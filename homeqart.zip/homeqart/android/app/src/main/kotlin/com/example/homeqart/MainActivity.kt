package com.example.homeqart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
