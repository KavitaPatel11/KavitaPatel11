import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class CategoryCard extends StatefulWidget {
  final double imageheight;
  final String name;
  final String image;
  final VoidCallback onTap;
  // final String unit;
  // final int offAmount;
  // final int mrp;
  // final int sellingPrice;
  // final int wishlistCount;
  const CategoryCard({
    Key? key,
    //   required this.id,
    required this.image,
    required this.name,
    required this.onTap,
    required this.imageheight,
    //   required this.unit,
    //   required this.mrp,
    //   required this.offAmount,
    //   required this.sellingPrice,
    //   required this.wishlistCount,
  }) : super(key: key);

  @override
  _CategoryCardState createState() => _CategoryCardState();
}

class _CategoryCardState extends State<CategoryCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.white70, width: 1),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Center(
                child: CachedNetworkImage(
                    fit: BoxFit.fill,
                    height: widget.imageheight,
                    imageUrl: "$baseUrl/storage/app/public/category/" +
                        widget.image.toString(),
                    placeholder: (context, url) {
                      return Padding(
                        padding: const EdgeInsets.all(10),
                        child: Image.asset("assets/images/placeholder.jpeg"),
                      );
                    },
                    errorWidget: (context, url, error) {
                      return Padding(
                        padding: const EdgeInsets.all(10),
                        child: SvgPicture.asset("assets/icons/Error.svg"),
                      );
                    }),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                ),
                child: Text(
                  widget.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.start,
                  style: Texttheme.caption2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
