import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';

import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class LatestProductCard extends StatefulWidget {
  final int id;
  final String name;
  final String image;
  final String unit;
  final String offAmount;
  final String mrp;
  final String sellingPrice;

  const LatestProductCard({
    Key? key,
    required this.id,
    required this.image,
    required this.unit,
    required this.name,
    required this.mrp,
    required this.offAmount,
    required this.sellingPrice,
  }) : super(key: key);

  @override
  _LatestProductCardState createState() => _LatestProductCardState();
}

class _LatestProductCardState extends State<LatestProductCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      child: InkWell(
        onTap: () {
          print("${widget.id}");
          Get.to(() => ProductdetailView(),
              arguments: widget.id, preventDuplicates: false);
        },
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 110,
                // ignore: prefer_if_null_operators
                child: Center(
                  child: FadeInImage(
                      imageErrorBuilder: (context, error, stackTrace) {
                        return SvgPicture.asset("assets/icons/Error.svg");
                      },
                      placeholder: AssetImage("assets/images/placeholder.jpeg"),
                      image: NetworkImage(
                        widget.image.toString(),
                      )),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                      width: double.infinity,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Center(
                          child: Text(widget.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              style: Texttheme.bodyText1),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "₹" + widget.sellingPrice.toString(),
                                textAlign: TextAlign.start,
                                style: Texttheme.subTitle
                                    .copyWith(color: AppColor.neturalOrange),
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                              Text(
                                "₹" + widget.mrp.toString(),
                                textAlign: TextAlign.start,
                                style: Texttheme.subTitle.copyWith(
                                  decoration: TextDecoration.lineThrough,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 2,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: AppColor.primaryColor,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 1.5),
                            child: Text(
                              "${widget.unit}",
                              style: Texttheme.bodyText1
                                  .copyWith(color: AppColor.accentWhite),
                            ),
                          ),
                        ),
                        widget.offAmount != 0
                            ? Container(
                                decoration: BoxDecoration(
                                  color: AppColor.primaryColor,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 1.5),
                                  child: Text(
                                    "Save ₹ ${widget.offAmount}",
                                    style: Texttheme.bodyText1
                                        .copyWith(color: AppColor.accentWhite),
                                  ),
                                ),
                              )
                            : Container(),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
