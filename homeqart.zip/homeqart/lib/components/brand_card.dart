import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';


class BrandCard extends StatefulWidget {
  final String image;
  final VoidCallback onTap;
  final double height;
  final double width;

  const BrandCard({
    Key? key,
    required this.image,
    required this.onTap,
     required this.width,
      required this.height,
  }) : super(key: key);

  @override
  _BrandCardState createState() => _BrandCardState();
}

class _BrandCardState extends State<BrandCard> {
 

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        height:widget.height,
        width: widget.height,
        child: CircleAvatar(
          backgroundColor: Colors.white,
         
          child: ClipRRect(
            borderRadius: BorderRadius.circular(600.0),
            child: CachedNetworkImage(
              imageUrl: 
                  widget.image.toString(),
              placeholder: (context, url){
                return Padding(
                  padding: const EdgeInsets.all(10),
                  child: Image.asset("assets/images/placeholder.jpeg"),
                );
              },
              errorWidget: (context, url, error){
                return Padding(
                  padding: const EdgeInsets.all(10),
                  child: SvgPicture.asset("assets/icons/Error.svg"),
                );
              }
            ),
          ),
        ),
      ),
    );
  }
}
