import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/custom_render.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class HomeCategoryCard extends StatefulWidget {
  
  final String image;

  final VoidCallback onTap;
  // final String unit;
  // final int offAmount;
  // final int mrp;
  // final int sellingPrice;
  // final int wishlistCount;
  const HomeCategoryCard({
    Key? key,
    //   required this.id,
    required this.image,
    
    required this.onTap,
    //   required this.unit,
    //   required this.mrp,
    //   required this.offAmount,
    //   required this.sellingPrice,
    //   required this.wishlistCount,
  }) : super(key: key);

  @override
  _HomeCategoryCardState createState() => _HomeCategoryCardState();
}

class _HomeCategoryCardState extends State<HomeCategoryCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
       
         
          child: Card(
            elevation: 1.0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(30.0))),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: ClipRRect(
                
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30.0),
                  topRight: Radius.circular(30.0),
                   bottomLeft: Radius.circular(30.0),
                  bottomRight: Radius.circular(30.0),
                ),
                child:CachedNetworkImage(
                fit: BoxFit.fill,
                height:100,
                width: 100,
                imageUrl:
                    "$baseUrl/storage/app/public/category/" +
                        widget.image.toString(),
                placeholder: (context, url) {
                  return Padding(
                    padding: const EdgeInsets.all(10),
                    child: Image.asset("assets/images/placeholder.jpeg"),
                  );
                },
                errorWidget: (context, url, error) {
                  return Padding(
                    padding: const EdgeInsets.all(10),
                    child: SvgPicture.asset("assets/icons/Error.svg"),
                  );
                }),
              ),
            ),
          ),
        )
    );
  }
}
