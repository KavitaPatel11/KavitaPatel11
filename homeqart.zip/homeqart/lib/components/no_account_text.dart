import 'package:flutter/material.dart';
import 'package:homeqart/app/modules/register/views/register_view.dart';

import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class NoAccountText extends StatelessWidget {
  const NoAccountText({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Don’t have an account? ",
          style: Texttheme.subTitle,
        ),
        GestureDetector(
          onTap: () =>
              Navigator.push(context, MaterialPageRoute(builder: (context) {
            return RegisterView();
          })),
          child: Text("Sign Up",
              style: Texttheme.subTitle.copyWith(color: AppColor.primaryColor)),
        ),
      ],
    );
  }
}
