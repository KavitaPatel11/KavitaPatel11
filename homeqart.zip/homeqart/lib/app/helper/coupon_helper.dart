import 'package:get_storage/get_storage.dart';

import 'package:homeqart/app/modules/shopping_cart/model/remove_coupon_response.dart';


final couponbox = GetStorage();

class GetCartStorageHelper {
  static setinitialdata() {
    couponbox.writeIfNull('msg', "");
  }

  static setdata(RemoveCouponResponse coupon_apiResponse) {
    couponbox.write('msg', coupon_apiResponse.msg);
  }
}
