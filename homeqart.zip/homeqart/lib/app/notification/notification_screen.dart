import 'package:flutter/material.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/get_notifications_response.dart';
import 'package:homeqart/app/notification/notification_tile.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/services/base_client.dart';


import 'notification_page.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({Key? key}) : super(key: key);

  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  List<GetNotificationResponse> notificationList = [];
  BaseClient baseClient = BaseClient();

  getNotification() async {
    var response = await baseClient.get(
        false, "$baseUrl", "/api/v1/notifications");
    notificationList = getNotificationResponseFromJson(response);
    setState(() {});
  }

  @override
  void initState() {
    //  implement initState
    getNotification();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar('Notifications'),
      backgroundColor: AppColor.accentBgColor,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Padding(
            padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
            child: ListView.separated(
              physics: ClampingScrollPhysics(),
              padding: EdgeInsets.zero,
              shrinkWrap: true,
              itemCount: notificationList.length,
              itemBuilder: (context, index) {
                return NotificationTile(
                  onTap: (){
                     Navigator.push(context, MaterialPageRoute(builder: (context) {
          return NotificationPage(notificationList[index]);
        }));
                  },
                  id: "${notificationList[index]}",
                  image: "${notificationList[index].image}",
                  heading: notificationList[index].title!,
                  description: notificationList[index].description!,
                  time: "${notificationList[index].time}",
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return Divider();
              },
            )

            // Column(
            //   children: [
            //     Padding(
            //       padding: const EdgeInsets.symmetric(vertical: 10),
            //       child: SizedBox(
            //         width: double.infinity,
            //         child: Text(
            //           "Today",
            //           style: Texttheme.subTitle,
            //         ),
            //       ),
            //     ),
            //     const NotificationTile(
            //       heading: "Title for Notification",
            //       description:
            //           "Reference site about Lorem Ipsum, giving information on its origins...",
            //       time: "10:45AM",
            //     ),
            //     const SizedBox(
            //       height: 10,
            //     ),
            //     const NotificationTile(
            //       heading: "Title for Notification",
            //       description:
            //           "Reference site about Lorem Ipsum, giving information on its origins...",
            //       time: "10:45AM",
            //     ),
            //     Padding(
            //       padding: const EdgeInsets.symmetric(vertical: 10),
            //       child: SizedBox(
            //         width: double.infinity,
            //         child: Text(
            //           "Yesterday",
            //           style: Texttheme.subTitle,
            //         ),
            //       ),
            //     ),
            //     const NotificationTile(
            //       heading: "Title for Notification",
            //       description:
            //           "Reference site about Lorem Ipsum, giving information on its origins...",
            //       time: "10:45AM",
            //     ),
            //     const SizedBox(
            //       height: 10,
            //     ),
            //     const NotificationTile(
            //       heading: "Title for Notification",
            //       description:
            //           "Reference site about Lorem Ipsum, giving information on its origins...",
            //       time: "10:45AM",
            //     ),
            //   ],
            // ),
            ),
      )),
    );
  }
}
