import 'package:flutter/material.dart';

import 'constent.dart';

class DefaultBackButton extends StatelessWidget {
  const DefaultBackButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back, color: kPrimaryColor),
      onPressed: () => Navigator.of(context).pop(),
    );
  }
}