
import 'package:flutter/material.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/get_notifications_response.dart';


import '../../components/appbar_without_actions.dart';
import 'component/constent.dart';
import 'component/default_appbar.dart';
import 'component/default_backbutton.dart';


class NotificationPage extends StatefulWidget {
 GetNotificationResponse notificationResponse;

   NotificationPage(this.notificationResponse);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhiteColor,
      appBar: CustomAppBar('Notifications details'),
      body: FittedBox(
        child: Container(
          // height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          margin: EdgeInsets.all(kFixPadding),
          padding: EdgeInsets.all(kFixPadding),
          decoration: BoxDecoration(
              color: kWhiteColor,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(8.0),
              boxShadow: [BoxShadow(color: kLightColor, blurRadius: 2.0)]),
          child: Column(
            children: [
              Text(
                  '${widget.notificationResponse.title}',
                 ),
              SizedBox(height: 16.0),
              SizedBox(
                height: 100,
                width: 100,

                child: Image.network("$baseUrl/storage/app/public/notification/${widget.notificationResponse.image}")),
              SizedBox(height: 16.0),
              Text(
                  "${widget.notificationResponse.description}",
                  style: TextStyle(color: kLightColor)),
              SizedBox(height: 16.0),
             
            ],
          ),
        ),
      ),
    );
  }
}