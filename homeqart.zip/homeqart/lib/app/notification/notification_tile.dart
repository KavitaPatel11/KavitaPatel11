import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';




class NotificationTile extends StatelessWidget {
  final String id;
  final String heading;
  final String description;
  final String image;
  final String time;
  final VoidCallback onTap;
  const NotificationTile(
      {Key? key,
      required this.heading,
      required this.image,
      required this.description,
      required this.time, 
      required this.id, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
       onTap:onTap,
      tileColor: AppColor.accentWhite,
      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      leading: SizedBox(
        width: 30,
        height: 25,
        child: ClipRRect(
          child: CachedNetworkImage(
            imageUrl:
                "storage/app/public/notification/" + image.toString(),
            placeholder: (context, url) => Icon(
              Icons.photo,
              size: 25,
              color: AppColor.accentLightGrey,
            ),
            errorWidget: (context, url, error) => Icon(
              Icons.person,
              size: 25,
              color: AppColor.accentLightGrey,
            ),
          ),
        ),
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            heading,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Texttheme.subTitle.copyWith(color: AppColor.accentDarkGrey),
          ),
          Text(
            time,
            style: Texttheme.caption1.copyWith(color: AppColor.accentLightGrey),
          )
        ],
      ),
      subtitle: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Text(
          description,
          maxLines: 2,
          textAlign: TextAlign.justify,
          overflow: TextOverflow.ellipsis,
          style: Texttheme.bodyText2.copyWith(color: AppColor.accentLightGrey),
        ),
      ),
    );
  }
}
