import 'package:get/get.dart';

import '../../components/filter.dart';
import '../modules/address/bindings/address_binding.dart';
import '../modules/address/views/address_view.dart';
import '../modules/brands/bindings/brands_binding.dart';
import '../modules/brands/views/all_brands_screen.dart';
import '../modules/brands/views/brands_view.dart';
import '../modules/categories/bindings/categories_binding.dart';
import '../modules/categories/views/categories_view.dart';
import '../modules/contact/bindings/contact_binding.dart';
import '../modules/contact/views/contact_view.dart';
import '../modules/contact_us.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';
import '../modules/login/bindings/login_binding.dart';
import '../modules/login/views/login_view.dart';
import '../modules/myorders_detail/bindings/myorders_detail_binding.dart';
import '../modules/myorders_detail/views/myorders_detail_view.dart';
import '../modules/orders/bindings/orders_binding.dart';
import '../modules/orders/views/orders_view.dart';
import '../modules/payment_option/bindings/payment_option_binding.dart';
import '../modules/payment_option/views/payment_option_view.dart';
import '../modules/productdetail/bindings/productdetail_binding.dart';
import '../modules/productdetail/views/productdetail_view.dart';
import '../modules/profile/views/profile_view.dart';
import '../modules/register/bindings/register_binding.dart';
import '../modules/register/views/register_view.dart';
import '../modules/search_products/searchbining.dart';
import '../modules/shopping_cart/bindings/shopping_cart_binding.dart';
import '../modules/shopping_cart/views/shopping_cart_view.dart';
import '../modules/showAllProducts/bindings/show_all_products_binding.dart';
import '../modules/showAllProducts/views/show_all_products_view.dart';
import '../modules/splash_screen/bindings/splash_screen_binding.dart';
import '../modules/splash_screen/views/splash_screen_view.dart';
import '../modules/wishlist/bindings/wishlist_binding.dart';
import '../modules/wishlist/views/wishlist_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH_SCREEN;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.LOGIN,
      page: () => LoginView(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.REGISTER,
      page: () => RegisterView(),
      binding: RegisterBinding(),
    ),
    GetPage(
      name: _Paths.WISHLIST,
      page: () => WishlistView(),
      binding: WishlistBinding(),
    ),
    GetPage(
      name: _Paths.CATEGORIES,
      page: () => CategoriesView(),
      binding: CategoriesBinding(),
    ),
    GetPage(
      name: _Paths.PROFILE,
      page: () => ProfileView(),
    ),
    GetPage(
      name: _Paths.SHOPPING_CART,
      page: () => ShoppingCartView(),
      binding: ShoppingCartBinding(),
    ),
    GetPage(
      name: _Paths.SPLASH_SCREEN,
      page: () => SplashScreenView(),
      binding: SplashScreenBinding(),
    ),
    GetPage(
      name: _Paths.PRODUCTDETAIL,
      page: () => ProductdetailView(),
      binding: ProductdetailBinding(),
    ),
    GetPage(
      name: _Paths.ADDRESS,
      page: () => AddressView(appBarTitle: "Address"),
      binding: AddressBinding(),
    ),
    GetPage(
      name: _Paths.ORDERS,
      page: () => OrdersView(),
      binding: OrdersBinding(),
    ),
    GetPage(
      name: _Paths.PAYMENT_OPTION,
      page: () => PaymentOptionView(),
      binding: PaymentOptionBinding(),
    ),
    GetPage(
      name: _Paths.SHOW_ALL_PRODUCTS,
      page: () => ShowAllProductsView(),
      binding: ShowAllProductsBinding(),
    ),
    GetPage(
      name: _Paths.BRANDS,
      page: () => AllBrandsView(),
      binding: BrandsBinding(),
    ),
    GetPage(
      name: _Paths.SEARCH,
      page: () => Filter(),
      binding: SearchBinding(),
    ),
    GetPage(
      name: _Paths.CONTACT,
      page: () => ContactUs(),
      binding: ContactBinding(),
    ),
    GetPage(
      name: _Paths.MYORDERS_DETAIL,
      page: () => MyordersDetailView(),
      binding: MyordersDetailBinding(),
    ),
  ];
}
