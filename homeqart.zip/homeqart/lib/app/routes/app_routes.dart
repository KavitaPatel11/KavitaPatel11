part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const LOGIN = _Paths.LOGIN;
  static const REGISTER = _Paths.REGISTER;
  static const WISHLIST = _Paths.WISHLIST;
  static const CATEGORIES = _Paths.CATEGORIES;
  static const PROFILE = _Paths.PROFILE;
  static const SHOPPING_CART = _Paths.SHOPPING_CART;
  static const SPLASH_SCREEN = _Paths.SPLASH_SCREEN;
  static const PRODUCTDETAIL = _Paths.PRODUCTDETAIL;
  static const ADDRESS = _Paths.ADDRESS;
  static const ORDERS = _Paths.ORDERS;
  static const PAYMENT_OPTION = _Paths.PAYMENT_OPTION;
  static const SHOW_ALL_PRODUCTS = _Paths.SHOW_ALL_PRODUCTS;
  static const BRANDS = _Paths.BRANDS;
  static const CONTACT = _Paths.CONTACT;
  static const MYORDERS_DETAIL = _Paths.MYORDERS_DETAIL;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const LOGIN = '/login';
  static const SEARCH = '/search';
  static const REGISTER = '/register';
  static const WISHLIST = '/wishlist';
  static const CATEGORIES = '/categories';
  static const PROFILE = '/profile';
  static const SHOPPING_CART = '/shopping-cart';
  static const SPLASH_SCREEN = '/splash-screen';
  static const PRODUCTDETAIL = '/productdetail';
  static const ADDRESS = '/address';
  static const ORDERS = '/orders';
  static const PAYMENT_OPTION = '/payment-option';
  static const SHOW_ALL_PRODUCTS = '/show-all-products';
  static const BRANDS = '/brands';
  static const CONTACT = '/contact';
  static const MYORDERS_DETAIL = '/myorders-detail';
}
