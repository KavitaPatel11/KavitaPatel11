


import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/categories/views/categories_view.dart';
import 'package:homeqart/app/modules/home/views/home_view.dart';
import 'package:homeqart/app/modules/profile/views/profile_view.dart';
import 'package:homeqart/app/modules/shopping_cart/views/shopping_cart_view.dart';
import 'package:homeqart/app/modules/wishlist/views/wishlist_view.dart';
import 'package:homeqart/app/theme.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  var children = [
   
    HomeView(),
    //  HomeView(),
    ShoppingCartView(),
    CategoriesView(),
    WishlistView(),
    ProfileView(),
    
  ];

  @override
  void initState() {
    super.initState();
  }

  void onTapped(int i) {
    setState(() {
      _currentIndex = i;
    });
  }

  Widget floatingButton() {
    return SizedBox(
      height: 50,
      width: 50,
      child: FloatingActionButton(
        onPressed: () {
          _currentIndex = 2;
          setState(() {});
        },
        child: const Icon(
          Icons.apps,
          color: Colors.white,
          size: 26.67,
        ),
        backgroundColor: AppColor.primaryColor,
        elevation: 0,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.accentBgColor,
      extendBody: true,
      body: children[_currentIndex],
      floatingActionButton: floatingButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
        child: BottomAppBar(
          color: Colors.transparent,
          clipBehavior: Clip.antiAlias,
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            onTap: onTapped,
            currentIndex: _currentIndex,
            backgroundColor: Colors.white,
            fixedColor: AppColor.primaryColor,
            unselectedItemColor: AppColor.defaultBlackColor,
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined,
                    color: _currentIndex == 0
                        ? AppColor.primaryColor
                        : AppColor.defaultBlackColor),
                label: "Home",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart_outlined,
                    color: _currentIndex == 1
                        ? AppColor.primaryColor
                        : AppColor.defaultBlackColor),
                label: "Cart",
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.analytics_outlined,
                  color: AppColor.accentWhite,
                ),
                label: "Categories",
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.favorite_border,
                  color: _currentIndex == 3
                      ? AppColor.primaryColor
                      : AppColor.defaultBlackColor,
                ),
                label: "Wishlist",
              ),
              BottomNavigationBarItem(
                icon: Container(
                          height: 25,
                          width: 25,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(60),
                            color: Colors.white,
                            border: Border.all(color: AppColor.primaryColor),
                          ),
                          child: ClipOval(
                            child: SizedBox.fromSize(
                              size: Size.fromRadius(48), // Image radius
                              child: CachedNetworkImage(
                                fit: BoxFit.cover,
                                imageUrl:
                                    "$baseUrl/storage/app/public/user/${box2.read("image")==null?"":box2.read("image")}" 
                                        ,
                                placeholder: (context, url) => Icon(
                                  Icons.photo,
                                  size: 20,
                                  color: AppColor.accentLightGrey,
                                ),
                                errorWidget: (context, url, error) => Icon(
                                  Icons.person,
                                  size: 20,
                                  color: AppColor.accentLightGrey,
                                ),
                              ),
                            ),
                          ),
                        ),
                label: "Profile",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
