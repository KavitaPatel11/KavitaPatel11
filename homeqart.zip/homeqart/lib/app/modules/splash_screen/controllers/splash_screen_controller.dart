import 'dart:async';

import 'package:get/get.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/login/views/login_view.dart';

import '../../../constent.dart';

class SplashScreenController extends GetxController {
  final count = 0.obs;
  @override
  void onInit() {
    authenticate();
    super.onInit();
  }

  authenticate() async {
    Timer(
      const Duration(seconds: 2),
      () {
        if ({box2.read("result")}.toString() == "true") {
          Get.offAll(MainScreen());
        } else {
          Get.offAll("/login");
        }
      },
    );
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
