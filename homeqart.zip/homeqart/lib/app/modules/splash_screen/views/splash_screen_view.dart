import 'dart:async';

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/login/views/login_view.dart';
import 'package:homeqart/app/theme.dart';

import '../../register/views/otp/otp_screen_sencond.dart';
import '../controllers/splash_screen_controller.dart';

class SplashScreenView extends StatefulWidget {
  const SplashScreenView({Key? key}) : super(key: key);

  @override
  _SplashScreenViewState createState() => _SplashScreenViewState();
}

class _SplashScreenViewState extends State<SplashScreenView> {
  authenticate() {
    print("verified  ${box2.read("verified")}");
    Timer(
      const Duration(seconds: 2),
      () {
        box2.read("logintoken") == null
            ? Get.offAllNamed("/login")
            : box2.read("verified") == "1" || box2.read("verified") == 1
                ? Get.offAll(MainScreen())
                : Navigator.push(context, MaterialPageRoute(builder: (_) {
                    return SecondOtpScreen(
                      mobileNUmber: box2.read("phone").toString(),
                      userId: box2.read("id").toString(),
                    );
                  }));
      },
    );
  }

  @override
  void initState() {
    super.initState();
    authenticate();
  }

  @override
  Widget build(BuildContext context) {
    // Future.delayed(Duration.zero, () async {
    //   if (box2.read("verified") == "1") {
    //     Get.snackbar(
    //       "Successfully ",
    //       "Logged in...",
    //       backgroundColor: Colors.green,
    //       snackPosition: SnackPosition.BOTTOM,
    //       borderRadius: 10,
    //       borderWidth: 2,
    //       colorText: Colors.white,
    //     );
    //   }
    // });
    return Scaffold(
      backgroundColor: AppColor.accentWhite,
      body: SafeArea(
          child: Center(
        child: Padding(
          padding: const EdgeInsets.all(0),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Image.asset(
              "assets/images/HomeQart.png",
            ),
          ),
        ),
      )),
    );
  }
}
