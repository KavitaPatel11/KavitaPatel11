import 'package:homeqart/app/modules/common_model/config_modal_data.dart';
import 'package:http/http.dart' as http;

import '../../constent.dart';

class ContactRemoteServices {
  static var client = http.Client();

  static Future<ConfigModalData?> fetchconfig_data() async {
    print("============ config data api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/config'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("config data api successs");
      var jsonString = response.body;
      print("config data======= $jsonString");
      print(jsonString);
      return configModalDataFromJson(jsonString);
    } else {
      print(" config data api Unsuccesssfull..");
      return null;
    }
  }
}
