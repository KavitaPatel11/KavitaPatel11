import 'package:get/get.dart';
import 'package:homeqart/app/modules/common_model/config_modal_data.dart';
import 'package:homeqart/app/modules/contact/contact_services.dart';

class ContactController extends GetxController {
  final count = 0.obs;
  var isLoading = true.obs;

  var configdata = ConfigModalData().obs;

  @override
  void onInit() async {
    config_data();

    super.onInit();
  }

  config_data() async {
    try {
      isLoading(true);
      print("config data try block");
      var data = await ContactRemoteServices.fetchconfig_data();
      print("===== config data==== $data ======");
      if (data != null) {
        print(" brands inside controller");
        configdata.value = data;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
