import 'package:get/get.dart';

import 'package:homeqart/app/modules/home/controllers/brandscontroller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/categorycontroller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/city_controller.dart';
import 'package:homeqart/app/modules/home/controllers/dailyneeds_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/discounted_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/featured_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/latest_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/upselling_product_controller_controller.dart';

import '../controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<DiscountedProductControllerController>(
      () => DiscountedProductControllerController(),
    );
    Get.lazyPut<UpsellingProductControllerController>(
      () => UpsellingProductControllerController(),
    );
    Get.lazyPut<FeaturedProductControllerController>(
      () => FeaturedProductControllerController(),
    );
    Get.lazyPut<DailyneedsProductControllerController>(
      () => DailyneedsProductControllerController(),
    );
    Get.lazyPut<LatestProductControllerController>(
      () => LatestProductControllerController(),
    );
    Get.lazyPut<CategorycontrollerController>(
      () => CategorycontrollerController(),
    );
    Get.lazyPut<BrandscontrollerController>(
      () => BrandscontrollerController(),
    );
    Get.lazyPut<HomeController>(
      () => HomeController(),
    );
    Get.lazyPut<CitycontrollerController>(
      () => CitycontrollerController(),
    );
  }
}
