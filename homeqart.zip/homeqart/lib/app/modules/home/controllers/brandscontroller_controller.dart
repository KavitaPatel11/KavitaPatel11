import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class BrandscontrollerController extends GetxController {
  final count = 0.obs;
  var isLoading = true.obs;

  var brandslist = BrandResponse().obs;

  @override
  void onInit() async {
    brands();

    super.onInit();
  }

  brands() async {
    try {
      isLoading(true);
      print(" brands try block");
      var brands = await HomePageRemoteServices.fetch_brands();
      print("===== brands==== $brands ======");
      if (brands != null) {
        print(" brands inside controller");
        brandslist.value = brands;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
