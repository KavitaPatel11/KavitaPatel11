import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class CategorycontrollerController extends GetxController {
  var isLoading = true.obs;

  List<CategoryModel> categorieslist = [];

  @override
  void onInit() async {
    categories();

    super.onInit();
  }

  categories() async {
    try {
      isLoading(true);
      print(" banners try block");
      var categories = await HomePageRemoteServices.fetch_categories();
      print("========= $categories ======");
      if (categories != null) {
        print("categories inside controller");
        categorieslist.assignAll(categories);
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.dispose();
  }
}
