import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class FeaturedProductControllerController extends GetxController {
 

  final count = 0.obs;
 var isLoading = true.obs;
  
  var featuredproductlist = ProductModel().obs;
  

  @override
  void onInit() async {
    featured();

    super.onInit();
  }



 

 
  featured() async {
    try {
      isLoading(true);
      print("featured try block");
      var featured = await HomePageRemoteServices.fetchfeatured_products();
      print("========= $featured ======");
      if (featured != null) {
        print("categories inside controller");
        featuredproductlist.value = featured;
      }
    } finally {
      isLoading(false);
    }
  }


  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
