import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class DailyneedsProductControllerController extends GetxController {


 var isLoading = true.obs;

  var dailyneedsproductlist = ProductModel().obs;
 

  @override
  void onInit() async {
   
   dailyNeeds();
    super.onInit();
  }

 

  
  dailyNeeds() async {
    try {
      isLoading(true);
      print(" dailyNeeds try block");
      var dailyNeeds = await HomePageRemoteServices.fetchdaily_needs_products();
      print("========= $dailyNeeds ======");
      if (dailyNeeds != null) {
        print(" dailyNeeds inside controller");
        dailyneedsproductlist.value = dailyNeeds;
      }
    } finally {
      isLoading(false);
    }
  }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
 
}
