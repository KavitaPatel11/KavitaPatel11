import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/get_banners_response.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class HomeController extends GetxController {
  final count = 0.obs;

  var isLoading = true.obs;

  List<GetBannersResponse> carouselist = [];

  @override
  void onInit() async {
    banners();

    super.onInit();
  }

  banners() async {
    try {
      isLoading(true);

      print("banners try block");
      var banners = await HomePageRemoteServices.fetchbanners();
      print("========= $banners ======");
      if (banners != null) {
        print(" banners inside controller");
        carouselist.assignAll(banners);
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.dispose();
  }
}
