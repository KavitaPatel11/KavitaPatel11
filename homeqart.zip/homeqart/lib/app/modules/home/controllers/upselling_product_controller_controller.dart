import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class UpsellingProductControllerController extends GetxController {
   var isLoading = true.obs;

  var upsellingproductlist = ProductModel().obs;

  @override
  void onInit() async {
    upselling();

    super.onInit();
  }

  upselling() async {
    try {
      isLoading(true);
      print("featured try block");
      var upselling = await HomePageRemoteServices.fetch_up_selling_products();
      print("========= $upselling ======");
      if (upselling != null) {
        print("upselling inside controller");
        upsellingproductlist.value = upselling;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.dispose();
  }
}
