import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class DiscountedProductControllerController extends GetxController {
  var isLoading = true.obs;

  var discountedproductlist = ProductModel().obs;

  @override
  void onInit() async {
    discounted();
    super.onInit();
  }

  discounted() async {
    try {
      isLoading(true);
      print("discounted try block");
      var discounted = await HomePageRemoteServices.fetch_discounted_products();
      print("========= $discounted ======");
      if (discounted != null) {
        print("discounted inside controller");
        discountedproductlist.value = discounted;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.dispose();
  }
}
