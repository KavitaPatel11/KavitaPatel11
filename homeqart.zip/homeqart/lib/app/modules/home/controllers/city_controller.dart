import 'package:get/get.dart';
import 'package:homeqart/app/modules/common_model/auth_city_modal.dart';
import 'package:homeqart/app/modules/common_model/set_city_modal.dart';
import 'package:homeqart/app/modules/home/controllers/upselling_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

import 'brandscontroller_controller.dart';
import 'categorycontroller_controller.dart';
import 'dailyneeds_product_controller_controller.dart';
import 'discounted_product_controller_controller.dart';
import 'featured_product_controller_controller.dart';
import 'home_controller.dart';
import 'latest_product_controller_controller.dart';

class CitycontrollerController extends GetxController {
  final count = 0.obs;
  var isCityLoading = true.obs;
  var isSetCityLoading = true.obs;

  var citylist = AvailableCityModal().obs;
  var postcitylist = SetCityModal().obs;
  final HomeController homeController = Get.put(HomeController());

  final CategorycontrollerController categorycontrollerController =
      Get.put(CategorycontrollerController());

  final BrandscontrollerController brandscontrollerController =
      Get.put(BrandscontrollerController());

  final LatestProductControllerController latestProductControllerController =
      Get.put(LatestProductControllerController());

  final DailyneedsProductControllerController
      dailyneedsProductControllerController =
      Get.put(DailyneedsProductControllerController());

  final FeaturedProductControllerController
      featuredProductControllerController =
      Get.put(FeaturedProductControllerController());

  final UpsellingProductControllerController
      upsellingProductControllerController =
      Get.put(UpsellingProductControllerController());

  final DiscountedProductControllerController
      discountedProductControllerController =
      Get.put(DiscountedProductControllerController());

  @override
  void onInit() async {
    city();

    super.onInit();
  }

  city() async {
    try {
      isCityLoading(true);
      print(" city try block");
      var cities = await HomePageRemoteServices.fetchcity();
      print("===== city==== $cities ======");
      if (cities != null) {
        print(" city inside controller");
        citylist.value = cities;
      }
    } finally {
      isCityLoading(false);
    }
  }

  setcity(city_id) async {
    try {
      isSetCityLoading(true);
      print("set city try block");
      var postcities = await HomePageRemoteServices.postCity(city_id);
      print("=====set city==== $postcities ======");
      if (postcities != null) {
        print("set city inside controller");
        postcitylist.value = postcities;
        homeController.banners();
        categorycontrollerController.categories();
        latestProductControllerController.latest_product();
        dailyneedsProductControllerController.dailyNeeds();
        brandscontrollerController.brands();
        featuredProductControllerController.featured();
        upsellingProductControllerController.upselling();
        discountedProductControllerController.discounted();
      }
    } finally {
      isSetCityLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
