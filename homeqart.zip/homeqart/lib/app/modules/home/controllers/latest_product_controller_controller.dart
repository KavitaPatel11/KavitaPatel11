import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/latestproductdata.dart';
import 'package:homeqart/app/modules/home/services/homeservices.dart';

class LatestProductControllerController extends GetxController {
  var isLoading = true.obs;

  var latestproductlist = LatestProductModel().obs;

  @override
  void onInit() async {
    latest_product();
    super.onInit();
  }

  latest_product() async {
    try {
      isLoading(true);
      print("latest_product try block");
      var latest_product = await HomePageRemoteServices.fetchlatestproduct();
      print("========= $latest_product ======");
      if (latest_product != null) {
        print("latest_product inside controller");
        latestproductlist.value = latest_product;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.dispose();
  }
}
