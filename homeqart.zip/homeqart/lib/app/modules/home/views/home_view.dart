// ignore_for_file: prefer_if_null_operators

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/custom_render.dart';
import 'package:get/get.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/brands/views/brands_view.dart';
import 'package:homeqart/app/modules/drawer/drawer_screen.dart';
import 'package:homeqart/app/modules/home/controllers/brandscontroller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/categorycontroller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/city_controller.dart';
import 'package:homeqart/app/modules/home/controllers/dailyneeds_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/discounted_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/featured_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/home_controller.dart';
import 'package:homeqart/app/modules/home/controllers/latest_product_controller_controller.dart';
import 'package:homeqart/app/modules/home/controllers/upselling_product_controller_controller.dart';
import 'package:homeqart/app/modules/login/model/user_data_list.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/modules/search_products/search_products.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_all_discounted_product.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_all_featured_products.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_all_product_screen3.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_all_products2.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_all_top_selling_products.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products/show_banner_category_screen.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products_view.dart';
import 'package:homeqart/app/notification/notification_screen.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/brand_card.dart';
import 'package:homeqart/components/category_card.dart';
import 'package:homeqart/components/homecategory_card.dart';
import 'package:homeqart/components/latest_productcard.dart';
import 'package:homeqart/components/product_card.dart';
import 'package:universal_html/html.dart' as html;

import '../../showAllProducts/views/categorise_wise/show_all_product_by_brand.dart';
import '../../showAllProducts/views/categorise_wise/show_all_product_by_categories.dart';
import '../../showAllProducts/views/show_all_products/show_all_product_screen4.dart';
import '../../showAllProducts/views/show_all_products/show_all_product_screen_dailyneeds.dart';
import '../model/get_banners_response.dart';

class HomeView extends StatefulWidget {
  HomeView({Key? key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  List<String> _locations = ['A', 'B', 'C', 'D']; // Option 2
  String? _selectedLocation;
  // Option 2

  final CitycontrollerController citycontrollerController =
      Get.put(CitycontrollerController());
  final HomeController homeController = Get.put(HomeController());

  final CategorycontrollerController categorycontrollerController =
      Get.put(CategorycontrollerController());

  final BrandscontrollerController brandscontrollerController =
      Get.put(BrandscontrollerController());

  final LatestProductControllerController latestProductControllerController =
      Get.put(LatestProductControllerController());

  final DailyneedsProductControllerController
      dailyneedsProductControllerController =
      Get.put(DailyneedsProductControllerController());

  final FeaturedProductControllerController
      featuredProductControllerController =
      Get.put(FeaturedProductControllerController());

  final UpsellingProductControllerController
      upsellingProductControllerController =
      Get.put(UpsellingProductControllerController());

  final DiscountedProductControllerController
      discountedProductControllerController =
      Get.put(DiscountedProductControllerController());

  latestproduct() {
    return SizedBox(
      child: Obx(() {
        if (latestProductControllerController.isLoading.value == null
            ? false
            : latestProductControllerController.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Latest Products",
                      style: Texttheme.subTitle,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(ShowAllProductScreen4(), arguments: [
                          {'title': "Latest products"},
                          {'path': "products/latest"},
                          {
                            'totalrecords': latestProductControllerController
                                .latestproductlist.value.totalSize
                          },
                          {'isReload': true},
                        ]);
                      },
                      child: Text(
                        "View All",
                        style: Texttheme.subTitle,
                      ),
                    )
                  ],
                ),
              ),
              latestProductControllerController
                      .latestproductlist.value.products!.isEmpty
                  ? SizedBox(
                      height: 220,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 220,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: latestProductControllerController
                                      .latestproductlist
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : latestProductControllerController
                                  .latestproductlist.value.products!.length,
                          itemExtent: 158,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return LatestProductCard(
                              id: latestProductControllerController
                                          .latestproductlist
                                          .value
                                          .products![index]
                                          .id ==
                                      null
                                  ? 0
                                  : latestProductControllerController
                                      .latestproductlist
                                      .value
                                      .products![index]
                                      .id!,
                              image: "$baseUrl/storage/app/public/product/" +
                                  latestProductControllerController
                                      .latestproductlist
                                      .value
                                      .products![index]
                                      .image![0],
                              mrp:
                                  "${latestProductControllerController.latestproductlist.value.products![index].price == null ? "" : latestProductControllerController.latestproductlist.value.products![index].price!}",
                              offAmount:
                                  "${latestProductControllerController.latestproductlist.value.products![index].offAmount == null ? "" : latestProductControllerController.latestproductlist.value.products![index].offAmount!}",
                              sellingPrice:
                                  "${latestProductControllerController.latestproductlist.value.products![index].sellingPrice == null ? "" : latestProductControllerController.latestproductlist.value.products![index].sellingPrice!}",
                              name: latestProductControllerController
                                          .latestproductlist
                                          .value
                                          .products![index]
                                          .name ==
                                      null
                                  ? ""
                                  : latestProductControllerController
                                      .latestproductlist
                                      .value
                                      .products![index]
                                      .name
                                      .toString(),
                              unit: latestProductControllerController
                                          .latestproductlist
                                          .value
                                          .products![index]
                                          .unit ==
                                      null
                                  ? ""
                                  : latestProductControllerController
                                      .latestproductlist
                                      .value
                                      .products![index]
                                      .unit
                                      .toString(),
                            );
                          }),
                    ),
            ],
          );
        }
      }),
    );
  }

  dailyneedsproduct() {
    return SizedBox(
      child: Obx(() {
        if (dailyneedsProductControllerController.isLoading.value == null
            ? false
            : dailyneedsProductControllerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Daily needs",
                      style: Texttheme.subTitle,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(ShowAllDailyNeedsProductScreen(), arguments: [
                          {'title': "Daliy needs"},
                          {'path': "products/daily-needs"},
                          {
                            'totalrecords':
                                dailyneedsProductControllerController
                                    .dailyneedsproductlist.value.totalSize
                          },
                          {'isReload': true},
                        ]);
                      },
                      child: Text(
                        "View All",
                        style: Texttheme.subTitle,
                      ),
                    )
                  ],
                ),
              ),
              dailyneedsProductControllerController
                      .dailyneedsproductlist.value.products!.isEmpty
                  ? SizedBox(
                      height: 220,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 220,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: dailyneedsProductControllerController
                                      .dailyneedsproductlist
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : dailyneedsProductControllerController
                                  .dailyneedsproductlist.value.products!.length,
                          itemExtent: 158,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return ProductCard(
                              mrp:
                                  "${dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].price == null ? 0 : dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].price!}",
                              image: "$baseUrl/storage/app/public/product/" +
                                  dailyneedsProductControllerController
                                      .dailyneedsproductlist
                                      .value
                                      .products![index]
                                      .image![0],
                              sellingPrice:
                                  "${dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].sellingPrice.toString() == null ? 0 : dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].sellingPrice.toString()}",
                              name:
                                  '${dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].name == null ? "" : dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].name}',
                              offAmount:
                                  "${dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].offAmount == null ? 0 : dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].offAmount!}",
                              id: dailyneedsProductControllerController
                                          .dailyneedsproductlist
                                          .value
                                          .products![index]
                                          .id ==
                                      null
                                  ? 0
                                  : dailyneedsProductControllerController
                                      .dailyneedsproductlist
                                      .value
                                      .products![index]
                                      .id!,
                              unit:
                                  '${dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].unit == null ? 0 : dailyneedsProductControllerController.dailyneedsproductlist.value.products![index].unit}',
                            );
                          }),
                    ),
            ],
          );
        }
      }),
    );
  }

  buildfeaturedproduct() {
    return SizedBox(
      child: Obx(() {
        if (featuredProductControllerController.isLoading.value == null
            ? false
            : featuredProductControllerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Featured Products",
                      style: Texttheme.subTitle,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(ShowAllFeaturedProductScreen(), arguments: [
                          {'title': "Featured products"},
                          {'path': "products/featured"},
                          {
                            'totalrecords': featuredProductControllerController
                                .featuredproductlist.value.totalSize
                          },
                          {'isReload': true},
                        ]);
                      },
                      child: Text(
                        "View All",
                        style: Texttheme.subTitle,
                      ),
                    )
                  ],
                ),
              ),
              featuredProductControllerController
                      .featuredproductlist.value.products!.isEmpty
                  ? SizedBox(
                      height: 220,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 220,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: featuredProductControllerController
                                      .featuredproductlist
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : featuredProductControllerController
                                  .featuredproductlist.value.products!.length,
                          itemExtent: 158,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return ProductCard(
                              mrp:
                                  "${featuredProductControllerController.featuredproductlist.value.products![index].price == null ? 0 : featuredProductControllerController.featuredproductlist.value.products![index].price!}",
                              image: "$baseUrl/storage/app/public/product/" +
                                  featuredProductControllerController
                                      .featuredproductlist
                                      .value
                                      .products![index]
                                      .image![0],
                              sellingPrice:
                                  "${featuredProductControllerController.featuredproductlist.value.products![index].sellingPrice == null ? 0 : featuredProductControllerController.featuredproductlist.value.products![index].sellingPrice!}",
                              name:
                                  '${featuredProductControllerController.featuredproductlist.value.products![index].name == null ? "" : featuredProductControllerController.featuredproductlist.value.products![index].name}',
                              offAmount:
                                  "${featuredProductControllerController.featuredproductlist.value.products![index].offAmount == null ? 0 : featuredProductControllerController.featuredproductlist.value.products![index].offAmount!}",
                              id: featuredProductControllerController
                                          .featuredproductlist
                                          .value
                                          .products![index]
                                          .id ==
                                      null
                                  ? 0
                                  : featuredProductControllerController
                                      .featuredproductlist
                                      .value
                                      .products![index]
                                      .id!,
                              unit:
                                  '${featuredProductControllerController.featuredproductlist.value.products![index].unit == null ? 0 : featuredProductControllerController.featuredproductlist.value.products![index].unit!}',
                            );
                          }),
                    ),
            ],
          );
        }
      }),
    );
  }

  buildUpSellingproduct() {
    return SizedBox(
      child: Obx(() {
        if (upsellingProductControllerController.isLoading.value == null
            ? false
            : upsellingProductControllerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Top Selling ",
                      style: Texttheme.subTitle,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(ShowAllUpSellingProductScreen(), arguments: [
                          {'title': "Top Selling"},
                          {'path': "products/up-selling"},
                          {
                            'totalrecords': upsellingProductControllerController
                                .upsellingproductlist.value.totalSize
                          },
                          {'isReload': true},
                        ]);
                      },
                      child: Text(
                        "View All",
                        style: Texttheme.subTitle,
                      ),
                    )
                  ],
                ),
              ),
              upsellingProductControllerController
                      .upsellingproductlist.value.products!.isEmpty
                  ? SizedBox(
                      height: 220,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 220,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: upsellingProductControllerController
                                      .upsellingproductlist
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : upsellingProductControllerController
                                  .upsellingproductlist.value.products!.length,
                          itemExtent: 158,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return ProductCard(
                              mrp:
                                  "${upsellingProductControllerController.upsellingproductlist.value.products![index].price == null ? 0 : upsellingProductControllerController.upsellingproductlist.value.products![index].price!}",
                              image: "$baseUrl/storage/app/public/product/" +
                                  upsellingProductControllerController
                                      .upsellingproductlist
                                      .value
                                      .products![index]
                                      .image![0],
                              sellingPrice:
                                  "${upsellingProductControllerController.upsellingproductlist.value.products![index].sellingPrice == null ? 0 : upsellingProductControllerController.upsellingproductlist.value.products![index].sellingPrice!}",
                              name:
                                  '${upsellingProductControllerController.upsellingproductlist.value.products![index].name == null ? "" : upsellingProductControllerController.upsellingproductlist.value.products![index].name}',
                              offAmount:
                                  "${upsellingProductControllerController.upsellingproductlist.value.products![index].offAmount == null ? 0 : upsellingProductControllerController.upsellingproductlist.value.products![index].offAmount!}",
                              id: upsellingProductControllerController
                                          .upsellingproductlist
                                          .value
                                          .products![index]
                                          .id ==
                                      null
                                  ? 0
                                  : upsellingProductControllerController
                                      .upsellingproductlist
                                      .value
                                      .products![index]
                                      .id!,
                              unit:
                                  '${upsellingProductControllerController.upsellingproductlist.value.products![index].unit == null ? 0 : upsellingProductControllerController.upsellingproductlist.value.products![index].unit!}',
                            );
                          }),
                    ),
            ],
          );
        }
      }),
    );
  }

  builddiscountedproduct() {
    return SizedBox(
      child: Obx(() {
        if (discountedProductControllerController.isLoading.value == null
            ? false
            : discountedProductControllerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Discounted Products",
                      style: Texttheme.subTitle,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(ShowAllDiscountedProductScreen(), arguments: [
                          {'title': "Discounted products"},
                          {'path': "products/discounted"},
                          {
                            'totalrecords':
                                discountedProductControllerController
                                    .discountedproductlist.value.totalSize
                          },
                          {'isReload': true},
                        ]);
                      },
                      child: Text(
                        "View All",
                        style: Texttheme.subTitle,
                      ),
                    )
                  ],
                ),
              ),
              discountedProductControllerController
                      .discountedproductlist.value.products!.isEmpty
                  ? SizedBox(
                      height: 220,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 220,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: discountedProductControllerController
                                      .discountedproductlist
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : discountedProductControllerController
                                  .discountedproductlist.value.products!.length,
                          itemExtent: 158,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return ProductCard(
                              mrp:
                                  "${discountedProductControllerController.discountedproductlist.value.products![index].price == null ? 0 : discountedProductControllerController.discountedproductlist.value.products![index].price!}",
                              image: "$baseUrl/storage/app/public/product/" +
                                  discountedProductControllerController
                                      .discountedproductlist
                                      .value
                                      .products![index]
                                      .image![0],
                              sellingPrice:
                                  "${discountedProductControllerController.discountedproductlist.value.products![index].sellingPrice == null ? 0 : discountedProductControllerController.discountedproductlist.value.products![index].sellingPrice!}",
                              name:
                                  '${discountedProductControllerController.discountedproductlist.value.products![index].name == null ? "" : discountedProductControllerController.discountedproductlist.value.products![index].name}',
                              offAmount:
                                  "${discountedProductControllerController.discountedproductlist.value.products![index].offAmount == null ? 0 : discountedProductControllerController.discountedproductlist.value.products![index].offAmount!}",
                              id: discountedProductControllerController
                                          .discountedproductlist
                                          .value
                                          .products![index]
                                          .id ==
                                      null
                                  ? 0
                                  : discountedProductControllerController
                                      .discountedproductlist
                                      .value
                                      .products![index]
                                      .id!,
                              unit:
                                  '${discountedProductControllerController.discountedproductlist.value.products![index].unit == null ? 0 : discountedProductControllerController.discountedproductlist.value.products![index].unit!}',
                            );
                          }),
                    ),
            ],
          );
        }
      }),
    );
  }

  buildCategoriesdata() {
    return SizedBox(
      child: Obx(() {
        if (categorycontrollerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Categories",
                  style: Texttheme.subTitle,
                ),
              ),
              categorycontrollerController.categorieslist.isEmpty
                  ? SizedBox(
                      height: 210,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 210,
                      child: GridView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: categorycontrollerController
                                    .categorieslist.length ==
                                null
                            ? 0
                            : categorycontrollerController
                                .categorieslist.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 5,
                          mainAxisSpacing: 10,
                          mainAxisExtent: 105,
                        ),
                        itemBuilder: (BuildContext context, int index) {
                          return HomeCategoryCard(
                            onTap: () {
                              Get.to(ShowAllProductByCategory(), arguments: [
                                {
                                  'id': categorycontrollerController
                                      .categorieslist[index].id
                                },
                                {
                                  'name': categorycontrollerController
                                      .categorieslist[index].name
                                },
                                {
                                  'banner': categorycontrollerController
                                      .categorieslist[index].banner
                                }
                              ]);
                            },
                            image: categorycontrollerController
                                .categorieslist[index].mobileImage
                                .toString(),
                          );
                        },
                      ),
                    ),
            ],
          );
        }
      }),
    );
  }

  buildBrandsdata() {
    return SizedBox(
      child: Obx(() {
        if (brandscontrollerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Brands",
                  style: Texttheme.subTitle,
                ),
              ),
              brandscontrollerController.brandslist.value.brands!.isEmpty
                  ? SizedBox(
                      height: 260,
                      child: Center(child: Text("nothing to show")))
                  : SizedBox(
                      height: 260,
                      child: GridView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: brandscontrollerController
                                    .brandslist.value.brands!.length ==
                                null
                            ? 0
                            : brandscontrollerController
                                .brandslist.value.brands!.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                          mainAxisExtent: 108,
                        ),
                        itemBuilder: (BuildContext context, int index) {
                          return BrandCard(
                            onTap: () {
                              Get.to(ShowAllBrandsProductScreen(), arguments: [
                                {
                                  'id': brandscontrollerController
                                      .brandslist.value.brands![index].id!
                                },
                                {
                                  'name': brandscontrollerController
                                      .brandslist.value.brands![index].name
                                },
                                {
                                  'banner': brandscontrollerController
                                      .brandslist.value.brands![index].banner
                                }
                              ]);
                            },
                            image:
                                "$baseUrl/storage/app/public/brand/${brandscontrollerController.brandslist.value.brands![index].image![0] == null ? "" : brandscontrollerController.brandslist.value.brands![index].image!}",
                            height: 30.0,
                            width: 30.0,
                          );
                        },
                      ),
                    ),
            ],
          );
        }
      }),
    );
  }

  SizedBox buildHomeCarousel() {
    return SizedBox(child: Obx((() {
      if (homeController.isLoading.value) {
        return Center(
          child: SpinKitThreeBounce(color: Colors.white),
        );
      } else {
        return CarouselSlider.builder(
          options: CarouselOptions(
            autoPlay: true,
            enlargeCenterPage: false,
            viewportFraction: 0.9,
            aspectRatio: 2.0,
            initialPage: 1,
          ),
          itemCount: homeController.carouselist.length == null
              ? 0
              : homeController.carouselist.length,
          itemBuilder: (BuildContext context, int itemIndex,
                  int pageViewIndex) =>
              GestureDetector(
                  onTap: () {
                    homeController.carouselist[itemIndex].categoryId == null
                        ? Get.to(ProductdetailView(),
                            arguments: homeController
                                .carouselist[itemIndex].productId!)
                        : Get.to(BannerCategoryView(), arguments: [
                            {
                              'id': homeController
                                  .carouselist[itemIndex].categoryId
                            },
                            {
                              'name':
                                  homeController.carouselist[itemIndex].title
                            },
                            {
                              'banner':
                                  homeController.carouselist[itemIndex].image
                            }
                          ]);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Stack(
                        children: [
                          // Container(
                          //   decoration: BoxDecoration(
                          //     shape: BoxShape.circle,
                          //     image: DecorationImage(
                          //       image: CachedNetworkImageProvider(''),
                          //     ),
                          //   ),
                          // ),
                          SizedBox(
                            width: double.infinity,
                            height: double.infinity,
                            child: CachedNetworkImage(
                              imageUrl: "$baseUrl/storage/app/public/banner/" +
                                  homeController.carouselist[itemIndex].image
                                      .toString(),
                              fit: BoxFit.cover,
                              placeholder: (context, url) => Icon(
                                Icons.photo,
                                size: 50,
                                color: AppColor.accentLightGrey,
                              ),
                              errorWidget: (context, url, error) => Icon(
                                Icons.info,
                                size: 50,
                                color: AppColor.accentLightGrey,
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  const Color(0xFF343434).withOpacity(0.7),
                                  const Color(0xFF343434).withOpacity(0.15),
                                ],
                              ),
                            ),
                          ),
                          // Padding(
                          //   padding: const EdgeInsets.symmetric(
                          //     horizontal: 15.0,
                          //     vertical: 20,
                          //   ),
                          //   child: Text(
                          //     homeController.carouselist[itemIndex].title
                          //         .toString(),
                          //     style: const TextStyle(
                          //         color: Colors.white,
                          //         fontSize: 18,
                          //         fontWeight: FontWeight.bold),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  )),
        );
      }
    })));
  }

  String greeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Good Morning';
    }
    if (hour < 17) {
      return 'Good Afternoon';
    }
    return 'Good Evening';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: DrawerView(),
        backgroundColor: Colors.grey.shade100,
        appBar: AppBar(
          iconTheme: IconThemeData(color: AppColor.accentWhite, size: 25),

          backgroundColor: AppColor.primaryColor,
          // leading: const Icon(Icons.menu),
          title: Text(
            "HomeQart",
            style: Texttheme.heading.copyWith(color: AppColor.accentWhite),
          ),
          bottom: PreferredSize(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: InkWell(
                  onTap: () {
                    Get.to(Filter());
                    // Navigator.push(context,
                    //     MaterialPageRoute(builder: (context) {
                    //   return Filter2();
                    // }));
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 10),
                    height: 40,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text(
                              'Search here',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey),
                            ),
                            Icon(
                              Icons.search,
                              color: Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              preferredSize: const Size.fromHeight(40)),
          actions: [
            IconButton(
                icon: Icon(Icons.notifications),
                onPressed: () {
                  Get.to(NotificationScreen());
                }),
            SizedBox(
              width: 30,
            ),
          ],
        ),
        // appBar: AppBar(
        //   iconTheme: IconThemeData(color: AppColor.accentWhite, size: 25),

        //   backgroundColor: AppColor.primaryColor,
        //   // leading: const Icon(Icons.menu),
        //   title: Obx(() {
        //     if (citycontrollerController.isCityLoading.value) {
        //       return Center(
        //         child: SpinKitThreeBounce(color: Colors.white),
        //       );
        //     } else {
        //       return TextButton(
        //         onPressed: () {
        //           showModalBottomSheet(
        //               context: context,
        //               shape: const RoundedRectangleBorder(
        //                 // <-- SEE HERE
        //                 borderRadius: BorderRadius.vertical(
        //                   top: Radius.circular(35.0),
        //                 ),
        //               ),
        //               builder: (context) {
        //                 return SingleChildScrollView(
        //                   child: Column(
        //                     children: [
        //                       Container(
        //                         margin: EdgeInsets.only(top: 20),
        //                         height: 3,
        //                         width: 100,
        //                         decoration: BoxDecoration(
        //                             color: Colors.grey,
        //                             borderRadius: BorderRadius.circular(10)),
        //                       ),
        //                       Container(
        //                         height: 200,
        //                         child: ListView.separated(
        //                           itemCount: citycontrollerController
        //                               .citylist.value.city!.length,
        //                           itemBuilder:
        //                               (BuildContext context, int index) {
        //                             return InkWell(
        //                               onTap: (() {
        //                                 setState(() {
        //                                   _selectedLocation =
        //                                       citycontrollerController.citylist
        //                                           .value.city![index].name!;
        //                                 });
        //                                 citycontrollerController.setcity(
        //                                     citycontrollerController
        //                                         .citylist.value.city![index].id
        //                                         .toString());
        //                                 Get.back();
        //                               }),
        //                               child: Container(
        //                                 padding: EdgeInsets.symmetric(
        //                                     vertical: 5, horizontal: 5),
        //                                 margin: EdgeInsets.only(left: 10),
        //                                 height: 30,
        //                                 child: Text(
        //                                     "${citycontrollerController.citylist.value.city![index].name}"),
        //                               ),
        //                             );
        //                           },
        //                           separatorBuilder:
        //                               (BuildContext context, int index) {
        //                             return Padding(
        //                               padding: const EdgeInsets.symmetric(
        //                                   horizontal: 10),
        //                               child: Divider(
        //                                 color: AppColor.accentLightGrey,
        //                               ),
        //                             );
        //                           },
        //                         ),
        //                       ),
        //                     ],
        //                   ),
        //                 );
        //               });
        //         },
        //         child: Row(
        //           children: [
        //             Icon(
        //               Icons.location_on,
        //               color: AppColor.neturalRed,
        //               size: 18,
        //             ),
        //             SizedBox(
        //               width: 5,
        //             ),
        //             Text(
        //               '${_selectedLocation == null ? "Select city" : _selectedLocation}',
        //               style: Texttheme.subTitle
        //                   .copyWith(color: AppColor.accentWhite),
        //             ),
        //           ],
        //         ),
        //       );
        //     }
        //   }),
        //   bottom: PreferredSize(
        //       child: Padding(
        //         padding: EdgeInsets.symmetric(horizontal: 20),
        //         child: InkWell(
        //           onTap: () {
        //             Get.to(Filter());
        //           },
        //           child: Container(
        //             margin: EdgeInsets.only(bottom: 10),
        //             height: 40,
        //             width: double.infinity,
        //             decoration: BoxDecoration(
        //                 color: Colors.white,
        //                 borderRadius: BorderRadius.circular(10)),
        //             child: Center(
        //               child: Padding(
        //                 padding: const EdgeInsets.symmetric(
        //                     horizontal: 10, vertical: 10),
        //                 child: Row(
        //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //                   children: const [
        //                     Text(
        //                       'Search here',
        //                       style: TextStyle(
        //                           fontSize: 16,
        //                           fontWeight: FontWeight.bold,
        //                           color: Colors.grey),
        //                     ),
        //                     Icon(
        //                       Icons.search,
        //                       color: Colors.grey,
        //                     ),
        //                   ],
        //                 ),
        //               ),
        //             ),
        //           ),
        //         ),
        //       ),
        //       preferredSize: Size.fromHeight(40)),
        //   actions: [
        //     IconButton(
        //         icon: Icon(Icons.notifications),
        //         onPressed: () {
        //           Get.to(NotificationScreen());
        //         }),
        //     SizedBox(
        //       width: 10,
        //     ),
        //   ],
        // ),
        body:
            ListView(padding: EdgeInsets.symmetric(horizontal: 10), children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Hi ${box2.read('name')}", style: Texttheme.subTitle
                    // .copyWith(color: AppColor.accentWhite),
                    ),
                Text(greeting(), style: Texttheme.title
                    // .copyWith(color: AppColor.accentWhite),
                    )
              ],
            ),
          ),
          buildHomeCarousel(),
          buildCategoriesdata(),
          Container(
            height: 270,
            width: double.infinity,
            child: latestproduct(),
          ),
          Container(
            height: 270,
            width: double.infinity,
            child: dailyneedsproduct(),
          ),
          buildBrandsdata(),
          Container(
              height: 270,
              width: double.infinity,
              child: buildfeaturedproduct()),
          Container(
              height: 270,
              width: double.infinity,
              child: buildUpSellingproduct()),
          Container(
            height: 270,
            width: double.infinity,
            child: builddiscountedproduct(),
          ),
          Container(
            height: 100,
            width: double.infinity,
          ),
        ]));
  }

  buildSelectCity() {
    return Obx(() {
      if (citycontrollerController.isCityLoading.value) {
        return Center(
          child: SpinKitThreeBounce(color: Colors.white),
        );
      } else {
        return Row(
          children: [
            Icon(Icons.location_on),
            Container(
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              width: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: DropdownButton(
                hint: Text('Select City'), // Not necessary for Option 1
                value: _selectedLocation,
                onChanged: (newValue) {
                  setState(() {
                    _selectedLocation = newValue.toString();
                    citycontrollerController.setcity(_selectedLocation);
                    Get.back();
                  });
                },
                items: citycontrollerController.citylist.value.city!
                    .map((location) {
                  return DropdownMenuItem(
                    child: Text(location.name!),
                    value: location.id.toString(),
                  );
                }).toList(),
              ),
            ),
          ],
        );
      }
    });
  }
}
