// To parse this JSON data, do
//
//     final getBannersResponse = getBannersResponseFromJson(jsonString);

import 'dart:convert';

List<GetBannersResponse> getBannersResponseFromJson(String str) => List<GetBannersResponse>.from(json.decode(str).map((x) => GetBannersResponse.fromJson(x)));

String getBannersResponseToJson(List<GetBannersResponse> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class GetBannersResponse {
    GetBannersResponse({
        this.id,
        this.title,
        this.image,
        this.productId,
        this.categoryId,
    });

    int? id;
    String? title;
    String? image;
    dynamic productId;
    int? categoryId;

    factory GetBannersResponse.fromJson(Map<String, dynamic> json) => GetBannersResponse(
        id: json["id"] == null ? null : json["id"],
        title: json["title"] == null ? null : json["title"],
        image: json["image"] == null ? null : json["image"],
        productId: json["product_id"],
        categoryId: json["category_id"] == null ? null : json["category_id"],
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "title": title == null ? null : title,
        "image": image == null ? null : image,
        "product_id": productId,
        "category_id": categoryId == null ? null : categoryId,
    };
}
