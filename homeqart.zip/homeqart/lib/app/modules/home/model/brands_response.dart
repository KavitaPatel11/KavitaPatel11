// To parse this JSON data, do
//
//     final brandResponse = brandResponseFromJson(jsonString);

import 'dart:convert';

BrandResponse brandResponseFromJson(String str) =>
    BrandResponse.fromJson(json.decode(str));

String brandResponseToJson(BrandResponse data) => json.encode(data.toJson());

class BrandResponse {
  BrandResponse({
    this.totalSize,
    this.totalPages,
    this.limit,
    this.offset,
    this.brands,
  });

  int? totalSize;
  int? totalPages;
  String? limit;
  String? offset;
  List<Brand>? brands;

  factory BrandResponse.fromJson(Map<String, dynamic> json) => BrandResponse(
        totalSize: json["total_size"] == null ? null : json["total_size"],
        totalPages: json["total_pages"] == null ? null : json["total_pages"],
        limit: json["limit"] == null ? null : json["limit"],
        offset: json["offset"] == null ? null : json["offset"],
        brands: json["brands"] == null
            ? null
            : List<Brand>.from(json["brands"].map((x) => Brand.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "total_size": totalSize == null ? null : totalSize,
        "total_pages": totalPages == null ? null : totalPages,
        "limit": limit == null ? null : limit,
        "offset": offset == null ? null : offset,
        "brands": brands == null
            ? null
            : List<dynamic>.from(brands!.map((x) => x.toJson())),
      };
}

class Brand {
  Brand({
    this.id,
    this.name,
    this.image,
    this.banner,
  });

  int? id;
  String? name;
  String? image;
  String? banner;

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        image: json["image"] == null ? null : json["image"],
        banner: json["banner"] == null ? null : json["banner"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "image": image == null ? null : image,
        "banner": banner == null ? null : banner,
      };
}
