// To parse this JSON data, do
//
//     final latestProductModel = latestProductModelFromJson(jsonString);

import 'dart:convert';

LatestProductModel latestProductModelFromJson(String str) =>
    LatestProductModel.fromJson(json.decode(str));

String latestProductModelToJson(LatestProductModel data) =>
    json.encode(data.toJson());

class LatestProductModel {
  LatestProductModel({
    this.totalSize,
    this.limit,
    this.offset,
    this.products,
  });

  int? totalSize;
  dynamic limit;
  dynamic offset;
  List<Product>? products;

  factory LatestProductModel.fromJson(Map<String, dynamic> json) =>
      LatestProductModel(
        totalSize: json["total_size"] == null ? null : json["total_size"],
        limit: json["limit"],
        offset: json["offset"],
        products: json["products"] == null
            ? null
            : List<Product>.from(
                json["products"].map((x) => Product.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "total_size": totalSize == null ? null : totalSize,
        "limit": limit,
        "offset": offset,
        "products": products == null
            ? null
            : List<dynamic>.from(products!.map((x) => x.toJson())),
      };
}

class Product {
  Product({
    this.id,
    this.brandId,
    this.name,
    this.description,
    this.image,
    this.price,
    this.unit,
    this.sellingPrice,
    this.offAmount,
    this.wishlistCount,
  });

  int? id;
  int? brandId;

  String? name;
  String? description;
  List<String>? image;
  double? price;

  String? unit;

  int? sellingPrice;
  int? offAmount;
  int? wishlistCount;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"] == null ? null : json["id"],
        brandId: json["brand_id"] == null ? null : json["brand_id"],
        name: json["name"] == null ? null : json["name"],
        description: json["description"] == null ? null : json["description"],
        image: json["image"] == null
            ? null
            : List<String>.from(json["image"].map((x) => x)),
        price: json["price"] == null ? null : json["price"].toDouble(),
        unit: json["unit"] == null ? null : json["unit"],
        sellingPrice:
            json["selling_price"] == null ? null : json["selling_price"],
        offAmount: json["off_amount"] == null ? null : json["off_amount"],
        wishlistCount:
            json["wishlist_count"] == null ? null : json["wishlist_count"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "brand_id": brandId == null ? null : brandId,
        "name": name == null ? null : name,
        "description": description == null ? null : description,
        "image":
            image == null ? null : List<dynamic>.from(image!.map((x) => x)),
        "price": price == null ? null : price,
        "unit": unit == null ? null : unit,
        "selling_price": sellingPrice == null ? null : sellingPrice,
        "off_amount": offAmount == null ? null : offAmount,
        "wishlist_count": wishlistCount == null ? null : wishlistCount,
      };
}

enum Type { PERCENT, AMOUNT }

final typeValues = EnumValues({"amount": Type.AMOUNT, "percent": Type.PERCENT});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
