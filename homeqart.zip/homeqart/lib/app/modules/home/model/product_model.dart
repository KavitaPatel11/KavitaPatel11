// To parse this JSON data, do
//
//     final productModel = productModelFromJson(jsonString);

import 'dart:convert';

ProductModel productModelFromJson(String str) =>
    ProductModel.fromJson(json.decode(str));

String productModelToJson(ProductModel data) => json.encode(data.toJson());

class ProductModel {
  ProductModel({
    this.totalSize,
    this.totalPages,
    this.limit,
    this.offset,
    this.products,
  });

  int? totalSize;
  int? totalPages;
  String? limit;
  String? offset;
  List<Product>? products;

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
        totalSize: json["total_size"] == null ? null : json["total_size"],
        totalPages: json["total_pages"] == null ? null : json["total_pages"],
        limit: json["limit"] == null ? null : json["limit"],
        offset: json["offset"] == null ? null : json["offset"],
        products: json["products"] == null
            ? null
            : List<Product>.from(
                json["products"].map((x) => Product.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "total_size": totalSize == null ? null : totalSize,
        "total_pages": totalPages == null ? null : totalPages,
        "limit": limit == null ? null : limit,
        "offset": offset == null ? null : offset,
        "products": products == null
            ? null
            : List<dynamic>.from(products!.map((x) => x.toJson())),
      };
}

class Product {
  Product({
    this.id,
    this.name,
    this.unit,
    this.image,
    this.price,
    this.sellingPrice,
    this.offAmount,
  });

  int? id;
  String? name;
  String? unit;
  List<String>? image;
  double? price;
  int? sellingPrice;
  int? offAmount;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        unit: json["unit"] == null ? null : json["unit"],
        image: json["image"] == null
            ? null
            : List<String>.from(json["image"].map((x) => x)),
        price: json["price"] == null ? null : json["price"].toDouble(),
        sellingPrice:
            json["selling_price"] == null ? null : json["selling_price"],
        offAmount: json["off_amount"] == null ? null : json["off_amount"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "unit": unit == null ? null : unit,
        "image":
            image == null ? null : List<dynamic>.from(image!.map((x) => x)),
        "price": price == null ? null : price,
        "selling_price": sellingPrice == null ? null : sellingPrice,
        "off_amount": offAmount == null ? null : offAmount,
      };
}
