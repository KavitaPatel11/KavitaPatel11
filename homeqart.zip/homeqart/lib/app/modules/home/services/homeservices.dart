// ignore_for_file: non_constant_identifier_names

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/auth_city_modal.dart';
import 'package:homeqart/app/modules/common_model/set_city_modal.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';
import 'package:homeqart/app/modules/home/model/get_banners_response.dart';
import 'package:homeqart/app/modules/home/model/latestproductdata.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:http/http.dart' as http;

class HomePageRemoteServices {
  static var client = http.Client();

  static Future<List<GetBannersResponse>?> fetchbanners() async {
    print("============ banners api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/banners'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("banners api successs");
      var jsonString = response.body;
      print("banners======= $jsonString");
      print(jsonString);
      return getBannersResponseFromJson(jsonString);
    } else {
      print(" banners api Unsuccesssfull..");
      return null;
    }
  }

  static Future<LatestProductModel?> fetchlatestproduct() async {
    print("============ banners api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/latest'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("products/latest api successs");
      var jsonString = response.body;
      print("products/latest $jsonString");
      print(jsonString);
      return latestProductModelFromJson(jsonString);
    } else {
      print(" products/latest api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetchdaily_needs_products() async {
    print("============ daily-needs api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/daily-needs'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("products/daily-needs api successs");
      var jsonString = response.body;
      print("products/daily-needs $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print(" products/daily-needs api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetchfeatured_products() async {
    print("============ featured api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/featured'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("featured api successs");
      var jsonString = response.body;
      print("featured==== $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print("featured api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetch_up_selling_products() async {
    print("============ up-selling api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/up-selling'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("up-selling api successs");
      var jsonString = response.body;
      print("up-selling==== $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print("up-selling api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetch_discounted_products() async {
    print("============ up-selling api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/discounted'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("up-selling api successs");
      var jsonString = response.body;
      print("up-selling==== $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print("up-selling api Unsuccesssfull..");
      return null;
    }
  }

  static Future<List<CategoryModel>?> fetch_categories() async {
    print("============categories api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/categories/top'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("categories api successs");
      var jsonString = response.body;
      print("===================================categories==== $jsonString");
      print(jsonString);
      return categoryModelFromJson(jsonString);
    } else {
      print("categories api Unsuccesssfull..");
      return null;
    }
  }

  static Future<BrandResponse?> fetch_brands() async {
    print("============ brands api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/brands/top?limit=15&offset=1'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("brands api successs");
      var jsonString = response.body;
      print("brands==== $jsonString");
      print(jsonString);

      return brandResponseFromJson(jsonString);
    } else {
      print("brands api Unsuccesssfull..");
      return null;
    }
  }

  static Future<AvailableCityModal?> fetchcity() async {
    print("============ city api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/auth/op_city'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("city api successs");
      var jsonString = response.body;
      print("city==== $jsonString");
      print(jsonString);
      return availableCityModalFromJson(jsonString);
    } else {
      print("city api Unsuccesssfull..");
      return null;
    }
  }

  static Future<SetCityModal?> postCity(city_id) async {
    print("============ set city api calling=======");

    var response = await client.post(Uri.parse('$baseUrl/api/v1/auth/set_city'),
        headers: {'Authorization': 'Bearer ${box2.read("logintoken")}'},
        body: {"city_id": city_id});
    if (response.statusCode == 200) {
      print("set city api successs");
      var jsonString = response.body;
      print("set city==== $jsonString");
      print(jsonString);
      return setCityModalFromJson(jsonString);
    } else {
      print("set city api Unsuccesssfull..");
      return null;
    }
  }
}
