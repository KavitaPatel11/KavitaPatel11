import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/controllers/categorycontroller_controller.dart';

import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/search_products/search_category_card.dart';
import 'package:homeqart/app/modules/search_products/serchlisting.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/category_card.dart';
import 'package:homeqart/components/product_card.dart';
import 'package:homeqart/services/base_client.dart';

import '../categories/views/sub_category_card.dart';
import '../common_model/all_categories_response.dart';
import '../home/model/category_model.dart';
import 'all_category_list.dart';
import 'model/search_product_model.dart';
import 'search_product_card.dart';

class Filter extends StatefulWidget {
  const Filter({
    Key? key,
  }) : super(key: key);

  @override
  _FilterState createState() => _FilterState();
}

class Debouncer {
  int? milliseconds;
  VoidCallback? action;
  Timer? timer;

  run(VoidCallback action) {
    if (null != timer) {
      timer!.cancel();
    }
    timer = Timer(
      Duration(milliseconds: Duration.millisecondsPerSecond),
      action,
    );
  }
}

class _FilterState extends State<Filter> {
  final CategorycontrollerController categorycontrollerController =
      Get.put(CategorycontrollerController());
  final _debouncer = Debouncer();
  BaseClient baseClient = BaseClient();

  SearchProductModel? productModel;
  SearchProductModel? productModelcount;
  // final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _searchController = TextEditingController();
  bool isloading = true;
  bool isCloading = true;

  int currentPage = 1;
  late int totalPages;

  allSearchProducts() async {
    isCloading = true;
    final apiResponse = await baseClient.get(false, "$baseUrl",
        "/api/v1/products/search?name=${_searchController.text}");
    // print(apiResponse);
    productModelcount = searchProductModelFromJson(apiResponse);
    isCloading = false;
    setState(() {});
  }

  onTextFieldChange() async {
    isloading = true;
    final apiResponse = await baseClient.get(false, "$baseUrl",
        "/api/v1/products/search?name=${_searchController.text}&limit=8&offset=$currentPage");
    // print(apiResponse);
    productModel = searchProductModelFromJson(apiResponse);
    isloading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,zzzz

      appBar: AppBar(
        backgroundColor: AppColor.primaryColor,
        title: Container(
          width: double.infinity,
          height: 40,
          decoration: BoxDecoration(
            color: AppColor.accentWhite,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            // textInputAction: TextInputAction.search,
            controller: _searchController,
            decoration: InputDecoration(
              hintText: "What are you looking for",
              border: InputBorder.none,
              suffixIcon: IconButton(
                  onPressed: () {
                    setState(() {
                      onTextFieldChange();
                      allSearchProducts();
                    });
                  },
                  icon: const Icon(Icons.search)),
              hintStyle:
                  Texttheme.subTitle.copyWith(color: AppColor.accentLightGrey),
              contentPadding: const EdgeInsets.only(left: 10, top: 5),
            ),
            onChanged: (String) {
              _debouncer.run(() {
                setState(() {
                  onTextFieldChange();
                  allSearchProducts();
                });
              });
            },
          ),
        ),
      ),
      body: productModel == null
          ? buildCategoriesdata()
          : productModel!.products!.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 3.5,
                        ),
                        Text("Your search--"),
                        SizedBox(
                          height: 3.5,
                        ),
                        Text(
                          "${_searchController.text}..",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 22),
                        ),
                        SizedBox(
                          height: 3.5,
                        ),
                        Text("did not match any documents"),
                        SizedBox(
                          height: 3.5,
                        ),
                        Text("Try different keywords"),
                        SizedBox(
                          height: 3.5,
                        ),
                        Text("Try more general keywords."),
                      ],
                    ),
                  ),
                )
              : isloading
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : Column(
                      children: [
                        Container(
                          height: 30,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Products"),
                                isCloading
                                    ? SizedBox()
                                    : productModelcount!.products!.length ==
                                            null
                                        ? SizedBox()
                                        : productModelcount!.products!.length >=
                                                15
                                            ? TextButton(
                                                onPressed: (() {
                                                  Get.to(() => ProductFilter(),
                                                      arguments: [
                                                        {
                                                          'text':
                                                              "${_searchController.text}"
                                                        }
                                                      ],
                                                      preventDuplicates: false);
                                                }),
                                                style: ButtonStyle(
                                                  shape: MaterialStateProperty
                                                      .all(RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      10.0))),
                                                ),
                                                child: const Text("View more"),
                                              )
                                            : SizedBox()
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListView.builder(
                            // shrinkWrap: true,
                            // physics: const NeverScrollableScrollPhysics(),
                            itemCount: productModel!.products!.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return SearchProductCard(
                                id: productModel!.products![index].id!,
                                image: "$baseUrl/storage/app/public/product/" +
                                    productModel!.products![index].image![0],
                                name: productModel!.products![index].name!,
                              );
                            },
                          ),
                        ),
                        productModel!.category!.length == 0
                            ? SizedBox()
                            : Container(
                                height: 30,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text("Category"),
                                      productModelcount!.category!.length > 8
                                          ? TextButton(
                                              onPressed: (() {
                                                Get.to(() => CategoryFilter(),
                                                    arguments: [
                                                      {
                                                        'text':
                                                            "${_searchController.text}"
                                                      }
                                                    ],
                                                    preventDuplicates: false);
                                              }),
                                              style: ButtonStyle(
                                                shape:
                                                    MaterialStateProperty.all(
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0))),
                                              ),
                                              child: const Text("View more"),
                                            )
                                          : SizedBox()
                                    ],
                                  ),
                                ),
                              ),
                        productModel!.category!.length == 0
                            ? SizedBox()
                            : Expanded(
                                child: ListView.builder(
                                  // shrinkWrap: true,
                                  // physics: const NeverScrollableScrollPhysics(),
                                  itemCount: productModel!.category!.length,
                                  itemBuilder: (BuildContext ctx, index) {
                                    return SearchCategoryCard(
                                      id: productModel!.category![index].id!,
                                      image:
                                          "$baseUrl/storage/app/public/category/${productModel!.category![index].image!}",
                                      name:
                                          productModel!.category![index].name!,
                                      onPress: () {
                                        Get.to(ShowAllProductsView(),
                                            arguments: [
                                              {
                                                'id': productModel!
                                                    .category![index].id
                                              },
                                              {
                                                'name': productModel!
                                                    .category![index].name
                                              },
                                              {
                                                'banner': productModel!
                                                    .category![index].image
                                              },
                                            ]);
                                      },
                                    );
                                  },
                                ),
                              ),
                      ],
                    ),
    );
  }

  buildCategoriesdata() {
    return SizedBox(
      child: Obx(() {
        if (categorycontrollerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else if (categorycontrollerController.categorieslist.isEmpty) {
          return const Center(
            child: Text("Nothing to show"),
          );
        } else {
          return SizedBox(
            height: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: GridView.builder(
                scrollDirection: Axis.vertical,
                itemCount:
                    categorycontrollerController.categorieslist.length == null
                        ? 0
                        : categorycontrollerController.categorieslist.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  mainAxisExtent: 130,
                ),
                itemBuilder: (BuildContext context, int index) {
                  return CategoryCard(
                    onTap: () {
                      Get.to(ShowAllProductsView(), arguments: [
                        {
                          'id': categorycontrollerController
                              .categorieslist[index].id
                        },
                        {
                          'name': categorycontrollerController
                              .categorieslist[index].name
                        },
                        {
                          'banner': categorycontrollerController
                              .categorieslist[index].banner
                        }
                      ]);
                    },
                    name: categorycontrollerController
                        .categorieslist[index].name
                        .toString(),
                    image: categorycontrollerController
                        .categorieslist[index].mobileImage
                        .toString(),
                    imageheight: 90,
                  );
                },
              ),
            ),
          );
        }
      }),
    );
  }
}
