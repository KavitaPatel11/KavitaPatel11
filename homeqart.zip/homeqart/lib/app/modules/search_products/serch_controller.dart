import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';

import 'package:homeqart/app/modules/showAllProducts/model/services.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:flutter/material.dart';

class SearchProductController extends GetxController {
  BaseClient baseClient = BaseClient();
  var isLoading = true.obs;
  var allproductlist = ProductModel().obs;
  final searchController = TextEditingController();
  int currentPage = 0;
  var totalPages;
  final RefreshController refreshController =
      RefreshController(initialRefresh: false);

  @override
  void onInit() async {
    searchController.text = "";
    searchproducts();
    super.onInit();
  }

  Future<bool> searchproducts({
    bool isRefresh = false,
  }) async {
    print("searchproducts==");

    if (isRefresh) {
      currentPage = 0;
    } else {
      if (currentPage == totalPages) {
        refreshController.loadNoData();
        return false;
      }
    }

    final apiResponse = await baseClient.get(false, "$baseUrl",
        "/api/v1/products/search?name=${searchController.text}&limit=30&offset=$currentPage");

    if (apiResponse != null) {
      print("search==$apiResponse");
      var result = apiResponse;
      if (isRefresh) {
        allproductlist.value = result;
        print("search3==$result");
      } else {
        allproductlist.value = result;
      }

      print(allproductlist);
      currentPage++;
      totalPages = (allproductlist.value.totalPages! + 1).toInt();
      print(
          "search.products!.length==${allproductlist.value.products!.length}");
      // print((brandResponse.length / 15).toInt());
      // print(" brandresponse====== $brandResponse");
      isLoading(false);

      return true;
    } else {
      print("search6==$apiResponse");
      return false;
    }
  }

  bool nodata() {
    refreshController.loadNoData();
    return false;
  }
  // Future<void> allproducts() async {
  //   isLoading(true);
  //   final usersData = await ShowAllProductRemoteServices.fetchAllProducts(getArgumentData[1]['path'], page);
  //   if (usersData!.products!.isEmpty) {
  //     _lastPage.value = true;
  //     print("filter product empty");
  //   }

  //   allproductlist.value=usersData;
  //     print("filter product list");
  //     isLoading(false);

  // }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
