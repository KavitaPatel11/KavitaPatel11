import 'package:get/get.dart';
import 'package:homeqart/app/modules/search_products/serch_controller.dart';

class SearchBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SearchProductController>(
      () => SearchProductController(),
    );
  }
}
