import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/controllers/categorycontroller_controller.dart';

import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/search_products/model/search_product_model.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/category_card.dart';
import 'package:homeqart/components/product_card.dart';
import 'package:homeqart/services/base_client.dart';

class ProductFilter extends StatefulWidget {
  const ProductFilter({
    Key? key,
  }) : super(key: key);

  @override
  _ProductFilterState createState() => _ProductFilterState();
}

class Debouncer {
  int? milliseconds;
  VoidCallback? action;
  Timer? timer;

  run(VoidCallback action) {
    if (null != timer) {
      timer!.cancel();
    }
    timer = Timer(
      Duration(milliseconds: Duration.millisecondsPerSecond),
      action,
    );
  }
}

class _ProductFilterState extends State<ProductFilter> {
  final CategorycontrollerController categorycontrollerController =
      Get.put(CategorycontrollerController());
  final _debouncer = Debouncer();
  BaseClient baseClient = BaseClient();
  SearchProductModel? productModel;
  // final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _searchController = TextEditingController();
  bool isloading = true;
  int currentPage = 1;
  late int totalPages;
  var argu = Get.arguments;
  onTextFieldChange() async {
    isloading = true;
    final apiResponse = await baseClient.get(false, "$baseUrl",
        "/api/v1/products/search?name=${argu[0]['text']}&limit=16&offset=$currentPage");
    // print(apiResponse);
    productModel = searchProductModelFromJson(apiResponse);
    isloading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    onTextFieldChange();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,zzzz

      floatingActionButton: isloading
          ? SizedBox()
          : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              if (currentPage > 1)
                ClipOval(
                  child: Material(
                    color: Colors.black12, // Button color
                    child: InkWell(
                      splashColor: Colors.red, // Splash color
                      onTap: () {
                        setState(() {
                          currentPage--;
                          onTextFieldChange();
                        });
                      },
                      child: SizedBox(
                        width: 56,
                        height: 56,
                        child: Icon(
                          Icons.navigate_before_rounded,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                ),
              if (currentPage < productModel!.totalPages!.toInt())
                ClipOval(
                  child: Material(
                    color: Colors.black12, // Button color
                    child: InkWell(
                      splashColor: Colors.red, // Splash color
                      onTap: () {
                        setState(() {
                          currentPage++;
                          onTextFieldChange();
                        });
                      },
                      child: SizedBox(
                        width: 56,
                        height: 56,
                        child: Icon(
                          Icons.navigate_next_rounded,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                )
            ]),

      appBar: CustomAppBar(argu[0]['text']),
      body: isloading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 10,
                    right: 10,
                    top: 10,
                  ),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 200,
                      mainAxisExtent: 220,
                      childAspectRatio: 2 / 2,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: productModel!.products!.length,
                    itemBuilder: (BuildContext ctx, index) {
                      return ProductCard(
                        id: productModel!.products![index].id!,
                        image: "$baseUrl/storage/app/public/product/" +
                            productModel!.products![index].image![0],
                        name: productModel!.products![index].name!,
                        mrp: "${productModel!.products![index].price}",
                        offAmount: productModel!.products![index].offAmount!
                            .toString(),
                        sellingPrice: productModel!
                            .products![index].sellingPrice!
                            .toString(),
                        unit:
                            '${productModel!.products![index].unit!.toString()}',
                      );
                    },
                  ),
                ),
              ),
            ),
    );
  }

  buildCategoriesdata() {
    return SizedBox(
      child: Obx(() {
        if (categorycontrollerController.isLoading.value) {
          return const Center(
            child: SpinKitThreeBounce(color: Colors.white),
          );
        } else if (categorycontrollerController.categorieslist.isEmpty) {
          return const Center(
            child: Text("Nothing to show"),
          );
        } else {
          return SizedBox(
            height: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: GridView.builder(
                scrollDirection: Axis.vertical,
                itemCount:
                    categorycontrollerController.categorieslist.length == null
                        ? 0
                        : categorycontrollerController.categorieslist.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  mainAxisExtent: 130,
                ),
                itemBuilder: (BuildContext context, int index) {
                  return CategoryCard(
                    onTap: () {
                      Get.to(ShowAllProductsView(), arguments: [
                        {
                          'id': categorycontrollerController
                              .categorieslist[index].id
                        },
                        {
                          'name': categorycontrollerController
                              .categorieslist[index].name
                        },
                        {
                          'banner': categorycontrollerController
                              .categorieslist[index].banner
                        }
                      ]);
                    },
                    name: categorycontrollerController
                        .categorieslist[index].name
                        .toString(),
                    image: categorycontrollerController
                        .categorieslist[index].mobileImage
                        .toString(),
                    imageheight: 90,
                  );
                },
              ),
            ),
          );
        }
      }),
    );
  }
}
