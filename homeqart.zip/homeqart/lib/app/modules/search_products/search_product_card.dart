import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/services/base_client.dart';

class SearchProductCard extends StatefulWidget {
  final int id;
  final String name;
  final String image;

  const SearchProductCard({
    Key? key,
    required this.id,
    required this.image,
    required this.name,
  }) : super(key: key);

  @override
  _SearchProductCardState createState() => _SearchProductCardState();
}

class _SearchProductCardState extends State<SearchProductCard> {
  BaseClient baseClient = BaseClient();
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
          onTap: (() {
            print("${widget.id}");
            Get.to(() => ProductdetailView(),
                arguments: widget.id, preventDuplicates: false);
          }),
          leading: widget.image.toString() == null
              ? Container()
              : FadeInImage(
                  height: 40,
                  width: 60,
                  imageErrorBuilder: (context, error, stackTrace) {
                    return SvgPicture.asset("assets/icons/Error.svg");
                  },
                  placeholder: AssetImage("assets/images/placeholder.jpeg"),
                  image: NetworkImage(
                    widget.image.toString(),
                  )),
          title: SizedBox(
            height: 20,
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Center(
                child: Text(widget.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.start,
                    style: Texttheme.bodyText1),
              ),
            ),
          ), // for Right
          trailing: Icon(Icons.arrow_right_rounded) // for Left
          ),
    );
  }
}
