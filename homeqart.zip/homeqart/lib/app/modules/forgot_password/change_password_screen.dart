import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/login/views/login_view.dart';
import 'package:homeqart/app/modules/register/register_model.dart';
import 'package:homeqart/app/modules/register/views/register_view.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:http/http.dart' as http;

import '../../theme.dart';
import '../splash_screen/views/splash_screen_view.dart';

class ChangePasswordScreen extends StatefulWidget {
  final String userId;
  const ChangePasswordScreen({Key? key, required this.userId})
      : super(key: key);

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  RegisterUser? registerUser;
  String? password;
  String? otp;
  String? confirmPassword;
  BaseClient baseClient = BaseClient();
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("Change password"),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * .07),
                Icon(
                  Icons.lock,
                  color: AppColor.accentLightGrey,
                  size: 100,
                ),
                const SizedBox(
                  height: 15,
                ),
                TextFormField(
                  keyboardType: TextInputType.text,
                  onSaved: (newValue) => otp = newValue,
                  maxLength: 6,
                  decoration: InputDecoration(
                      hintText: '6 Digit OTP',
                      border: InputBorder.none,
                      counterText: "",
                      filled: true,
                      fillColor: AppColor.accentWhite,
                      prefixIcon: const Icon(Icons.security)),
                  validator: (text) {
                    if (text!.isEmpty) {
                      return 'OTP is required*';
                    } else if (text.length < 6) {
                      return "Please enter valid 6 Digit otp";
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  keyboardType: TextInputType.text,
                  onSaved: (newValue) => password = newValue,
                  obscureText: true,
                  decoration: InputDecoration(
                      hintText: 'Password',
                      border: InputBorder.none,
                      filled: true,
                      fillColor: AppColor.accentWhite,
                      prefixIcon: const Icon(Icons.lock)),
                  validator: (text) {
                    if (text!.isEmpty) {
                      return 'Password is required*';
                    } else if (text.length < 8) {
                      return "Password must contain atleast 8 characters";
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  keyboardType: TextInputType.text,
                  obscureText: true,
                  onSaved: (newValue) => confirmPassword = newValue,
                  decoration: InputDecoration(
                      hintText: 'Confirm password',
                      border: InputBorder.none,
                      filled: true,
                      fillColor: AppColor.accentWhite,
                      prefixIcon: const Icon(Icons.lock)),
                  validator: (text) {
                    if (text!.isEmpty) {
                      return 'Confirm password is Required*';
                    }
                    if (password != confirmPassword) {
                      return "Password and confirm password doesn't match";
                    }
                    if (text.length < 8) {
                      return "Password must contain atleast 8 characters";
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 15,
                ),
                DefaultButton(
                  buttonText: "Continue",
                  press: () async {
                    formKey.currentState!.save();
                    if (formKey.currentState!.validate()) {
                      Map<String, dynamic> dataBody = {
                        "user_id": widget.userId,
                        "otp_code": otp,
                        "password": password,
                      };
                      print(dataBody);
                      var dataToSend = json.encode(dataBody);

                      var response = await http.post(
                          Uri.parse(
                              "$baseUrl/api/v1/auth/password/confirm_reset"),
                          headers: <String, String>{
                            'Content-Type': 'application/json; charset=UTF-8',
                          },
                          body: dataToSend);
                      print(response);
                      print(response.body);
                      print(response.statusCode);

                      if (response.statusCode == 200) {
                        Map<String, dynamic> responseData =
                            jsonDecode(response.body);
                        if (responseData['message'] ==
                            "Successfully logged in") {
                          box2.write(
                              "logintoken", responseData['access_token']);
                          box2.write("result", responseData['result']);
                          box2.write("name", responseData['user']['name']);
                          box2.write("email", responseData['user']['email']);
                          box2.write("id", responseData['user']['id']);
                          box2.write("phone", responseData['user']['phone']);
                          box2.write("image", responseData['user']['image']);
                          box2.write("provider_id",
                              responseData['user']['provider_id']);
                          box2.write(
                              "verified", responseData['user']['verified']);
                          box2.write(
                              "is_prime", responseData['user']['is_prime']);

                          print(
                              "=================logintokn======${box2.read("logintoken")}================");
                          print(
                              "=================verified======${box2.read("verified")}================");

                          // Fluttertoast.showToast(
                          //   msg: "Your password reset done.",
                          //   toastLength: Toast.LENGTH_SHORT,
                          //   gravity: ToastGravity.SNACKBAR,
                          //   timeInSecForIosWeb: 2,
                          //   backgroundColor: AppColor.primaryColor,
                          //   textColor: Colors.white,
                          // );

                          Get.snackbar(
                            "Successfully ",
                            "Logged in...",
                            backgroundColor: Colors.green,
                            snackPosition: SnackPosition.BOTTOM,
                            borderRadius: 10,
                            borderWidth: 2,
                            colorText: Colors.white,
                          );

                          Get.offAll(() => SplashScreenView());
                        } else {
                          Fluttertoast.showToast(
                            msg: "Invalid OTP",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.SNACKBAR,
                            timeInSecForIosWeb: 2,
                            backgroundColor: AppColor.neturalOrange,
                            textColor: Colors.white,
                          );
                        }
                      } else {
                        Fluttertoast.showToast(
                          msg: "Invalid OTP",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.SNACKBAR,
                          timeInSecForIosWeb: 2,
                          backgroundColor: AppColor.neturalOrange,
                          textColor: Colors.white,
                        );
                      }
                    }
                  },
                  buttonColor: AppColor.primaryColor,
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }
}
