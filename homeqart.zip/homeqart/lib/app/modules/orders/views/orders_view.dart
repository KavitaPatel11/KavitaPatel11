import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/order_model.dart';
import 'package:homeqart/app/modules/myorders_detail/views/myorders_detail_view.dart';
import 'package:homeqart/app/modules/orders/components/order_tile.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/services/base_client.dart';

class OrdersView extends StatefulWidget {
  const OrdersView({Key? key}) : super(key: key);

  @override
  _OrdersViewState createState() => _OrdersViewState();
}

class _OrdersViewState extends State<OrdersView> {
  bool isLoading = true;
  List<OrderModel> orderModel = [];
  BaseClient baseClient = BaseClient();

  getOrderList() async {
    final apiResponse =
        await baseClient.get(true, "$baseUrl", "/api/v1/customer/order/list");
    orderModel = orderModelFromJson(apiResponse);
    isLoading = false;
    setState(() {});
  }

  @override
  void initState() {
    getOrderList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.accentBgColor,
      appBar: CustomAppBar("My Orders"),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : orderModel.isEmpty
              ? const Center(
                  child: Text(
                      "You have not ordered anything yet please order someting"),
                )
              : SafeArea(
                  child: SingleChildScrollView(
                  child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 10),
                      child: ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: orderModel.length,
                          itemBuilder: (_, i) {
                            return OrderTile(
                              productTitle: orderModel[i].code!.isEmpty
                                  ? ""
                                  : orderModel[i].code.toString(),
                              expectedDeleveryDate: orderModel[i].deliveryDate!,
                              status: orderModel[i].orderStatus!.isEmpty
                                  ? ""
                                  : orderModel[i].orderStatus.toString(),
                              orderAmount: orderModel[i].orderAmount!.isNaN
                                  ? ""
                                  : orderModel[i].orderAmount.toString(),
                              orderNote: orderModel[i].orderNote == null
                                  ? ""
                                  : orderModel[i].orderNote.toString(),
                              paymentStatus: orderModel[i].paymentStatus == null
                                  ? ""
                                  : orderModel[i].paymentStatus.toString(),
                              paymentType: orderModel[i].paymentMethod == null
                                  ? ""
                                  : orderModel[i].paymentMethod.toString(),
                              onPress: () {
                                Get.to(MyordersDetailView(), arguments: [
                                  {
                                    "id": orderModel[i].id == null
                                        ? 0
                                        : orderModel[i].id.toString(),
                                  },
                                  {
                                    "status": orderModel[i].orderStatus!.isEmpty
                                        ? ""
                                        : orderModel[i].orderStatus.toString()
                                  }
                                ]);
                              },
                            );
                          })),
                )),
    );
  }
}
