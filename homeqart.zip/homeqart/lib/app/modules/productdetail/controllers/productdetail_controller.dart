import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:get_storage/get_storage.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/productdetail/product_detail_model.dart';
import 'package:homeqart/app/modules/productdetail/product_detail_services.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/modules/shopping_cart/views/shopping_cart_view.dart';
import 'package:homeqart/app/theme.dart';
import 'package:http/http.dart' as http;


class ProductdetailController extends GetxController {
  var isLoading = true.obs;
  var isrelatedproductLoading = true.obs;
  var productdetail_data = ProductDetailModel().obs;
  var isDataReadingCompleted = false.obs;
  var orderid=Get.arguments;
  var box2=GetStorage();

  var relatedproductlist = ProductModel().obs;
  @override
  void onInit() {
    product_detail(Get.arguments);
    related_product(Get.arguments);
    super.onInit();
  }

  Future<void> product_detail(int orderid) async {
    
    try {
      isLoading(true);
      print("order_detail try block");
      print("get order id $orderid");
       print("=====order id================ $orderid");
      var productdetail =
          await ProductDetailRemoteServices.fetchproductdetail(orderid);
      print("========= $productdetail ======");
      if (productdetail != null) {
        print("order_detail inside controller");
        productdetail_data.value = productdetail;
      }
    } finally {
      isLoading(false);
     
    }
  }

  Future<void> related_product(int productid) async {
    try {
      isrelatedproductLoading(true);
      // // print("order_detail try block");
      // // print("get order id $productid");
      var relatedproduct =
          await ProductDetailRemoteServices.fetchrelatedproduct(productid);
      print("========= $relatedproduct ======");
      if (relatedproduct != null) {
        print("order_detail inside controller");
        relatedproductlist.value = relatedproduct;
      }
    } finally {
      isrelatedproductLoading(false);
    }
  }

  Future<void> addwishlist(int product_id) async {
    var isLoading = false.obs;
    print(
        "============product_id====================================================$product_id=====");
  
    Map data = {
      'product_id': '$product_id',
    };

    print(data);
     print(baseUrl);
    final http.Response response =
        await http.post(Uri.parse("$baseUrl/api/v1/customer/wishlist/add"),
            headers: <String, String>{
              
              'Authorization': 'Bearer ${box2.read("logintoken")}'
            },
            body: data);

    if (response.statusCode == 200) {
      print(response.body);
      print("status api success");
      isLoading(false);
     
      // Get.back();
      product_detail(product_id);
      Get.to(ProductdetailView());
    } else {
      print(response.body);
      print("status api un successfull");
      
      Get.back();
    }
  }

  Future<void> add_to_cart(int product_id) async {
    
    Map data = {
      'product_id': '$product_id',
    };
    print(data);
    final http.Response response =
        await http.post(Uri.parse("$baseUrl/api/v1/customer/cart/add"),
            headers: <String, String>{
              
              'Authorization': 'Bearer ${box2.read("logintoken")}'
            },
            body: data);

    if (response.statusCode == 200) {
      print(response.body);
      print("status api success");
      isLoading(false);
      Fluttertoast.showToast(
        msg: "Item added to your cart",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 2,
        backgroundColor: AppColor.primaryColor,
        textColor: Colors.white,
      );
      product_detail(product_id);
      Get.to(ProductdetailView());
    } else {
      print(response.body);
      print("status api un successfull");
      Get.snackbar(
        "Failed to",
        "Item added to your cart",
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.black,
      );
      Get.to(ProductdetailView());
    }
  }

  Future<void> buynow(int product_id) async {
    
    print(baseUrl);
    Map data = {
      'product_id': '$product_id',
    };
    print(data);
    final http.Response response =
        await http.post(Uri.parse("$baseUrl/api/v1/customer/cart/add"),
            headers: <String, String>{
         
              'Authorization': 'Bearer ${box2.read("logintoken")}'
            },
            body: data);

    if (response.statusCode == 200) {
      print(response.body);
      print("status api success");
      isLoading(false);
     

      Get.to(ShoppingCartView());
    } else {
      print(response.body);
      print("status api un successfull");
      
      Get.back();
    }
  }
}
