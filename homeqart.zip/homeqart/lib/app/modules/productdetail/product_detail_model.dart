// To parse this JSON data, do
//
//     final productDetailModel = productDetailModelFromJson(jsonString);

import 'dart:convert';

ProductDetailModel productDetailModelFromJson(String str) =>
    ProductDetailModel.fromJson(json.decode(str));

String productDetailModelToJson(ProductDetailModel data) =>
    json.encode(data.toJson());

class ProductDetailModel {
  ProductDetailModel({
    this.totalSize,
    this.limit,
    this.offset,
    this.products,
  });

  int? totalSize;
  dynamic limit;
  dynamic offset;
  Products? products;

  factory ProductDetailModel.fromJson(Map<String, dynamic> json) =>
      ProductDetailModel(
        totalSize: json["total_size"] == null ? null : json["total_size"],
        limit: json["limit"],
        offset: json["offset"],
        products: json["products"] == null
            ? null
            : Products.fromJson(json["products"]),
      );

  Map<String, dynamic> toJson() => {
        "total_size": totalSize == null ? null : totalSize,
        "limit": limit,
        "offset": offset,
        "products": products == null ? null : products!.toJson(),
      };
}

class Products {
  Products({
    this.id,
    this.name,
    this.description,
    this.totalStock,
    this.capacity,
    this.unit,
    this.image,
    this.price,
    this.sellingPrice,
    this.offAmount,
    this.wishlistCount,
    this.rating,
  });

  int? id;
  String? name;
  String? description;
  int? totalStock;
  double? capacity;
  String? unit;
  List<String>? image;
  int? price;
  int? sellingPrice;
  int? offAmount;
  int? wishlistCount;
  List<Rating>? rating;

  factory Products.fromJson(Map<String, dynamic> json) => Products(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        description: json["description"] == null ? null : json["description"],
        totalStock: json["total_stock"] == null ? null : json["total_stock"],
        capacity: json["capacity"] == null ? null : json["capacity"].toDouble(),
        unit: json["unit"] == null ? null : json["unit"],
        image: json["image"] == null
            ? null
            : List<String>.from(json["image"].map((x) => x)),
        price: json["price"] == null ? null : json["price"],
        sellingPrice:
            json["selling_price"] == null ? null : json["selling_price"],
        offAmount: json["off_amount"] == null ? null : json["off_amount"],
        wishlistCount:
            json["wishlist_count"] == null ? null : json["wishlist_count"],
        rating: json["rating"] == null
            ? null
            : List<Rating>.from(json["rating"].map((x) => Rating.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "description": description == null ? null : description,
        "total_stock": totalStock == null ? null : totalStock,
        "capacity": capacity == null ? null : capacity,
        "unit": unit == null ? null : unit,
        "image":
            image == null ? null : List<dynamic>.from(image!.map((x) => x)),
        "price": price == null ? null : price,
        "selling_price": sellingPrice == null ? null : sellingPrice,
        "off_amount": offAmount == null ? null : offAmount,
        "wishlist_count": wishlistCount == null ? null : wishlistCount,
        "rating": rating == null
            ? null
            : List<dynamic>.from(rating!.map((x) => x.toJson())),
      };
}

class Rating {
  Rating({
    this.average,
    this.productId,
  });

  String? average;
  int? productId;

  factory Rating.fromJson(Map<String, dynamic> json) => Rating(
        average: json["average"] == null ? null : json["average"],
        productId: json["product_id"] == null ? null : json["product_id"],
      );

  Map<String, dynamic> toJson() => {
        "average": average == null ? null : average,
        "product_id": productId == null ? null : productId,
      };
}
