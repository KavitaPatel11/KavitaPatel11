



import 'package:get_storage/get_storage.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/login/model/user_data_list.dart';
import 'package:homeqart/app/modules/productdetail/product_detail_model.dart';
import 'package:http/http.dart' as http;


class ProductDetailRemoteServices {
  static var client = http.Client();
  static var box2=GetStorage();

  static Future<ProductDetailModel?> fetchproductdetail(int productid, ) async {
     print("===token===${box2.read("logintoken")}======");
    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/details/${box2.read("id")}/$productid'),
      headers: {
        'Authorization': 'Bearer ${box2.read("logintoken")}',
      },
    );
    if (response.statusCode == 200) {
      print("orderDetailData api successs");
      var jsonString = response.body;
      print("orderDetailData $jsonString");
      print(jsonString);
      return productDetailModelFromJson(jsonString);
    } else {
      print("orderDetailData api Unsuccesssfull..");
      return null;
    }
  }


  static Future<ProductModel?> fetchrelatedproduct(int productid) async {
    print("============ orderDetailData api calling=======");
    
    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/products/related-products/$productid}'),
      headers: {
        'Authorization': 'Bearer ${box2.read("logintoken")}',
      },
    );
    if (response.statusCode == 200) {
      print("orderDetailData api successs");
      var jsonString = response.body;
      print("orderDetailData $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print("orderDetailData api Unsuccesssfull..");
      return null;
    }
  }
}
