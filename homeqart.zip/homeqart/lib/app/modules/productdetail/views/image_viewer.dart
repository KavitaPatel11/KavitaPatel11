import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:photo_view/photo_view.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

import '../../../constent.dart';
import '../../../theme.dart';

class ImageViewer extends StatelessWidget {
  ImageViewer({Key? key}) : super(key: key);
  var image = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          iconTheme: IconThemeData(color: AppColor.defaultBlackColor),
          leading: Padding(
            padding: const EdgeInsets.all(5),
            child: CircleAvatar(
              backgroundColor: AppColor.primaryColor,
              child: IconButton(
                icon: Icon(
                  Icons.close,
                  color: AppColor.accentWhite,
                  size: 20,
                ),
                onPressed: () {
                  Get.back();
                },
              ),
            ),
          ),
          backgroundColor: AppColor.accentWhite,
          automaticallyImplyLeading: true,
        ),
        body: SafeArea(
          child: Container(
            color: Colors.white,
            height: double.infinity,
            width: double.infinity,
            child: Center(
                child: GestureDetector(
              onTap: (() {
                // Get.back();
              }),
              child: Container(
                color: Colors.white,
                // width: 100,
                child: PhotoView(
                  imageProvider: NetworkImage(
                      "$baseUrl/storage/app/public/product/${Get.arguments}"),
                  backgroundDecoration: BoxDecoration(color: Colors.white),
                  // gaplessPlayback: false,
                  customSize: MediaQuery.of(context).size,
                  // enableRotation: true,
                  minScale: PhotoViewComputedScale.contained * 0.8,
                  maxScale: PhotoViewComputedScale.covered * 1.8,
                  initialScale: PhotoViewComputedScale.contained,
                  basePosition: Alignment.center,
                ),
              ),
            )),
          ),
        ));
  }
}
