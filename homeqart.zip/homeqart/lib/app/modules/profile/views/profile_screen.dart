// import 'package:flutter/material.dart';
// import 'package:homeqart_online/components/appbar_without_actions.dart';
// import 'package:homeqart_online/helper/get_storage_helper.dart';
// import 'package:homeqart_online/screens/profile/components/section.dart';
// import 'package:homeqart_online/screens/profile/components/user_profile_widget.dart';
// import '../../main.dart';
// import '../../text_theme.dart';
// import '../../theme.dart';
// import '../drawer/drawer_screen.dart';
// import 'components/section_heading_tile.dart';

// class ProfileScreen extends StatefulWidget {
//   const ProfileScreen({Key? key}) : super(key: key);

//   @override
//   _ProfileScreenState createState() => _ProfileScreenState();
// }

// class _ProfileScreenState extends State<ProfileScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: DrawerView(),
//       appBar: CustomAppBar('Profile'),
//       backgroundColor: AppColor.accentBgColor,
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Column(
//             children: [
//               Container(
//                 margin: EdgeInsets.zero,
//                 height: 50,
//               child: Card(
//                 elevation: 0.0,
//                 child: Padding(
//                                   padding: EdgeInsets.symmetric(horizontal:10 ),

//                   child: Row(
//                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text(
//                           "My Account",
//                           style: Texttheme.subTitle,
//                         ),
//                         GestureDetector(
//                           onTap: () {
//                             Navigator.of(context).pushAndRemoveUntil(
//                                 MaterialPageRoute(
//                               builder: (BuildContext context) {
//                                 box.erase();
//                                 return const MyApp();
//                               },
//                             ), (Route<dynamic> route) => false);
//                           },
//                           child: Text(
//                             "Logout",
//                             style: Texttheme.subTitle,
//                           ),
//                         ),
//                       ],
//                   ),
//                 ),
//               ),
//               ),
//                const SectionHeadingTile(),
             
//               UserProfileWidget(
//                 userImageUrl: "${box.read('user_image')}",
//                 userName: "${box.read('name')}",
//                 userId: "${box.read('id')}",
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               const Section(),
//               const SizedBox(
//                 height: 30,
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
