import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/drawer/drawer_screen.dart';

import 'package:homeqart/app/modules/profile/views/components/section.dart';
import 'package:homeqart/app/modules/profile/views/components/section_heading_tile.dart';
import 'package:homeqart/app/modules/profile/views/components/user_profile_widget.dart';
import 'package:homeqart/app/routes/app_pages.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

class ProfileView extends StatefulWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  _ProfileViewState createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: DrawerView(),
      appBar: AppBar(
        elevation: 0,
        iconTheme: IconThemeData(color: AppColor.defaultBlackColor),
        title: Row(
          children: [
            Text(
              "Prime Membership",
              style:
                  Texttheme.subTitle.copyWith(color: AppColor.accentDarkGrey),
            ),
            box2.read("is_prime") == "1"
                ? Container(
                    margin: EdgeInsets.symmetric(horizontal: 5),
                    height: 20,
                    width: 20,
                    child: Center(
                        child: Icon(
                      Icons.check,
                      size: 18,
                      color: AppColor.accentWhite,
                    )),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppColor.primaryColor),
                  )
                : Container(
                    margin: EdgeInsets.symmetric(horizontal: 5),
                    height: 20,
                    width: 20,
                    child: Center(
                        child: Icon(
                      Icons.close,
                      size: 18,
                      color: AppColor.accentWhite,
                    )),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppColor.neturalRed),
                  )
          ],
        ),
        backgroundColor: AppColor.accentWhite,
        automaticallyImplyLeading: true,
      ),
      backgroundColor: AppColor.accentBgColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.zero,
                height: 50,
                child: Card(
                  elevation: 0.0,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "My Account",
                          style: Texttheme.subTitle,
                        ),
                        GestureDetector(
                          onTap: () {
                            var box2 = GetStorage();
                            box2.erase();
                            Get.offNamedUntil(
                                AppPages.INITIAL, (route) => false);
                          },
                          child: Text(
                            "Logout",
                            style: Texttheme.subTitle,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SectionHeadingTile(),
              UserProfileWidget(
                userImageUrl:
                    "${box2.read('image') == null ? "" : box2.read('image')}",
                userName:
                    "${box2.read('name') == null ? "" : box2.read('name')}",
                userId: "${box2.read('id')}",
              ),
              const SizedBox(
                height: 10,
              ),
              const Section(),
              const SizedBox(
                height: 30,
              )
            ],
          ),
        ),
      ),
    );
  }
}
