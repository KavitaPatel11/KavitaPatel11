import 'package:flutter/material.dart';
import 'package:homeqart/app/modules/address/views/address_view.dart';
import 'package:homeqart/app/modules/orders/views/orders_view.dart';
import 'package:homeqart/app/modules/profile/views/components/section_heading_tile.dart';
import 'package:homeqart/app/modules/profile/views/components/section_tile.dart';
import 'package:homeqart/app/modules/shopping_cart/views/shopping_cart_view.dart';
import 'package:homeqart/app/modules/wishlist/views/wishlist_view.dart';
import 'package:homeqart/app/theme.dart';



class Section extends StatelessWidget {
  const Section({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
              color: AppColor.accentWhite,
              borderRadius: BorderRadius.circular(4)),
          child: Column(
            children: [
             
               SectionTile(
                      iconData: "assets/icons/myorders.jpeg",
                      press: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return const OrdersView();
                        }));
                      },
                      tileText: "My Orders",
                      subtileText: 'Track your orders and history',
                    ),
                    const SectionHeadingTile(),
                    SectionTile(
                      iconData: "assets/icons/wishlist.jpeg",
                      press: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return const WishlistView();
                        }));
                      },
                      tileText: "Wishlist",
                      subtileText: 'Create,Edit your custom Wishlist',
                    ),
                    const SectionHeadingTile(),
                    SectionTile(
                      iconData: "assets/icons/address.jpeg",
                      press: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return const AddressView(
                            appBarTitle: "Saved Addresses",
                          );
                        }));
                      },
                      tileText: "Address",
                      subtileText: 'Add,Edit your address',
                    ),
                    const SectionHeadingTile(),
                    SectionTile(
                      iconData: "assets/icons/cart_icon.png",
                      press: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return const ShoppingCartView();
                        }));
                      },
                      tileText: "Cart",
                      subtileText: 'check your cart',
                    ),
                    const SectionHeadingTile(),
            ],
          ),
        ),
       
      ],
    );
  }
}
