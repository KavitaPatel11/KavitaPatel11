import 'package:flutter/material.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class SectionTile extends StatelessWidget {
  final String iconData;
  final String tileText;
  final String subtileText;
  final VoidCallback press;
  const SectionTile(
      {Key? key,
      required this.iconData,
      required this.press,
      required this.subtileText,
      required this.tileText})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Card(
        elevation: 0.0,
        child: Container(
          height: 80,
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Row(
              mainAxisAlignment:MainAxisAlignment.spaceBetween,
                // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment:MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tileText,style: Texttheme.subTitle,),
                SizedBox(height: 3.5,),
                Text(subtileText, style:
                  Texttheme.bodyText1.copyWith(color: AppColor.accentLightGrey),),
              ],
              ),
               Container(
                 decoration:BoxDecoration(
                   color: Colors.pink.shade50,
                   borderRadius: BorderRadius.circular(70)
                 ),
                 
                 height: 70,
                 width: 70,
                 child: Image.asset(iconData)),
            ],
          ),
        )
      ),
    );
  }
}
