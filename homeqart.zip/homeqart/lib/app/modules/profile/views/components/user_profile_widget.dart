import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/login/model/login_response_model.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../../services/base_client.dart';

class UserProfileWidget extends StatefulWidget {
  final String userName;
  final String userId;
  final String userImageUrl;
  const UserProfileWidget(
      {Key? key,
      required this.userName,
      required this.userId,
      required this.userImageUrl})
      : super(key: key);

  @override
  State<UserProfileWidget> createState() => _UserProfileWidgetState();
}

class _UserProfileWidgetState extends State<UserProfileWidget> {
  File? selectedImage;
  BaseClient baseClient = BaseClient();
  LoginResponse? loginResponse;
  // This function used to pick image from device
  Future pickImage(ImageSource imageSource) async {
    try {
      final image = await ImagePicker().pickImage(source: imageSource);
      if (image == null) return;
      selectedImage = File(image.path);
      final apiResponse = await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(
          uploadImage(selectedImage!),
        ),
      );
    } on Exception catch (e) {
      print(e);
    }
  }

// This function show option to pick either from the camera or gallery
  void _showPicker(context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                  leading: const Icon(Icons.photo_library),
                  title: const Text('Gallery'),
                  onTap: () async {
                    await pickImage(ImageSource.gallery);
                    Navigator.of(context).pop();
                  }),
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Camera'),
                onTap: () async {
                  await pickImage(ImageSource.camera);
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  uploadImage(File image) async {
    print(widget.userId);
    var headers = {'Authorization': 'Bearer ${box2.read('logintoken')}'};
    print("profiee token  ${box2.read('logintoken')}");
    var request = http.MultipartRequest(
        'POST', Uri.parse('$baseUrl/api/v1/customer/update-profile-picture'));
    print("success update profil ${request} picture");
    request.fields.addAll({'user_id': widget.userId});
    request.files.add(await http.MultipartFile.fromPath('image', image.path));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    print("success update profile picture");
    if (response.statusCode == 200) {
      final apiResponse = await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(getUserProfile()),
      );
    } else {
      print("cant' update profile picture");
    }
  }

  getUserProfile() async {
    print("get user profile data");
    final response =
        await baseClient.get(true, "$baseUrl", "/api/v1/customer/info");
    var userdata = jsonDecode(response);
    box2.write("id", userdata['id']);
    box2.write("name", userdata['name']);
    box2.write("email", userdata['email']);
    box2.write("phone", userdata['phone']);
    box2.write("image", userdata['image']);
    box2.write("provider_id", userdata['provider_id']);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.zero,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        color: AppColor.accentWhite,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 80,
            width: double.infinity,
            child: Center(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.userName,
                          style: Texttheme.subTitle,
                        ),
                        box2.read("phone") == null
                            ? SizedBox()
                            : Text(
                                "Phone: ${box2.read("phone")}",
                                style: Texttheme.bodyText1
                                    .copyWith(color: AppColor.accentLightGrey),
                              ),
                        box2.read("email") == null
                            ? SizedBox()
                            : Text(
                                "Email: ${box2.read("email") == null ? "" : box2.read("email")}",
                                style: Texttheme.bodyText1
                                    .copyWith(color: AppColor.accentLightGrey),
                              ),
                      ],
                    ),
                    Stack(
                      children: [
                        Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white,
                            border: Border.all(color: AppColor.primaryColor),
                          ),
                          child: ClipOval(
                            child: SizedBox.fromSize(
                              size: Size.fromRadius(48), // Image radius
                              child: CachedNetworkImage(
                                fit: BoxFit.cover,
                                imageUrl:
                                    "$baseUrl/storage/app/public/user/${widget.userImageUrl == null ? "" : widget.userImageUrl}",
                                placeholder: (context, url) => Icon(
                                  Icons.photo,
                                  size: 50,
                                  color: AppColor.accentLightGrey,
                                ),
                                errorWidget: (context, url, error) => Icon(
                                  Icons.person,
                                  size: 50,
                                  color: AppColor.accentLightGrey,
                                ),
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () async {
                            _showPicker(context);
                          },
                          child: Container(
                            width: 25,
                            height: 25,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: AppColor.primaryColor,
                            ),
                            child: const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
        ],
      ),
    );
  }
}
