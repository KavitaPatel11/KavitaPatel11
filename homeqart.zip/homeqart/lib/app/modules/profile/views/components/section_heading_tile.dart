import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

class SectionHeadingTile extends StatelessWidget {
  
  const SectionHeadingTile({Key? key, }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 13,
      width: double.infinity,
      color: Colors.grey.shade200,
      child: Center(
          child: Padding(
        padding: const EdgeInsets.only(left: 15),
        
      )),
    );
  }
}
