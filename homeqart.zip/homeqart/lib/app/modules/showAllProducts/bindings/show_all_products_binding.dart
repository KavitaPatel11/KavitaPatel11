import 'package:get/get.dart';

import 'package:homeqart/app/modules/showAllProducts/controllers/show_all_product_screen3_controller_controller.dart';
import 'package:homeqart/app/modules/showAllProducts/controllers/show_all_product_screen3_controller_controller.dart';
import 'package:homeqart/app/modules/showAllProducts/controllers/showallproductscreen2_controller.dart';

import '../controllers/show_all_products_controller.dart';

class ShowAllProductsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ShowAllProductScreen3ControllerController>(
      () => ShowAllProductScreen3ControllerController(),
    );
    Get.lazyPut<ShowAllProductScreen3ControllerController>(
      () => ShowAllProductScreen3ControllerController(),
    );
    Get.lazyPut<Showallproductscreen2Controller>(
      () => Showallproductscreen2Controller(),
    );
    Get.lazyPut<ShowAllProductsController>(
      () => ShowAllProductsController(),
    );
  }
}
