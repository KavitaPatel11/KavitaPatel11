class Config {
  static final String apiURL = '';
}
