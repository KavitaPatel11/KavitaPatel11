import 'dart:convert';

import 'package:homeqart/app/modules/showAllProducts/model/data_model.dart';
import 'package:http/http.dart' as http;

import '../../../constent.dart';
import '../../common_model/product_by_brand_response.dart';
import '../model/config.dart';

class APIService {
  Future<DataModel> getData(pageNumber, path) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/$path?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<DataModel> dailyneeds(pageNumber, path) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/$path?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<DataModel> featured(pageNumber, path) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/$path?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<DataModel> upselling(pageNumber, path) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/$path?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<DataModel> discounted(pageNumber, path) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/$path?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<DataModel> categorieswiseproduct(pageNumber, catid) async {
    print("api services is clling");
    String url =
        "$baseUrl/api/v1/categories/products/$catid/all?limit=20&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success ${json.decode(response.body)}");
      return DataModel.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<ProductByBrandResponse> brandwiseproduct(pageNumber, brand_id) async {
    print("api services is clling");
    String url = "$baseUrl/api/v1/brands/$brand_id?limit=16&offset=$pageNumber";

    print("URL : $url");
    final response = await http.get(Uri.parse(Config.apiURL + url));
    if (response.statusCode == 200) {
      print("api services is success  ${json.decode(response.body)}");
      return ProductByBrandResponse.fromJson(
        json.decode(response.body),
      );
    } else {
      throw Exception('Failed to load data!');
    }
  }
}
