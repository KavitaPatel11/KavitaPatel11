// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:http/http.dart' as http;

import 'package:homeqart/app/constent.dart';

class ShowAllProductRemoteServices {
  static var client = http.Client();

  static Future<ProductModel?> fetchcatProduct(catid, currentPage) async {
    print("============ banners api calling=======");

    var response = await client.get(
      Uri.parse(
          '$baseUrl/api/v1/categories/products/$catid/all?limit=16&offset=$currentPage'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("banners api successs");
      var jsonString = response.body;
      print("banners======= $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print(" banners api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetchAllProducts(path, currentPage) async {
    print("============filter api calling== ===${currentPage}=====");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/$path?limit=16&offset=$currentPage'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("filter banners api successs");
      var jsonString = response.body;
      print("filter ======= $jsonString");
      print(jsonString);
      return productModelFromJson(jsonString);
    } else {
      print(" filter api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductModel?> fetchProducts(
      int currentPage, String path) async {
    print("============ all products screen3 api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/$path?limit=16&offset=$currentPage'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("all products screen3 api successs");
      var jsonString = response.body;
      print("all products screen3======= $jsonString");
      print(jsonString);
      print("success");
      return productModelFromJson(jsonString);
    } else {
      print("all products screen3 api Unsuccesssfull..");
      return null;
    }
  }
}
