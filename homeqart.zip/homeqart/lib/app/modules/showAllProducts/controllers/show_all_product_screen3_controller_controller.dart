import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';

import '../model/services.dart';

class ShowAllProductScreen3ControllerController extends GetxController {
  var isLoading = true.obs;
  var productModel = ProductModel().obs;
  int currentPage = 1;
  late int totalPages;

  // final RefreshController refreshController =
  //     RefreshController(initialRefresh: true);

  @override
  void onInit() async {
    products();
    super.onInit();
  }

  products() async {
    try {
      isLoading(true);
      print("brand block");
      final apiResponse = await ShowAllProductRemoteServices.fetchProducts(
          currentPage, "${Get.arguments[1]['path']}");

      print("brand block exexuted");
      if (apiResponse != null) {
        var result = apiResponse;
        print("brands====$result");
        productModel.value = result;
        totalPages = productModel.value.totalPages!;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
