import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/showAllProducts/model/services.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ShowAllProductsController extends GetxController {
  //TODO: Implement ShowAllProductsController

  var isLoading = true.obs;
  var productModel = ProductModel().obs;
  int currentPage = 1;
  late int totalPages;

  // final RefreshController refreshController =
  //     RefreshController(initialRefresh: true);

  @override
  void onInit() async {
    subcategories();
    super.onInit();
  }

  subcategories() async {
    try {
      isLoading(true);
      print("categories wise products");
      final apiResponse = await ShowAllProductRemoteServices.fetchcatProduct(
          Get.arguments[0]['id'], currentPage);

      print("categories wise products exexuted");
      if (apiResponse != null) {
        var result = apiResponse;
        print("categories wise products====$result");
        productModel.value = result;
        totalPages = productModel.value.totalPages!;
      }
    } finally {
      isLoading(false);
    }
  }

  // var isLoading = true.obs;
  // var productlist = ProductModel().obs;
  // var getArgumentData = Get.arguments;
  // int currentPage = 1;
  // var totalPages;
  // final RefreshController refreshController =
  //     RefreshController(initialRefresh: false);

  // @override
  // void onInit() async {
  //   subcategories(getArgumentData[0]['id']);

  //   super.onInit();
  // }

  // Future<bool> subcategories(
  //   cat_id, {
  //   bool isRefresh = false,
  // }) async {
  //   print("all product2==");
  //   if (isRefresh) {
  //     currentPage = 1;
  //   } else {
  //     if (currentPage == totalPages) {
  //       refreshController.loadNoData();
  //       return false;
  //     }
  //   }

  //   //  final apiResponse = await baseClient.get(false, "$baseUrl",
  //   //     "/api/v1/${getArgumentData[1]['path']}?offset=$currentPage");
  //   final apiResponse =
  //       await ShowAllProductRemoteServices.fetchcatProduct(cat_id, currentPage);
  //   if (apiResponse != null) {
  //     print("fetchcatProduct3==$apiResponse");
  //     var result = apiResponse;
  //     if (isRefresh) {
  //       productlist.value = result;
  //       print("fetchcatProduct3==$result");
  //     } else {
  //       productlist.value = result;
  //     }

  //     print(productlist);
  //     currentPage++;
  //     totalPages = productlist.value.totalPages! + 1;
  //     print(
  //         "aproductlist.products!.length==${productlist.value.products!.length}");
  //     // print((brandResponse.length / 15).toInt());
  //     // print(" brandresponse====== $brandResponse");
  //     isLoading(false);

  //     return true;
  //   } else {
  //     print("all null product6==$apiResponse");
  //     return false;
  //   }
  // }

  // subcategories(cat_id) async {
  //   try {
  //     isLoading(true);
  //     print(" brands try block");
  //     var products = await ShowAllProductRemoteServices.fetchcatProduct(cat_id);
  //     print("========= $products ======");
  //     if (products != null) {
  //       print(" brands inside controller");
  //       productlist.value=products;
  //     }
  //   } finally {
  //     isLoading(false);
  //   }
  // }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
