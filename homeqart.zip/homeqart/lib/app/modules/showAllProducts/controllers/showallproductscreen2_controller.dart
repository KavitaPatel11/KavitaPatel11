import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';

import 'package:homeqart/app/modules/showAllProducts/model/services.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class Showallproductscreen2Controller extends GetxController {
  BaseClient baseClient = BaseClient();
  var isLoading = true.obs;
  var allproductlist = ProductModel().obs;
  var getArgumentData = Get.arguments;
  int currentPage = 0;
  var totalPages;
  final RefreshController refreshController =
      RefreshController(initialRefresh: false);

  @override
  void onInit() async {
    allproducts();
    super.onInit();
  }

  Future<bool> allproducts({bool isRefresh = false}) async {
    print("all product2==");

    if (isRefresh) {
      currentPage = 0;
    } else {
      if (currentPage == totalPages) {
        refreshController.loadNoData();
        return false;
      }
    }

    //  final apiResponse = await baseClient.get(false, "$baseUrl",
    //     "/api/v1/${getArgumentData[1]['path']}?offset=$currentPage");
    final apiResponse = await ShowAllProductRemoteServices.fetchAllProducts(
        "${getArgumentData[1]['path']}", currentPage);
    if (apiResponse != null) {
      print("all product3==$apiResponse");
      var result = apiResponse;
      if (isRefresh) {
        allproductlist.value = result;
        print("all product3==$result");
      } else {
        allproductlist.value = result;
      }

      print(allproductlist);
      currentPage++;
      totalPages = (allproductlist.value.totalPages! + 1).toInt();
      print(
          "allproductlist.products!.length==${allproductlist.value.products!.length}");
      // print((brandResponse.length / 15).toInt());
      // print(" brandresponse====== $brandResponse");
      isLoading(false);

      return true;
    } else {
      print("all null product6==$apiResponse");
      return false;
    }
  }

  bool nodata() {
    refreshController.loadNoData();
    return false;
  }
  // Future<void> allproducts() async {
  //   isLoading(true);
  //   final usersData = await ShowAllProductRemoteServices.fetchAllProducts(getArgumentData[1]['path'], page);
  //   if (usersData!.products!.isEmpty) {
  //     _lastPage.value = true;
  //     print("filter product empty");
  //   }

  //   allproductlist.value=usersData;
  //     print("filter product list");
  //     isLoading(false);

  // }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
