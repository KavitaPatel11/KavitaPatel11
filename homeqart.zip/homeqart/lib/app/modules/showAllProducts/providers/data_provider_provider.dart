import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/common_model/product_by_brand_response.dart';

import '../model/api_services.dart';
import '../model/data_model.dart';

enum LoadMoreStatus { LOADING, STABLE }

class DataProvider with ChangeNotifier {
  APIService? _apiService;
  late DataModel _dataFetcher;

  late ProductByBrandResponse _productByBrandResponse;

  int totalPages = 0;
  int pageSize = 25;
  var argu = Get.arguments;

  List<Product>? get allUsers => _dataFetcher.products;
  List<BrandProduct>? get allBrandProduct => _productByBrandResponse.products;
  double get totalRecords => _dataFetcher.totalSize!.toDouble();

  double get totalBrandRecords => _productByBrandResponse.totalSize!.toDouble();

  LoadMoreStatus _loadMoreStatus = LoadMoreStatus.STABLE;
  getLoadMoreStatus() => _loadMoreStatus;

  DataProvider() {
    _initStreams();
  }

  void _initStreams() {
    _apiService = APIService();
    _dataFetcher = DataModel();
    _productByBrandResponse = ProductByBrandResponse();
  }

  void resetStreams() {
    _initStreams();
  }

  fetchAllUsers(pageNumber, path) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel = await _apiService!.getData(pageNumber, path);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  setLoadingState(LoadMoreStatus loadMoreStatus) {
    _loadMoreStatus = loadMoreStatus;
    notifyListeners();
  }

  fetchAllDailyneeds(pageNumber, path) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel = await _apiService!.dailyneeds(pageNumber, path);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  fetchAllfeatured(pageNumber, path) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel = await _apiService!.featured(pageNumber, path);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  fetchAllupselling(pageNumber, path) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel = await _apiService!.upselling(pageNumber, path);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  fetchAlldiscounted(pageNumber, path) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel = await _apiService!.discounted(pageNumber, path);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  fetchAllCategirieswise(pageNumber, catid) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      DataModel itemModel =
          await _apiService!.categorieswiseproduct(pageNumber, catid);
      if (_dataFetcher.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _dataFetcher = itemModel;
      } else {
        _dataFetcher.products!.addAll(itemModel.products!);
        _dataFetcher = _dataFetcher;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }

  fetchAllBrandswise(pageNumber, brand_id) async {
    if ((totalPages == 0) || pageNumber <= totalPages) {
      ProductByBrandResponse itemModel =
          await _apiService!.brandwiseproduct(pageNumber, brand_id);
      if (_productByBrandResponse.products == null) {
        totalPages = (itemModel.totalPages!);
        print("total pages $totalPages");
        _productByBrandResponse = itemModel;
      } else {
        _productByBrandResponse.products!.addAll(itemModel.products!);
        _productByBrandResponse = _productByBrandResponse;

        // One load more is done will make it status as stable.
        setLoadingState(LoadMoreStatus.STABLE);
      }

      notifyListeners();
    }

    if (pageNumber > totalPages) {
      // One load more is done will make it status as stable.
      setLoadingState(LoadMoreStatus.STABLE);
      notifyListeners();
    }
  }
}
