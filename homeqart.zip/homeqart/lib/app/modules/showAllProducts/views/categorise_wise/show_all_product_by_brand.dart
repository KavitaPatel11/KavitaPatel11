import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:homeqart/app/modules/common_model/product_by_brand_response.dart'
    as RadioModel;
import 'package:provider/provider.dart';

import '../../../../../components/appbar_without_actions.dart';
import '../../../../../components/product_card.dart';
import '../../../../constent.dart';
import '../../providers/data_provider_provider.dart';

class ShowAllBrandsProductScreen extends StatefulWidget {
  const ShowAllBrandsProductScreen({Key? key}) : super(key: key);

  @override
  State<ShowAllBrandsProductScreen> createState() =>
      _ShowAllBrandsProductScreenState();
}

class _ShowAllBrandsProductScreenState
    extends State<ShowAllBrandsProductScreen> {
  ScrollController _scrollController = ScrollController();
  int _page = 1;
  bool isLoading = false;
  var argu = Get.arguments;

  @override
  void initState() {
    super.initState();

    var videosBloc = Provider.of<DataProvider>(context, listen: false);
    videosBloc.resetStreams();
    videosBloc.fetchAllBrandswise(_page, argu[0]['id']);

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        videosBloc.setLoadingState(LoadMoreStatus.LOADING);
        videosBloc.fetchAllBrandswise(++_page, argu[0]['id']);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("${argu[1]['name']} "),
      body: Consumer<DataProvider>(
        builder: (context, usersModel, child) {
          if (usersModel.allBrandProduct != null) {
            return usersModel.allBrandProduct!.length == 0
                ? Center(
                    child: Text("No Records Found"),
                  )
                : _listView(usersModel);
          }

          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _listView(DataProvider dataProvider) {
    return GridView.builder(
      padding: const EdgeInsets.only(left: 10, right: 10, bottom: 10, top: 10),
      itemCount: dataProvider.allBrandProduct!.length,
      controller: _scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      shrinkWrap: true,
      // physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 200,
        mainAxisExtent: 220,
        childAspectRatio: 2 / 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemBuilder: (BuildContext ctx, index) {
        if ((index == dataProvider.allBrandProduct!.length - 1) &&
            dataProvider.allBrandProduct!.length <
                dataProvider.totalBrandRecords) {
          return Center(child: CircularProgressIndicator());
        }

        return _buildRow(dataProvider.allBrandProduct![index]);
      },
    );
  }

  // Widget _buildRow(RadioModel.Product radioModel) {
  //   return ListTile(title: new Text(radioModel.name!));
  // }

  Widget _buildRow(RadioModel.BrandProduct radioModel) {
    return ProductCard(
      id: radioModel.id!,
      image: "$baseUrl/storage/app/public/product/" + radioModel.image![0],
      name: radioModel.name!,
      mrp: "${radioModel.price!}",
      offAmount: radioModel.offAmount!.toString(),
      sellingPrice: radioModel.sellingPrice!.toString(),
      unit: '${radioModel.unit!}',
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
