import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:homeqart/app/modules/showAllProducts/model/data_model.dart'
    as RadioModel;
import 'package:provider/provider.dart';

import '../../../../../components/appbar_without_actions.dart';
import '../../../../../components/product_card.dart';
import '../../../../constent.dart';
import '../../providers/data_provider_provider.dart';

class ShowAllDailyNeedsProductScreen extends StatefulWidget {
  const ShowAllDailyNeedsProductScreen({Key? key}) : super(key: key);

  @override
  State<ShowAllDailyNeedsProductScreen> createState() =>
      _ShowAllDailyNeedsProductScreenState();
}

class _ShowAllDailyNeedsProductScreenState
    extends State<ShowAllDailyNeedsProductScreen> {
  ScrollController _scrollController = ScrollController();
  int _page = 1;
  bool isLoading = false;
  var argu = Get.arguments;

  @override
  void initState() {
    super.initState();

    var videosBloc = Provider.of<DataProvider>(context, listen: false);
    videosBloc.resetStreams();
    videosBloc.fetchAllDailyneeds(_page, argu[1]['path']);

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        videosBloc.setLoadingState(LoadMoreStatus.LOADING);
        videosBloc.fetchAllDailyneeds(++_page, argu[1]['path']);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("${argu[0]['title']} "),
      body: Consumer<DataProvider>(
        builder: (context, usersModel, child) {
          if (usersModel.allUsers != null && usersModel.allUsers!.length > 0) {
            return _listView(usersModel);
          }

          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _listView(DataProvider dataProvider) {
    return GridView.builder(
      padding: const EdgeInsets.only(left: 10, right: 10, bottom: 10, top: 10),
      itemCount: dataProvider.allUsers!.length,
      controller: _scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      shrinkWrap: true,
      // physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 200,
        mainAxisExtent: 220,
        childAspectRatio: 2 / 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemBuilder: (BuildContext ctx, index) {
        if ((index == dataProvider.allUsers!.length - 1) &&
            dataProvider.allUsers!.length < dataProvider.totalRecords) {
          return Center(child: CircularProgressIndicator());
        }

        return _buildRow(dataProvider.allUsers![index]);
      },
    );
  }

  // Widget _buildRow(RadioModel.Product radioModel) {
  //   return ListTile(title: new Text(radioModel.name!));
  // }

  Widget _buildRow(RadioModel.Product radioModel) {
    return ProductCard(
      id: radioModel.id!,
      image: "$baseUrl/storage/app/public/product/" + radioModel.image![0],
      name: radioModel.name!,
      mrp: "${radioModel.price!}",
      offAmount: radioModel.offAmount!.toString(),
      sellingPrice: radioModel.sellingPrice!.toString(),
      unit: '${radioModel.unit!}',
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
