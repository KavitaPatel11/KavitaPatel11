import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/showAllProducts/controllers/showallproductscreen2_controller.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/product_card.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ShowAllProductsScreen2 extends StatefulWidget {
  const ShowAllProductsScreen2({Key? key}) : super(key: key);

  @override
  _ShowAllProductsScreen2State createState() => _ShowAllProductsScreen2State();
}

class _ShowAllProductsScreen2State extends State<ShowAllProductsScreen2> {
  // var refreshKey = GlobalKey<RefreshIndicatorState>();
  final Showallproductscreen2Controller showallproductscreen2controller =
      Get.put(Showallproductscreen2Controller());
  var argu = Get.arguments;
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomAppBar("${argu[0]['title']} "),
        body: Obx(() {
          if (showallproductscreen2controller.isLoading.value) {
            return Center(child: CircularProgressIndicator());
          } else if (showallproductscreen2controller
              .allproductlist.value.products!.isEmpty) {
            return Center(
              child: Text("nothing to show"),
            );
          } else {
            return SmartRefresher(
                controller: showallproductscreen2controller.refreshController,
                enablePullDown: true,
                enablePullUp: true,

                // enablePullUp: true,
                onRefresh: () async {
                  final result = await showallproductscreen2controller
                      .allproducts(isRefresh: true);
                  if (result) {
                    showallproductscreen2controller.refreshController
                        .refreshCompleted();
                  } else {
                    showallproductscreen2controller.refreshController
                        .refreshFailed();
                  }
                },
                onLoading: () async {
                  final result =
                      await showallproductscreen2controller.allproducts();
                  if (result) {
                    showallproductscreen2controller.refreshController
                        .loadComplete();
                  } else {
                    showallproductscreen2controller.refreshController
                        .loadNoData();
                  }
                },
                child: SingleChildScrollView(
                  child: SafeArea(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, right: 10, top: 10),
                          child: GridView.builder(
                            controller: scrollController,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 200,
                              mainAxisExtent: 220,
                              childAspectRatio: 2 / 2,
                              crossAxisSpacing: 8,
                              mainAxisSpacing: 8,
                            ),
                            itemCount: showallproductscreen2controller
                                        .allproductlist
                                        .value
                                        .products!
                                        .length ==
                                    null
                                ? 0
                                : showallproductscreen2controller
                                    .allproductlist.value.products!.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return ProductCard(
                                id: showallproductscreen2controller
                                    .allproductlist.value.products![index].id!,
                                image: "$baseUrl/storage/app/public/product/" +
                                    showallproductscreen2controller
                                        .allproductlist
                                        .value
                                        .products![index]
                                        .image![0],
                                name: showallproductscreen2controller
                                    .allproductlist
                                    .value
                                    .products![index]
                                    .name!,
                                mrp:
                                    "${showallproductscreen2controller.allproductlist.value.products![index].price!}",
                                offAmount: showallproductscreen2controller
                                    .allproductlist
                                    .value
                                    .products![index]
                                    .offAmount!
                                    .toString(),
                                sellingPrice: showallproductscreen2controller
                                    .allproductlist
                                    .value
                                    .products![index]
                                    .sellingPrice!
                                    .toString(),
                                unit:
                                    '${showallproductscreen2controller.allproductlist.value.products![index].unit!}',
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ));
          }
        }));
  }
}
