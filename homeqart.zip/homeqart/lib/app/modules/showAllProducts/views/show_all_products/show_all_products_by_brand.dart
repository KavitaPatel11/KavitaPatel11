// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:homeqart/app/modules/common_model/product_by_brand_response.dart';
// import 'package:homeqart/services/base_client.dart';

// import 'package:http/http.dart' as http;



// class ShowAllBrandProductsScreen extends StatefulWidget {
//   final String subCategoryId;
//   final String subCategoryName;
//   const ShowAllBrandProductsScreen(
//       {Key? key, required this.subCategoryId, required this.subCategoryName})
//       : super(key: key);

//   @override
//   _ShowAllBrandProductsScreenState createState() => _ShowAllBrandProductsScreenState();
// }

// class _ShowAllBrandProductsScreenState extends State<ShowAllBrandProductsScreen> {
//   bool isLoading = true;
//   BaseClient baseClient = BaseClient();
//   List<ProductByBrandResponse>? productByBrandResponse;
//   var client = http.Client();

//   getData() async {
//     final apiResponse = await baseClient.get(false, "https://homeqart.com",
//         "/api/v1/brands/${widget.subCategoryId}");
  
//     productByBrandResponse = productByBrandResponseFromJson(apiResponse!);
     
//     isLoading = false;
//     setState(() {});
//   }

 


//   @override
//   void initState() {
//     //  implement initState
//     getData();
   
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: CustomAppBar("${widget.subCategoryName}"),
//       body: isLoading
//           ? const Center(
//               child: CircularProgressIndicator(),
//             )
//           : productByBrandResponse!.isEmpty
//               ? const Center(
//                   child: Text('Nothing to Show'),
//                 )
//               : SingleChildScrollView(
//                   child: SafeArea(
//                     child: Padding(
//                       padding:
//                           const EdgeInsets.only(left: 10, right: 10, top: 10),
//                       child: GridView.builder(
//                         shrinkWrap: true,
//                         physics: const NeverScrollableScrollPhysics(),
//                         gridDelegate:
//                             const SliverGridDelegateWithMaxCrossAxisExtent(
//                           maxCrossAxisExtent: 200,
//                           mainAxisExtent: 220,
//                           childAspectRatio: 2 / 2,
//                           crossAxisSpacing: 8,
//                           mainAxisSpacing: 8,
//                         ),
//                         itemCount: productByBrandResponse!.length,
//                         itemBuilder: (BuildContext ctx, index) {
//                           return BrandProductCard(id: productByBrandResponse![index].id==null?0:productByBrandResponse![index].id!, image: 'https://homeqart.com/storage/app/public/product/${productByBrandResponse![index].image![0]}', mrp: '${productByBrandResponse![index].price==null?0:productByBrandResponse![index].price!}', offAmount:productByBrandResponse![index].offAmount==null?0:productByBrandResponse![index].offAmount!, unit: '${productByBrandResponse![index].unit==null?'':productByBrandResponse![index].unit!}', name: '${productByBrandResponse![index].name==null?0:productByBrandResponse![index].name!}', sellingPrice: productByBrandResponse![index].sellingPrice==null?0:productByBrandResponse![index].sellingPrice!,
                           
//                           );
//                         },
//                       ),
//                     ),
//                   ),
//                 ),
//     );
//   }
// }
