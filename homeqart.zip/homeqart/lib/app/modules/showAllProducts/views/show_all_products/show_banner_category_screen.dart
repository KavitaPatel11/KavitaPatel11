import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/showAllProducts/model/data_model.dart'
    as RadioModel;

import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/product_card.dart';

import 'package:provider/provider.dart';

import '../../providers/data_provider_provider.dart';

class BannerCategoryView extends StatefulWidget {
  const BannerCategoryView({
    Key? key,
  }) : super(key: key);

  @override
  _BannerCategoryViewState createState() => _BannerCategoryViewState();
}

class _BannerCategoryViewState extends State<BannerCategoryView> {
  ScrollController _scrollController = ScrollController();
  int _page = 1;
  bool isLoading = false;
  var argu = Get.arguments;

  @override
  void initState() {
    super.initState();

    var videosBloc = Provider.of<DataProvider>(context, listen: false);
    videosBloc.resetStreams();
    videosBloc.fetchAllCategirieswise(_page, argu[0]['id']);

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        videosBloc.setLoadingState(LoadMoreStatus.LOADING);
        videosBloc.fetchAllCategirieswise(++_page, argu[0]['id']);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("${Get.arguments[1]['name']}"),
      body: Consumer<DataProvider>(
        builder: (context, usersModel, child) {
          if (usersModel.allUsers != null && usersModel.allUsers!.length > 0) {
            return ListView(
              // physics: const AlwaysScrollableScrollPhysics(),
              // shrinkWrap: true,
              scrollDirection: Axis.vertical,
              controller: _scrollController,
              children: [
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(10),
                  height: 200,
                  child: CachedNetworkImage(
                      fit: BoxFit.fill,
                      imageUrl:
                          "$baseUrl/storage/app/public/banner/${argu[2]['banner']}",
                      placeholder: (context, url) {
                        return Image.asset("assets/images/placeholder.jpeg");
                      },
                      errorWidget: (context, url, error) {
                        return SvgPicture.asset("assets/icons/Error.svg");
                      }), /* add child content here */
                ),
                _listView(usersModel),
              ],
            );
          }

          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _listView(DataProvider dataProvider) {
    return GridView.builder(
      padding: const EdgeInsets.only(left: 10, right: 10, bottom: 10, top: 10),
      itemCount: dataProvider.allUsers!.length,

      // //  / physics: const AlwaysScrollableScrollPhysics(),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 200,
        mainAxisExtent: 220,
        childAspectRatio: 2 / 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemBuilder: (BuildContext ctx, index) {
        if ((index == dataProvider.allUsers!.length - 1) &&
            dataProvider.allUsers!.length < dataProvider.totalRecords) {
          return Center(child: CircularProgressIndicator());
        }

        return _buildRow(dataProvider.allUsers![index]);
      },
    );
  }

  // Widget _buildRow(RadioModel.Product radioModel) {
  //   return ListTile(title: new Text(radioModel.name!));
  // }

  Widget _buildRow(RadioModel.Product radioModel) {
    return ProductCard(
      id: radioModel.id!,
      image: "$baseUrl/storage/app/public/product/" + radioModel.image![0],
      name: radioModel.name!,
      mrp: "${radioModel.price!}",
      offAmount: radioModel.offAmount!.toString(),
      sellingPrice: radioModel.sellingPrice!.toString(),
      unit: '${radioModel.unit!}',
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
