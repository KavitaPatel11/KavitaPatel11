import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../../../components/appbar_without_actions.dart';
import '../../../../../components/product_card.dart';
import '../../../../../services/base_client.dart';
import '../../../../constent.dart';
import 'package:http/http.dart' as http;
import '../../../brands/controllers/brands_controller.dart';
import '../../controllers/show_all_product_screen3_controller_controller.dart';
import '../../model/services.dart';

class ShowAllProductScreen3 extends StatefulWidget {
  @override
  _ShowAllProductScreen3State createState() => _ShowAllProductScreen3State();
}

class _ShowAllProductScreen3State extends State<ShowAllProductScreen3> {
  final ShowAllProductScreen3ControllerController
      showAllProductScreen3ControllerController =
      Get.put(ShowAllProductScreen3ControllerController());
  final getargument = Get.arguments;
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (showAllProductScreen3ControllerController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return Scaffold(
              // floatingActionButton: showAllProductScreen3ControllerController
              //         .isLoading.value
              //     ? SizedBox()
              //     : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage >
              //             1)
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                   showAllProductScreen3ControllerController
              //                       .currentPage--;
              //                   showAllProductScreen3ControllerController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_before_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           ),
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage <
              //             showAllProductScreen3ControllerController.totalPages
              //                 .toInt())
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                   showAllProductScreen3ControllerController
              //                       .currentPage++;
              //                   showAllProductScreen3ControllerController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_next_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           )
              //       ]),
              appBar: CustomAppBar("${Get.arguments[0]['title']}"),
              body: SingleChildScrollView(
                child: SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 10, right: 10, top: 10),
                        child: GridView.builder(
                          controller: scrollController,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200,
                            mainAxisExtent: 220,
                            childAspectRatio: 2 / 2,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: showAllProductScreen3ControllerController
                                      .productModel.value.products!.length ==
                                  null
                              ? 0
                              : showAllProductScreen3ControllerController
                                  .productModel.value.products!.length,
                          itemBuilder: (BuildContext ctx, index) {
                            return ProductCard(
                              id: showAllProductScreen3ControllerController
                                  .productModel.value.products![index].id!,
                              image: "$baseUrl/storage/app/public/product/" +
                                  showAllProductScreen3ControllerController
                                      .productModel
                                      .value
                                      .products![index]
                                      .image![0],
                              name: showAllProductScreen3ControllerController
                                  .productModel.value.products![index].name!,
                              mrp:
                                  "${showAllProductScreen3ControllerController.productModel.value.products![index].price!}",
                              offAmount:
                                  showAllProductScreen3ControllerController
                                      .productModel
                                      .value
                                      .products![index]
                                      .offAmount!
                                      .toString(),
                              sellingPrice:
                                  showAllProductScreen3ControllerController
                                      .productModel
                                      .value
                                      .products![index]
                                      .sellingPrice!
                                      .toString(),
                              unit:
                                  '${showAllProductScreen3ControllerController.productModel.value.products![index].unit!}',
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsets.only(left: 10, right: 10, bottom: 10),
                        child: Container(
                          child: showAllProductScreen3ControllerController
                                  .isLoading.value
                              ? SizedBox()
                              : Card(
                                  child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        if (showAllProductScreen3ControllerController
                                                .currentPage >
                                            1)
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  showAllProductScreen3ControllerController
                                                      .currentPage--;
                                                  showAllProductScreen3ControllerController
                                                      .products();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons
                                                        .navigate_before_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        if (showAllProductScreen3ControllerController
                                                .currentPage <
                                            showAllProductScreen3ControllerController
                                                .totalPages
                                                .toInt())
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  showAllProductScreen3ControllerController
                                                      .currentPage++;
                                                  showAllProductScreen3ControllerController
                                                      .products();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons.navigate_next_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                      ]),
                                ),
                        ),
                      )
                    ],
                  ),
                ),
              ));
        }
      }),
    );
  }
}
