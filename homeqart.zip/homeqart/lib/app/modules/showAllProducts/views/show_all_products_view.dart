import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/product_card.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../controllers/show_all_products_controller.dart';

class ShowAllProductsView extends StatefulWidget {
  const ShowAllProductsView({
    Key? key,
  }) : super(key: key);

  @override
  _ShowAllProductsViewState createState() => _ShowAllProductsViewState();
}

class _ShowAllProductsViewState extends State<ShowAllProductsView> {
  final ShowAllProductsController showAllProductsController =
      Get.put(ShowAllProductsController());
  final getargument = Get.arguments;
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (showAllProductsController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return Scaffold(
              // floatingActionButton:showAllProductsController
              //         .isLoading.value
              //     ? SizedBox()
              //     : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage >
              //             1)
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                  showAllProductsController
              //                       .currentPage--;
              //                  showAllProductsController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_before_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           ),
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage <
              //            showAllProductsController.totalPages
              //                 .toInt())
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                  showAllProductsController
              //                       .currentPage++;
              //                  showAllProductsController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_next_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           )
              //       ]),
              appBar: CustomAppBar("${Get.arguments[1]['name']}"),
              body: SingleChildScrollView(
                child: SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(10),
                        height: 200,
                        child: CachedNetworkImage(
                            fit: BoxFit.fill,
                            imageUrl:
                                "$baseUrl/storage/app/public/category/${getargument[2]['banner']}",
                            placeholder: (context, url) {
                              return Image.asset(
                                  "assets/images/placeholder.jpeg");
                            },
                            errorWidget: (context, url, error) {
                              return SvgPicture.asset("assets/icons/Error.svg");
                            }), /* add child content here */
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 10, right: 10, top: 10),
                        child: GridView.builder(
                          controller: scrollController,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200,
                            mainAxisExtent: 220,
                            childAspectRatio: 2 / 2,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: showAllProductsController
                                      .productModel.value.products!.length ==
                                  null
                              ? 0
                              : showAllProductsController
                                  .productModel.value.products!.length,
                          itemBuilder: (BuildContext ctx, index) {
                            return ProductCard(
                              id: showAllProductsController
                                  .productModel.value.products![index].id!,
                              image: "$baseUrl/storage/app/public/product/" +
                                  showAllProductsController.productModel.value
                                      .products![index].image![0],
                              name: showAllProductsController
                                  .productModel.value.products![index].name!,
                              mrp:
                                  "${showAllProductsController.productModel.value.products![index].price!}",
                              offAmount: showAllProductsController.productModel
                                  .value.products![index].offAmount!
                                  .toString(),
                              sellingPrice: showAllProductsController
                                  .productModel
                                  .value
                                  .products![index]
                                  .sellingPrice!
                                  .toString(),
                              unit:
                                  '${showAllProductsController.productModel.value.products![index].unit!}',
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsets.only(left: 10, right: 10, bottom: 10),
                        child: Container(
                          child: showAllProductsController.isLoading.value
                              ? SizedBox()
                              : Card(
                                  child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        if (showAllProductsController
                                                .currentPage >
                                            1)
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  showAllProductsController
                                                      .currentPage--;
                                                  showAllProductsController
                                                      .subcategories();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons
                                                        .navigate_before_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        if (showAllProductsController
                                                .currentPage <
                                            showAllProductsController.totalPages
                                                .toInt())
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  showAllProductsController
                                                      .currentPage++;
                                                  showAllProductsController
                                                      .subcategories();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons.navigate_next_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                      ]),
                                ),
                        ),
                      )
                    ],
                  ),
                ),
              ));
        }
      }),
    );
  }
}
