// To parse this JSON data, do
//
//     final categoryResponse = categoryResponseFromJson(jsonString);

import 'dart:convert';

List<CategoryResponse> categoryResponseFromJson(String str) => List<CategoryResponse>.from(json.decode(str).map((x) => CategoryResponse.fromJson(x)));

String categoryResponseToJson(List<CategoryResponse> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CategoryResponse {
    CategoryResponse({
        this.id,
        this.name,
        this.parentId,
       
        this.image,
        this.banner,
        this.mobileImage,
    });

    int? id;
    String? name;
    int? parentId;
    
    String? image;
    String? banner;
    String? mobileImage;

    factory CategoryResponse.fromJson(Map<String, dynamic> json) => CategoryResponse(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        parentId: json["parent_id"] == null ? null : json["parent_id"],
       
        image: json["image"] == null ? null : json["image"],
        banner: json["banner"] == null ? null : json["banner"],
        mobileImage: json["mobile_image"] == null ? null : json["mobile_image"],
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "parent_id": parentId == null ? null : parentId,
       
        "image": image == null ? null : image,
        "banner": banner == null ? null : banner,
        "mobile_image": mobileImage == null ? null : mobileImage,
    };
}
