import 'package:get/get.dart';
import 'package:homeqart/app/modules/categories/views/categories_services.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';

class CategoriesController extends GetxController {
  var isLoading = true.obs;

  List<CategoryModel> catlist = [];

  @override
  void onInit() async {
    categories();

    super.onInit();
  }

  categories() async {
    try {
      isLoading(true);
      print(" brands try block");
      var cat = await CategoriesRemoteServices.fetchcategories();
      print("========= $cat ======");
      if (cat != null) {
        print(" brands inside controller");
        catlist.assignAll(cat);
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
