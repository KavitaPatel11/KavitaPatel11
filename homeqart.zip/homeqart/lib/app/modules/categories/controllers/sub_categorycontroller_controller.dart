import 'package:get/get.dart';
import 'package:homeqart/app/modules/categories/views/categories_services.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';

class SubCategorycontrollerController extends GetxController {
  //TODO: Implement SubCategorycontrollerController

  final count = 0.obs;

  var isLoading = true.obs;
  List<CategoryModel> subcatlist = [];
  var args=Get.arguments;

  @override
  void onInit() async {
    subcategories(args[0]['id']);

    super.onInit();
  }

  subcategories(int cat_id) async {
    try {
      isLoading(true);
      print("subcategosry try block");
      var subcat = await CategoriesRemoteServices.fetchsub_cat(cat_id);
      print("========= $subcat ======");
      if (subcat != null) {
        print(" brands inside controller");
        subcatlist.assignAll(subcat);
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
