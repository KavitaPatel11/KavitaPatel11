import 'package:get/get.dart';

import 'package:homeqart/app/modules/categories/controllers/sub_categorycontroller_controller.dart';

import '../controllers/categories_controller.dart';

class CategoriesBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SubCategorycontrollerController>(
      () => SubCategorycontrollerController(),
    );
    Get.lazyPut<CategoriesController>(
      () => CategoriesController(),
    );
  }
}
