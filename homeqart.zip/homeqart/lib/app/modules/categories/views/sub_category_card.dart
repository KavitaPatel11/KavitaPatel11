import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/modules/categories/controllers/sub_categorycontroller_controller.dart';
import 'package:homeqart/app/modules/showAllProducts/views/show_all_products_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

import '../../showAllProducts/views/categorise_wise/show_all_product_by_categories.dart';

class SubCategoryScreen extends StatefulWidget {
  const SubCategoryScreen({
    Key? key,
  }) : super(key: key);

  @override
  _SubCategoryScreenState createState() => _SubCategoryScreenState();
}

class _SubCategoryScreenState extends State<SubCategoryScreen> {
  final SubCategorycontrollerController subCategorycontrollerController =
      Get.put(SubCategorycontrollerController());
  var args = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        subCategorycontrollerController.subcategories(args[0]['id']);
      },
      child: Scaffold(
          backgroundColor: AppColor.accentBgColor,
          appBar: CustomAppBar(args[1]['name']),
          body: Obx(() {
            if (subCategorycontrollerController.isLoading.value) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else {
              return SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(5),
                        height: 200,
                        child: CachedNetworkImage(
                            fit: BoxFit.fill,
                            imageUrl:
                                "$baseUrl/storage/app/public/category/${args[2]['banner']}",
                            placeholder: (context, url) {
                              return Image.asset(
                                "assets/images/placeholder.jpeg",
                              );
                            },
                            errorWidget: (context, url, error) {
                              return SvgPicture.asset("assets/icons/Error.svg");
                            }), /* add child content here */
                      ),
                      ListView.builder(
                        itemCount: subCategorycontrollerController
                                    .subcatlist.length ==
                                null
                            ? 0
                            : subCategorycontrollerController.subcatlist.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          // print(categories[index].image!);
                          return InkWell(
                            onTap: () {
                              Get.to(ShowAllProductByCategory(), arguments: [
                                {
                                  'id': subCategorycontrollerController
                                      .subcatlist[index].id
                                      .toString(),
                                },
                                {
                                  'name': subCategorycontrollerController
                                      .subcatlist[index].name
                                      .toString(),
                                },
                                {
                                  'banner': subCategorycontrollerController
                                      .subcatlist[index].banner
                                      .toString()
                                }
                              ]);
                              // Navigator.push(context,
                              //     MaterialPageRoute(builder: (context) {
                              //   return ShowAllProductsView(
                              //     subCategoryName:
                              //         subCategorycontrollerController.subcatlist[index].name.toString(),
                              //     subCategoryId:
                              //         subCategorycontrollerController.subcatlist[index].id.toString(), bannerImage:  subCategorycontrollerController.subcatlist[index].banner.toString(),
                              //   );
                              // }));
                            },
                            child: Container(
                              margin: const EdgeInsets.only(top: 10),
                              decoration: BoxDecoration(
                                  color: AppColor.accentWhite,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, left: 10),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      height: 70,
                                      width: 70,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: CachedNetworkImage(
                                          imageUrl:
                                              "$baseUrl/storage/app/public/category/" +
                                                  subCategorycontrollerController
                                                      .subcatlist[index]
                                                      .mobileImage!,
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) => Icon(
                                            Icons.photo,
                                            size: 50,
                                            color: AppColor.accentLightGrey,
                                          ),
                                          errorWidget: (context, url, error) =>
                                              Icon(
                                            Icons.info,
                                            size: 50,
                                            color: AppColor.accentLightGrey,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 15,
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width -
                                          155,
                                      child: Text(
                                        "${subCategorycontrollerController.subcatlist[index].name!}",
                                        overflow: TextOverflow.ellipsis,
                                        style: Texttheme.subTitle.copyWith(
                                            color: AppColor.accentLightGrey),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(
                        height: 40,
                      )
                    ],
                  ),
                ),
              );
            }
          })),
    );
  }
}
