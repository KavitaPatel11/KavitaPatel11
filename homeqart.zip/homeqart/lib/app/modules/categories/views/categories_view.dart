import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/categories/views/sub_category_card.dart';
import 'package:homeqart/app/modules/home/controllers/categorycontroller_controller.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

class CategoriesView extends StatelessWidget {
  final CategorycontrollerController categorycontrollerController =
      Get.put(CategorycontrollerController());

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        categorycontrollerController.categories();
      },
      child: Scaffold(
          backgroundColor: AppColor.accentBgColor,
          appBar: CustomAppBar("Categories"),
          body: Obx(() {
            if (categorycontrollerController.isLoading.value) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else {
              return SingleChildScrollView(
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Column(
                      children: [
                        ListView.builder(
                          itemCount: categorycontrollerController
                                      .categorieslist.length ==
                                  null
                              ? 0
                              : categorycontrollerController
                                  .categorieslist.length,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            // print(categories[index].image!);
                            return InkWell(
                              onTap: () {
                                Get.to(SubCategoryScreen(), arguments: [
                                  {
                                    'id': categorycontrollerController
                                        .categorieslist[index].id,
                                  },
                                  {
                                    'name': categorycontrollerController
                                        .categorieslist[index].name
                                        .toString(),
                                  },
                                  {
                                    'banner': categorycontrollerController
                                        .categorieslist[index].banner
                                        .toString()
                                  }
                                ]);
                                // Navigator.push(context,
                                //     MaterialPageRoute(builder: (context) {
                                //   return SubCategoryScreen(
                                //     subCaegoryId:categorycontrollerController.categorieslist[index].id!,
                                //     categoryName: categorycontrollerController.categorieslist[index].name!,
                                //     bannerImage:categorycontrollerController.categorieslist[index].banner!,
                                //   );
                                // }));
                              },
                              child: Container(
                                margin: const EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                    color: AppColor.accentWhite,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.only(top: 10, left: 10),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        height: 70,
                                        width: 70,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: CachedNetworkImage(
                                              imageUrl:
                                                  "https://homeqart.com/storage/app/public/category/" +
                                                      categorycontrollerController
                                                          .categorieslist[index]
                                                          .mobileImage!,
                                              fit: BoxFit.cover,
                                              placeholder: (context, url) =>
                                                  Icon(
                                                    Icons.photo,
                                                    size: 50,
                                                    color: AppColor
                                                        .accentLightGrey,
                                                  ),
                                              errorWidget:
                                                  (context, url, error) {
                                                return SvgPicture.asset(
                                                    "assets/icons/Error.svg");
                                              }),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 15,
                                      ),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width -
                                                155,
                                        child: Text(
                                          categorycontrollerController
                                              .categorieslist[index].name!,
                                          overflow: TextOverflow.ellipsis,
                                          style: Texttheme.subTitle.copyWith(
                                              color: AppColor.accentLightGrey),
                                        ),
                                      ),
                                      Icon(
                                        Icons.arrow_forward_ios_sharp,
                                        color: AppColor.accentLightGrey,
                                        size: 15,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(
                          height: 40,
                        )
                      ],
                    ),
                  ),
                ),
              );
            }
          })),
    );
  }
}
