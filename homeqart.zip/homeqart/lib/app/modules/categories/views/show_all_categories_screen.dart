// import 'package:badges/badges.dart';
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:flutter/material.dart';
// import 'package:homeqart_online/components/appbar_without_actions.dart';
// import 'package:homeqart_online/components/brand_card.dart';
// import 'package:homeqart_online/components/category_card.dart';
// import 'package:homeqart_online/components/latest_productcard.dart';
// import 'package:homeqart_online/helper/get_storage_helper.dart';
// import 'package:homeqart_online/models/latest_productmodel.dart';
// import 'package:homeqart_online/models/response/all_categories_response.dart';
// import 'package:homeqart_online/models/response/brands_response.dart';
// import 'package:homeqart_online/models/response/category_model.dart';
// import 'package:homeqart_online/models/response/discounted_product_response.dart';
// import 'package:homeqart_online/models/response/featured_product_response.dart';
// import 'package:homeqart_online/models/response/get_banners_response.dart';
// import 'package:homeqart_online/models/response/get_notifications_response.dart';
// import 'package:homeqart_online/models/response/product_model.dart';
// import 'package:homeqart_online/models/response/top_selling_product.dart';
// import 'package:homeqart_online/screens/categories/categories_screen.dart';
// import 'package:homeqart_online/screens/drawer/drawer_screen.dart';
// import 'package:homeqart_online/screens/notification/notification_screen.dart';
// import 'package:homeqart_online/screens/search_products/search_products.dart';

// import 'package:homeqart_online/screens/show_all_products/show_all_products2.dart';
// import 'package:homeqart_online/screens/show_all_products/show_all_products_by_brand.dart';
// import 'package:homeqart_online/screens/show_all_products/show_all_products_screen.dart';
// import 'package:homeqart_online/services/base_client.dart';
// import 'package:homeqart_online/text_theme.dart';
// import 'package:homeqart_online/theme.dart';

// class ShowAllCategories extends StatefulWidget {
//   ShowAllCategories({Key? key}) : super(key: key);

//   @override
//   State<ShowAllCategories> createState() => _ShowAllCategoriesState();
// }

// class _ShowAllCategoriesState extends State<ShowAllCategories> {
 
//   @override
//   void initState() {
//     getCategories();
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColor.accentBgColor,
//       appBar: CustomAppBar("Categories"),
//       body: isLoading
//           ? const Center(
//               child: CircularProgressIndicator(),
//             )
//           : allCategorieslist.isEmpty
//               ? const Center(
//                   child: Text('Nothing to Show'),
//                 )
//               : SingleChildScrollView(
//                   child: SafeArea(
//                     child: Column(
//                       children: <Widget>[
//                         // note the ... spread operator that enables us to add two elements
//                         for (int i = 0; i < allCategorieslist.length; i++) ...[
//                           Container(
//                             margin: EdgeInsets.only(bottom: 5),
//                             height: 95,
//                             child: Card(
//                               elevation: 0.0,
//                               margin: EdgeInsets.zero,
//                               shape: RoundedRectangleBorder(
//                                 side:
//                                     BorderSide(color: Colors.white70, width: 1),
//                                 borderRadius: BorderRadius.circular(10),
//                               ),
//                               child: Padding(
//                                 padding: const EdgeInsets.all(10.0),
//                                 child: Row(
//                                   children: [
//                                     CachedNetworkImage(
//                                         imageUrl:
//                                             "https://homeqart.com/storage/app/public/category/${allCategorieslist[i].mobileImage}"),
//                                     SizedBox(
//                                       width: 5,
//                                     ),
//                                     Text(
//                                       "${allCategorieslist[i].name}",
//                                     ),
//                                     Spacer(),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ),
//                           Container(
//                               height: 170,
//                               child: ListView(
//                                 scrollDirection: Axis.horizontal,
//                                 children: <Widget>[
//                                   // this creates scat.length many elements inside the Column
//                                   for (int j = 0;
//                                       j <
//                                           4;
//                                       j++)
//                                     Container(
//                                       height: 70,
//                                       width: 100,
//                                       child: Card(
//                                         shape: RoundedRectangleBorder(
//                                           side: BorderSide(
//                                               color: Colors.white70, width: 1),
//                                           borderRadius:
//                                               BorderRadius.circular(10),
//                                         ),
//                                         child: Column(
//                                           children: [
//                                             Container(
//                                               height: 40,
//                                               child: CachedNetworkImage(
//                                                   fit: BoxFit.cover,
//                                                   height: 80,
//                                                   imageUrl:
//                                                       "https://test.homeqart.com/storage/app/public/category/${allCategorieslist[i].childCategories![j].mobileImage!}",
//                                                   placeholder: (context, url) {
//                                                     return Padding(
//                                                       padding:
//                                                           const EdgeInsets.all(
//                                                               10),
//                                                       child: Image.asset(
//                                                           "assets/images/placeholder.jpeg"),
//                                                     );
//                                                   },
//                                                   errorWidget:
//                                                       (context, url, error) {
//                                                     return Padding(
//                                                       padding:
//                                                           const EdgeInsets.all(
//                                                               10),
//                                                       child: Image.asset(
//                                                           "assets/images/placeholder.jpeg"),
//                                                     );
//                                                   }),
//                                             ),
//                                             Text(allCategorieslist[i]
//                                                 .childCategories![j]
//                                                 .name
//                                                 .toString())
//                                           ],
//                                         ),
//                                       ),
//                                     )
//                                 ],
//                               ))
//                         ]
//                       ],
//                     ),
//                   ),
//                 ),
//     );
//   }
// }
