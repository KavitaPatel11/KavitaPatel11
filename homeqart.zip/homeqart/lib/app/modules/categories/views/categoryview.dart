import 'package:flutter/material.dart';
import 'package:get/get.dart';


class CategoryView extends StatelessWidget {
  final int _index = 1;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: _index,
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.black),
          actionsIconTheme: IconThemeData(color: Colors.black),
          actions: [
            Icon(
              Icons.more_vert,
              size: 40,
            ),
          ],
          title: Text(
            'Order History',
            style: TextStyle(color: Colors.black),
          ),
          centerTitle: true,
          bottom: TabBar(
            labelPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            labelStyle: TextStyle(color: Colors.white),
            unselectedLabelColor: Colors.white,
            labelColor: Colors.white,
            indicatorColor: Colors.white,
            tabs: [
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _index == 0 ? Colors.green : Colors.grey),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Text(
                  'Completed',
                  style: TextStyle(
                      // color: Colors.green,
                      ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _index == 1 ? Colors.green : Colors.grey),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Text(
                  'Cancelled',
                  style: TextStyle(),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _index == 2 ? Colors.green : Colors.grey,
                ),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Text(
                  'Requested',
                  style: TextStyle(
                      // color: Colors.white,
                      ),
                ),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
           
          ],
        ),
      ),
    );
  }
}
