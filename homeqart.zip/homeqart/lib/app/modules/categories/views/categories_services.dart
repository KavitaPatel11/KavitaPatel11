



// ignore_for_file: non_constant_identifier_names

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';
import 'package:homeqart/app/modules/home/model/get_banners_response.dart';
import 'package:homeqart/app/modules/home/model/latestproductdata.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:http/http.dart' as http;


class CategoriesRemoteServices {
  static var client = http.Client();

  static Future<List<CategoryModel>?> fetchcategories() async {
   
    print("============ banners api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/categories'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    
    if (response.statusCode == 200) {
      print("banners api successs");
      var jsonString = response.body;
      print("banners======= $jsonString");
      print(jsonString);
      return categoryModelFromJson(jsonString);
    } else {
      print(" banners api Unsuccesssfull..");
      return null;
    }
  }


  static Future<List<CategoryModel>?> fetchsub_cat(cat_id) async {
   
    print("============ banners api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/categories/childes/$cat_id'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    if (response.statusCode == 200) {
      print("products/latest api successs");
      var jsonString = response.body;
      print("products/latest $jsonString");
      print(jsonString);
      return categoryModelFromJson(jsonString);
    } else {
      print(" products/latest api Unsuccesssfull..");
      return null;
    }
  }

  
  }

  
  




 

