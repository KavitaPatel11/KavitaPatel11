



// ignore_for_file: non_constant_identifier_names

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_model_response.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_summery_model.dart';
import 'package:http/http.dart' as http;



class CartRemoteServices {
  static var client = http.Client();

  static Future<CartModel?> fetchCartData() async {
    
    
    print("============ Shopping cart api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/customer/cart'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    
    if (response.statusCode == 200) {
      print(" Shopping cart api successs");
      var jsonString = response.body;
      print(" Shopping cart======= $jsonString");
      print(" Shopping cart api successs===========$jsonString");
      return cartModelFromJson(jsonString);
    } else {
      print(" Shopping cart api successs===========${response.body}");
      print("  Shopping cart api Unsuccesssfull..");
      return null;
    }
  }
   

   
  static Future<CartSummaryModel?> fetchCartSummeryData() async {
    
    
    print("============ Shopping cart api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/customer/cart/cart_value'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );
    
    if (response.statusCode == 200) {
      print(" Shopping cart api successs");
      var jsonString = response.body;
      print(" Shopping cart======= $jsonString");
      print(" Shopping cart api successs===========$jsonString");
      return cartSummaryModelFromJson(jsonString);
    } else {
      print(" Shopping cart api successs===========${response.body}");
      print("  Shopping cart api Unsuccesssfull..");
      return null;
    }
  }

 

 
  }


 

