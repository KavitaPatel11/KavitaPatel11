import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_model_response.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_summery_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:homeqart/app/modules/shopping_cart/services.dart';

class ShoppingCartController extends GetxController {
  List<int> counter = [];
  var isLoading = true.obs;
  var isCSLoading = true.obs;
  var cartlist = CartModel().obs;
  var cartsummerydata = CartSummaryModel().obs;
  // RemoveCouponResponse? coupon_apiResponse;

  @override
  void onInit() {
    shoppingcart();
    super.onInit();
  }

  Future<void> shoppingcart() async {
    try {
      isLoading(true);
      print(" Shopping cart try block");
      // print("get order id $orderid");

      var shopincart = await CartRemoteServices.fetchCartData();
      print("========= $shopincart ======");
      if (shopincart != null) {
        print("order_detail inside controller");
        cartlist.value = shopincart;
        cartsummery();
      }
    } finally {
      isLoading(false);
    }
  }

  Future<void> cartsummery() async {
    try {
      isCSLoading(true);
      print("summery Shopping cart try block");
      // print("get order id $orderid");

      var shopincartsummery = await CartRemoteServices.fetchCartSummeryData();
      print("========= $shopincartsummery ======");
      if (shopincartsummery != null) {
        print("summery inside controller");
        cartsummerydata.value = shopincartsummery;
      }
    } finally {
      isCSLoading(false);
    }
  }

  Future<void> cartremove(int cart_id) async {
    var isLoading = false.obs;
    print(
        "============product_id====================================================$cart_id=====");

    Map data = {
      'cart_id': '$cart_id',
    };

    print(data);
    print(baseUrl);
    final http.Response response = await http.post(
        Uri.parse("$baseUrl/api/v1/customer/cart/remove"),
        headers: <String, String>{
          'Authorization': 'Bearer ${box2.read("logintoken")}'
        },
        body: data);

    if (response.statusCode == 200) {
      print(response.body);
      print("status api success");
      isLoading(false);
      Get.snackbar(
        "Removed item",
        "${response.statusCode}",
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
      );
      // Get.back();
      shoppingcart();
    } else {
      print(response.body);
      print("status api un successfull");
      Get.snackbar(
        "Failed to",
        "removed item",
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.black,
      );
      Get.back();
    }
  }

  Future<void> decreaseCounter(index, cartId) async {
    if (counter[index] != 1) {
      counter[index]--;

      var data = {"cart_id": cartId, "value": "-1"};

      print(data);
      print(baseUrl);
      final http.Response response = await http.post(
          Uri.parse("$baseUrl/api/v1/customer/cart/update"),
          headers: <String, String>{
            'Authorization': 'Bearer ${box2.read("logintoken")}'
          },
          body: data);

      shoppingcart();
    }
  }

  Future<void> incrementCounter(index, cartId) async {
    counter[index]++;

    var data = {"cart_id": cartId, "value": "1"};

    print(data);
    print(baseUrl);
    final http.Response response = await http.post(
        Uri.parse("$baseUrl/api/v1/customer/cart/update"),
        headers: <String, String>{
          'Authorization': 'Bearer ${box2.read("logintoken")}'
        },
        body: data);

    shoppingcart();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
