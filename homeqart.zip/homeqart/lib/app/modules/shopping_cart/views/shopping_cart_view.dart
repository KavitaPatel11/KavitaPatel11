import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/helper/coupon_helper.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/address/views/address_view.dart';
import 'package:homeqart/app/modules/helper/keyboard_helper.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/modules/shopping_cart/controllers/shopping_cart_controller.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_model_response.dart';
import 'package:homeqart/app/modules/shopping_cart/model/cart_summery_model.dart';
import 'package:homeqart/app/modules/shopping_cart/model/coupon_response_model.dart';
import 'package:homeqart/app/modules/shopping_cart/model/remove_coupon_response.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/components/total_bill.dart';
import 'package:homeqart/services/base_client.dart';

import '../../register/verify_otp_model.dart';

class ShoppingCartView extends StatefulWidget {
  const ShoppingCartView({Key? key}) : super(key: key);

  @override
  _ShoppingCartViewState createState() => _ShoppingCartViewState();
}

class _ShoppingCartViewState extends State<ShoppingCartView> {
  ScrollController mainScrollController = ScrollController();
  CartSummaryModel? cartSummaryModel;
  VerifyOtpResponse? wishlistmsg;
  List<int> counter = [];
  bool isLoading = true;
  bool isSLoading = true;
  BaseClient baseClient = BaseClient();
  CartModel? cartModel;
  RemoveCouponResponse? coupon_apiResponse;
  final _applyformKey = GlobalKey<FormState>();

  final couponcodeController = TextEditingController();
  getCartItems() async {
    var response =
        await baseClient.get(true, "$baseUrl", "/api/v1/customer/cart");

    cartModel = cartModelFromJson(response);
    for (var i = 0; i < cartModel!.result!.length; i++) {
      counter.add(cartModel!.result![i].quantity!);
    }

    isLoading = false;
    setState(() {});
  }

  void incrementCounter(index) async {
    setState(() {
      counter[index]++;
    });
    var data = {
      "cart_id": cartModel!.result![index].id!.toString(),
      "value": "1"
    };

    final apiResponse = await await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(baseClient.post(
        true,
        "$baseUrl",
        "/api/v1/customer/cart/update",
        data,
      )),
    );
    // final apiResponse = await baseClient.post(
    //   true,
    //   "$baseUrl",
    //   "/api/v1/customer/cart/update",
    //   data,
    // );
    print(apiResponse);
    getCartItems();
    getOrderSummary();
    setState(() {
      box2.write("cart_total", cartSummaryModel!.total);
    });
  }

  void decreaseCounter(index) async {
    if (counter[index] != 1) {
      setState(() {
        counter[index]--;
      });
      var data = {
        "cart_id": cartModel!.result![index].id!.toString(),
        "value": "-1"
      };

      final apiResponse = await await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(baseClient.post(
          true,
          "$baseUrl",
          "/api/v1/customer/cart/update",
          data,
        )),
      );
      // final apiResponse = await baseClient.post(
      //   true,
      //   "$baseUrl",
      //   "/api/v1/customer/cart/update",
      //   data,
      // );
      print(apiResponse);
      getCartItems();
      getOrderSummary();
      setState(() {
        box2.write("cart_total", cartSummaryModel!.total);
      });
    }
  }

  getOrderSummary() async {
    final apiResponse = await baseClient.get(
        true, "$baseUrl", "/api/v1/customer/cart/cart_value");
    cartSummaryModel = cartSummaryModelFromJson(apiResponse);
    isSLoading = false;
    setState(() {});
  }

  @override
  void initState() {
    getCartItems();
    getOrderSummary();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // drawer: DrawerView(),
        backgroundColor: AppColor.accentBgColor,
        appBar: CustomAppBar("Cart"),
        body: (isLoading)
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : cartModel!.result!.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Container(
                        height: MediaQuery.of(context).size.height / 2 + 68,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: AppColor.accentWhite,
                            borderRadius: BorderRadius.circular(15)),
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                'assets/icons/sentiment_dissatisfied.svg',
                                height: 150,
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              Text(
                                "Your cart is empty!",
                                style: Texttheme.bodyText1.copyWith(
                                    color: AppColor.accentDarkGrey,
                                    fontSize: 20),
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              SizedBox(
                                width: double.infinity,
                                child: Text(
                                  "Make your basket happy and add products to purchage.",
                                  textAlign: TextAlign.center,
                                  style: Texttheme.bodyText1.copyWith(
                                      color: AppColor.accentLightGrey,
                                      fontSize: 16),
                                ),
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: DefaultButton(
                                  buttonText: "Start Shopping ",
                                  press: () {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (_) =>
                                                const MainScreen()));
                                  },
                                  buttonColor: AppColor.primaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                : SafeArea(
                    child: CustomScrollView(
                      controller: mainScrollController,
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      slivers: [
                        SliverList(
                          delegate: SliverChildListDelegate(
                            [
                              ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: cartModel?.result?.length == null
                                    ? 0
                                    : cartModel?.result?.length,
                                itemBuilder: (context, index) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                    ),
                                    child: InkWell(
                                      onTap: () {
                                        Get.to(ProductdetailView(),
                                            arguments: cartModel!
                                                .result![index].productId!);
                                      },
                                      child: Container(
                                        margin: const EdgeInsets.only(top: 10),
                                        decoration: BoxDecoration(
                                          border:
                                              Border.all(color: Colors.black12),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: AppColor.accentWhite,
                                        ),
                                        child: Row(
                                          children: [
                                            cartModel!.result![index].image ==
                                                    null
                                                ? const SizedBox()
                                                : Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 7,
                                                            bottom: 9,
                                                            left: 10),
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      child: Image.network(
                                                        "$baseUrl/storage/app/public/product/" +
                                                            cartModel!
                                                                .result![index]
                                                                .image!,
                                                        height: 70,
                                                        width: 70,
                                                      ),
                                                    ),
                                                  ),
                                            const SizedBox(
                                              width: 14,
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      165,
                                                  child: Text(
                                                    cartModel!.result![index]
                                                                .name ==
                                                            null
                                                        ? ""
                                                        : cartModel!
                                                            .result![index]
                                                            .name!,
                                                    maxLines: 2,
                                                    style: Texttheme.bodyText1
                                                        .copyWith(
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      160,
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                        "₹${cartModel!.result![index].sellingPrice == null ? "" : cartModel!.result![index].sellingPrice!}",
                                                        softWrap: true,
                                                        style: Texttheme.title
                                                            .copyWith(
                                                                color: AppColor
                                                                    .primaryColor),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 20),
                                                        child: OutlinedButton(
                                                          style: OutlinedButton
                                                              .styleFrom(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(0),
                                                          ),
                                                          onPressed: () async {
                                                            var data = {
                                                              "cart_id":
                                                                  cartModel!
                                                                      .result![
                                                                          index]
                                                                      .id!
                                                                      .toString(),
                                                            };

                                                            final apiResponse =
                                                                await showDialog(
                                                              context: context,
                                                              builder: (context) =>
                                                                  FutureProgressDialog(
                                                                      baseClient
                                                                          .post(
                                                                true,
                                                                "$baseUrl",
                                                                "/api/v1/customer/cart/remove",
                                                                data,
                                                              )),
                                                            );

                                                            wishlistmsg =
                                                                verifyOtpResponseFromJson(
                                                                    apiResponse);
                                                            Fluttertoast
                                                                .showToast(
                                                              msg:
                                                                  '${wishlistmsg!.message}',
                                                              toastLength: Toast
                                                                  .LENGTH_SHORT,
                                                              gravity:
                                                                  ToastGravity
                                                                      .SNACKBAR,
                                                              timeInSecForIosWeb:
                                                                  2,
                                                              backgroundColor:
                                                                  AppColor
                                                                      .primaryColor,
                                                              textColor:
                                                                  Colors.white,
                                                            );

                                                            // final apiResponse =
                                                            //     await baseClient
                                                            //         .post(
                                                            //   true,
                                                            //   "$baseUrl",
                                                            //   "/api/v1/customer/cart/remove",
                                                            //   data,
                                                            // );
                                                            print(apiResponse);
                                                            getCartItems();
                                                            getOrderSummary();
                                                            setState(() {
                                                              box2.write(
                                                                  "cart_total",
                                                                  cartSummaryModel!
                                                                      .total);
                                                            });
                                                          },
                                                          child: Text(
                                                            "Remove",
                                                            style: Texttheme
                                                                .bodyText2
                                                                .copyWith(
                                                                    color: AppColor
                                                                        .neturalRed),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Expanded(
                                              child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                    right: 0,
                                                  ),
                                                  child: Container(
                                                    height: 90,
                                                    width: 30,
                                                    decoration: BoxDecoration(
                                                      color: AppColor
                                                          .accentBgColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 3),
                                                          child: InkWell(
                                                            onTap: () {
                                                              incrementCounter(
                                                                  index);
                                                            },
                                                            child: const Icon(
                                                                Icons.add,
                                                                color: Colors
                                                                    .black,
                                                                size: 20),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          height: 10,
                                                        ),
                                                        AnimatedFlipCounter(
                                                          value: counter[index],
                                                          duration:
                                                              const Duration(
                                                                  milliseconds:
                                                                      300),
                                                          textStyle:
                                                              const TextStyle(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          32,
                                                                          16,
                                                                          16),
                                                                  fontSize: 15,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700),
                                                        ),
                                                        const SizedBox(
                                                          height: 8,
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  bottom: 3),
                                                          child: InkWell(
                                                            onTap: () {
                                                              decreaseCounter(
                                                                  index);
                                                            },
                                                            child: const Icon(
                                                                Icons.remove,
                                                                color: Colors
                                                                    .black,
                                                                size: 20),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        // SliverList(
                        //   delegate: SliverChildListDelegate(
                        //     [
                        //       Padding(
                        //         padding: const EdgeInsets.symmetric(
                        //             vertical: 16, horizontal: 16),
                        //         child: Row(
                        //           children: [
                        //             Expanded(
                        //               child: TextField(
                        //                 decoration: InputDecoration(
                        //                   fillColor: AppColor.accentWhite,
                        //                   filled: true,
                        //                   border: InputBorder.none,
                        //                   hintText: 'Enter coupon key',
                        //                 ),
                        //               ),
                        //             ),
                        //             SizedBox(
                        //               width: 100,
                        //               height: 48,
                        //               child: DefaultButton(
                        //                 buttonColor: AppColor.neturalOrange,
                        //                 buttonText: "Apply",
                        //                 press: () {},
                        //               ),
                        //             )
                        //           ],
                        //         ),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                        cartModel == null
                            ? const SizedBox()
                            : SliverList(
                                delegate: SliverChildListDelegate(
                                  [
                                    cartModel!.result!.isEmpty
                                        ? const SizedBox()
                                        : isSLoading
                                            ? SizedBox(
                                                height: 400,
                                                width: double.infinity,
                                                child: Center(
                                                    child:
                                                        CircularProgressIndicator()))
                                            : Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 12,
                                                    right: 12,
                                                    top: 10),
                                                child: TotalBill(
                                                  itemCount: (cartModel!
                                                          .result!.length)
                                                      .toString(),
                                                  subTotal: cartSummaryModel!
                                                      .subTotal
                                                      .toString(),
                                                  deliveryCharges:
                                                      "${cartSummaryModel!.shiping.toString() == "0" ? "" : "₹"}" +
                                                          "${cartSummaryModel!.shiping.toString() == "0" ? "Free" : cartSummaryModel!.shiping}",
                                                  totalAmount: cartSummaryModel!
                                                      .total
                                                      .toString(),
                                                ),
                                              ),
                                  ],
                                ),
                              ),
                        couponbox.read("msg") == "success"
                            ? SliverList(
                                delegate: SliverChildListDelegate([
                                Form(
                                  key: _applyformKey,
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 12),
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(3),
                                      border: Border.all(
                                          width: 1, color: Colors.grey),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          color: Colors.white,
                                          height: 50,
                                          width: 250,
                                          child: buildCouponFormField(),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(right: 10),
                                          child: OutlinedButton(
                                            style: OutlinedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              padding: const EdgeInsets.all(0),
                                            ),
                                            onPressed: () async {
                                              print("apply clicked");
                                              print(
                                                  "${couponbox.read("masg")}");
                                              if (_applyformKey.currentState!
                                                  .validate()) {
                                                _applyformKey.currentState!
                                                    .save();
                                                KeyboardUtil.hideKeyboard(
                                                    context);
                                                if (couponcodeController
                                                    .text.isNotEmpty) {
                                                  var data = {
                                                    "code": couponcodeController
                                                        .text,
                                                    "total_amount":
                                                        cartSummaryModel!.total,
                                                  };

                                                  final apiResponse =
                                                      await await showDialog(
                                                    context: context,
                                                    builder: (context) =>
                                                        FutureProgressDialog(
                                                            baseClient.post(
                                                      true,
                                                      "$baseUrl",
                                                      "/api/v1/customer/cart/apply_coupon_code",
                                                      data,
                                                    )),
                                                  );
                                                  // final apiResponse =
                                                  //     await baseClient.post(
                                                  //   true,
                                                  //   "$baseUrl",
                                                  //   "/api/v1/customer/cart/apply_coupon_code",
                                                  //   data,
                                                  // );
                                                  coupon_apiResponse =
                                                      removeCouponResponseFromJson(
                                                          apiResponse);

                                                  GetCartStorageHelper.setdata(
                                                      coupon_apiResponse!);

                                                  Fluttertoast.showToast(
                                                    msg: apiResponse,
                                                    toastLength:
                                                        Toast.LENGTH_SHORT,
                                                    gravity:
                                                        ToastGravity.SNACKBAR,
                                                    timeInSecForIosWeb: 2,
                                                    backgroundColor:
                                                        AppColor.primaryColor,
                                                    textColor: Colors.white,
                                                  );
                                                  print(apiResponse);
                                                  getCartItems();
                                                  getOrderSummary();
                                                  setState(() {
                                                    box2.write(
                                                        "cart_total",
                                                        cartSummaryModel!
                                                            .total);
                                                  });
                                                }
                                              }
                                            },
                                            child: Text(
                                              "Apply",
                                              style: Texttheme.bodyText2
                                                  .copyWith(
                                                      color: AppColor
                                                          .primaryColor),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              ]))
                            : couponbox.read("msg") == "Coupon applied"
                                ? SliverList(
                                    delegate: SliverChildListDelegate([
                                    Container(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 10),
                                      height: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(3),
                                        border: Border.all(
                                            width: 1, color: Colors.grey),
                                      ),
                                      child: OutlinedButton(
                                        style: OutlinedButton.styleFrom(
                                          padding: const EdgeInsets.all(0),
                                        ),
                                        onPressed: () async {
                                          print("Remove clicked");
                                          print("${couponbox.read("masg")}");

                                          final rapiResponse =
                                              await await showDialog(
                                            context: context,
                                            builder: (context) =>
                                                FutureProgressDialog(baseClient.get(
                                                    true,
                                                    "$baseUrl",
                                                    "/api/v1/customer/cart/remove_coupon/${cartModel!.result!.first.id}")),
                                          );
                                          // final rapiResponse =
                                          //     await baseClient.get(
                                          //   true,
                                          //   "$baseUrl",
                                          //   "/api/v1/customer/cart/remove_coupon/${cartModel!.result!.first.id}",
                                          // );
                                          coupon_apiResponse =
                                              removeCouponResponseFromJson(
                                                  rapiResponse);

                                          GetCartStorageHelper.setdata(
                                              coupon_apiResponse!);

                                          Fluttertoast.showToast(
                                            msg: rapiResponse,
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.SNACKBAR,
                                            timeInSecForIosWeb: 2,
                                            backgroundColor:
                                                AppColor.primaryColor,
                                            textColor: Colors.white,
                                          );
                                          print(rapiResponse);

                                          getCartItems();
                                          getOrderSummary();
                                          setState(() {
                                            box2.write("cart_total",
                                                cartSummaryModel!.total);
                                          });
                                        },
                                        child: Text(
                                          "Remove coupon",
                                          style: Texttheme.bodyText2.copyWith(
                                              color: AppColor.neturalRed),
                                        ),
                                      ),
                                    )
                                  ]))
                                : SliverList(
                                    delegate: SliverChildListDelegate([
                                    Form(
                                      key: _applyformKey,
                                      child: Container(
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 12),
                                        height: 50,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(3),
                                          border: Border.all(
                                              width: 1, color: Colors.grey),
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              color: Colors.white,
                                              height: 50,
                                              width: 250,
                                              child: buildCouponFormField(),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 10),
                                              child: OutlinedButton(
                                                style: OutlinedButton.styleFrom(
                                                  backgroundColor: Colors.white,
                                                  padding:
                                                      const EdgeInsets.all(0),
                                                ),
                                                onPressed: () async {
                                                  print("apply clicked");
                                                  print(
                                                      "${couponbox.read("masg")}");
                                                  if (_applyformKey
                                                      .currentState!
                                                      .validate()) {
                                                    _applyformKey.currentState!
                                                        .save();
                                                    KeyboardUtil.hideKeyboard(
                                                        context);
                                                    if (couponcodeController
                                                        .text.isNotEmpty) {
                                                      var data = {
                                                        "code":
                                                            couponcodeController
                                                                .text,
                                                        "total_amount":
                                                            cartSummaryModel!
                                                                .total,
                                                      };

                                                      final apiResponse =
                                                          await await showDialog(
                                                        context: context,
                                                        builder: (context) =>
                                                            FutureProgressDialog(
                                                                baseClient.post(
                                                          true,
                                                          "$baseUrl",
                                                          "/api/v1/customer/cart/apply_coupon_code",
                                                          data,
                                                        )),
                                                      );
                                                      // final apiResponse =
                                                      //     await baseClient.post(
                                                      //   true,
                                                      //   "$baseUrl",
                                                      //   "/api/v1/customer/cart/apply_coupon_code",
                                                      //   data,
                                                      // );
                                                      coupon_apiResponse =
                                                          removeCouponResponseFromJson(
                                                              apiResponse);

                                                      GetCartStorageHelper.setdata(
                                                          coupon_apiResponse!);

                                                      Fluttertoast.showToast(
                                                        msg: apiResponse,
                                                        toastLength:
                                                            Toast.LENGTH_SHORT,
                                                        gravity: ToastGravity
                                                            .SNACKBAR,
                                                        timeInSecForIosWeb: 2,
                                                        backgroundColor:
                                                            AppColor
                                                                .primaryColor,
                                                        textColor: Colors.white,
                                                      );
                                                      print(apiResponse);
                                                      getCartItems();
                                                      getOrderSummary();
                                                      setState(() {
                                                        box2.write(
                                                            "cart_total",
                                                            cartSummaryModel!
                                                                .total);
                                                      });
                                                    }
                                                  }
                                                },
                                                child: Text(
                                                  "Apply",
                                                  style: Texttheme.bodyText2
                                                      .copyWith(
                                                          color: AppColor
                                                              .primaryColor),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ])),

                        SliverList(
                          delegate: SliverChildListDelegate(
                            [
                              cartModel!.result!.isEmpty
                                  ? const SizedBox()
                                  : Padding(
                                      padding: const EdgeInsets.only(
                                        top: 16,
                                        left: 16,
                                        right: 16,
                                        bottom: 50,
                                      ),
                                      child: DefaultButton(
                                        buttonText: "Checkout",
                                        press: () {
                                          Navigator.push(context,
                                              MaterialPageRoute(
                                                  builder: (context) {
                                            return const AddressView(
                                              // cartId: cartModel!.,
                                              appBarTitle:
                                                  "Select Delivery Address",
                                            );
                                          }));
                                        },
                                        buttonColor: AppColor.primaryColor,
                                      ),
                                    ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ));
  }

  TextFormField buildCouponFormField() {
    return TextFormField(
      keyboardType: TextInputType.text,
      controller: couponcodeController,
      onChanged: (value) {
        // if (value.isNotEmpty) {
        //   removeError(error: kEmailNullError);
        // } else if (emailValidatorRegExp.hasMatch(value)) {
        //   removeError(error: kInvalidEmailError);
        // }
        // return;
      },
      validator: (value) {
        // if (value!.isEmpty) {

        //   return "";
        // }
        // return null;
      },
      decoration: InputDecoration(
          counterText: "",
          hintText: "Enter coupon code",
          fillColor: AppColor.accentWhite,
          filled: true,
          floatingLabelBehavior: FloatingLabelBehavior.always,
          border: InputBorder.none),
    );
  }
}
