// To parse this JSON data, do
//
//     final couponResponse = couponResponseFromJson(jsonString);

import 'dart:convert';

List<CouponResponse> couponResponseFromJson(String str) =>
    List<CouponResponse>.from(
        json.decode(str).map((x) => CouponResponse.fromJson(x)));

String couponResponseToJson(List<CouponResponse> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CouponResponse {
  CouponResponse({
    this.id,
    this.title,
    this.code,
    this.discountType,
    this.minPurchase,
    this.maxDiscount,
    this.discount,
    this.prime,
  });

  int? id;
  String? title;
  String? code;
  String? discountType;
  int? minPurchase;
  int? maxDiscount;
  int? discount;
  int? prime;

  factory CouponResponse.fromJson(Map<String, dynamic> json) => CouponResponse(
        id: json["id"] == null ? null : json["id"],
        title: json["title"] == null ? null : json["title"],
        code: json["code"] == null ? null : json["code"],
        discountType:
            json["discount_type"] == null ? null : json["discount_type"],
        minPurchase: json["min_purchase"] == null ? null : json["min_purchase"],
        maxDiscount: json["max_discount"] == null ? null : json["max_discount"],
        discount: json["discount"] == null ? null : json["discount"],
        prime: json["prime"] == null ? null : json["prime"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "title": title == null ? null : title,
        "code": code == null ? null : code,
        "discount_type": discountType == null ? null : discountType,
        "min_purchase": minPurchase == null ? null : minPurchase,
        "max_discount": maxDiscount == null ? null : maxDiscount,
        "discount": discount == null ? null : discount,
        "prime": prime == null ? null : prime,
      };
}
