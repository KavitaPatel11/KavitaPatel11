// To parse this JSON data, do
//
//     final removeCouponResponse = removeCouponResponseFromJson(jsonString);

import 'dart:convert';

RemoveCouponResponse removeCouponResponseFromJson(String str) => RemoveCouponResponse.fromJson(json.decode(str));

String removeCouponResponseToJson(RemoveCouponResponse data) => json.encode(data.toJson());

class RemoveCouponResponse {
    RemoveCouponResponse({
        this.msg,
    });

    String? msg;

    factory RemoveCouponResponse.fromJson(Map<String, dynamic> json) => RemoveCouponResponse(
        msg: json["msg"] == null ? null : json["msg"],
    );

    Map<String, dynamic> toJson() => {
        "msg": msg == null ? null : msg,
    };
}
