import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/brands/views/all_brands_screen.dart';
import 'package:homeqart/app/modules/brands/views/mainbrandfile.dart';
import 'package:homeqart/app/modules/categories/views/categories_view.dart';
import 'package:homeqart/app/modules/common_web_view_screen.dart';
import 'package:homeqart/app/modules/contact_us.dart';
import 'package:homeqart/app/modules/coupon/coupon_screen.dart';
import 'package:homeqart/app/modules/faqs/faq_screen.dart';
import 'package:homeqart/app/modules/orders/views/orders_view.dart';
import 'package:homeqart/app/modules/subscriptions/subscriptionlist.dart';
import 'package:homeqart/app/routes/app_pages.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/main.dart';
import 'package:launch_review/launch_review.dart';
import 'package:share_plus/share_plus.dart';

class DrawerView extends StatefulWidget {
  DrawerView({Key? key}) : super(key: key);

  @override
  State<DrawerView> createState() => _DrawerViewState();
}

class _DrawerViewState extends State<DrawerView> {
  var box2 = GetStorage();
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          buildHeader(),
          Container(
            // padding: padding,
            child: Column(
              children: [
                buildMenuItem(
                  text: 'Dashboard',
                  icon: Icons.dashboard,
                  onClicked: () => selectedItem(context, 8),
                ),
                buildMenuItem(
                  text: 'Coupons',
                  icon: Icons.local_offer_outlined,
                  onClicked: () => selectedItem(context, 7),
                ),
                buildMenuItem(
                  text: 'My Orders',
                  icon: Icons.assessment_outlined,
                  onClicked: () => selectedItem(context, 11),
                ),
                buildMenuItem(
                  text: 'All Brands',
                  icon: Icons.all_inclusive_sharp,
                  onClicked: () => selectedItem(context, 15),
                ),
                buildMenuItem(
                  text: 'All Categories',
                  icon: Icons.list_outlined,
                  onClicked: () => selectedItem(context, 10),
                ),
                buildMenuItem(
                  text: 'Subscription Plans',
                  icon: Icons.subscriptions_outlined,
                  onClicked: () => selectedItem(context, 16),
                ),
                buildMenuItem(
                  text: 'Our FAQ',
                  icon: Icons.quiz_sharp,
                  onClicked: () => selectedItem(context, 2),
                ),
                buildMenuItem(
                  text: 'Contact us',
                  icon: Icons.contact_page_outlined,
                  onClicked: () => selectedItem(context, 3),
                ),
                buildMenuItem(
                  text: 'Share this app',
                  icon: Icons.share,
                  onClicked: () {
                    Share.share(
                      'Hi Check this amazing app https://play.google.com/store/apps/details?id=com.HomeQart',
                    );
                  },
                ),
                buildMenuItem(
                  text: 'Rate this app',
                  icon: Icons.stars,
                  onClicked: () {
                    LaunchReview.launch(
                      androidAppId: "com.HomeQart",
                    );
                  },
                ),
                buildMenuItem(
                  text: 'Privacy policy',
                  icon: Icons.privacy_tip_outlined,
                  onClicked: () => selectedItem(context, 4),
                ),
                buildMenuItem(
                  text: 'Return policy',
                  icon: Icons.settings_backup_restore_sharp,
                  onClicked: () => selectedItem(context, 5),
                ),
                buildMenuItem(
                  text: 'Terms & Conditions',
                  icon: Icons.ac_unit,
                  onClicked: () => selectedItem(context, 6),
                ),
                const Divider(color: Colors.grey),
                buildMenuItem(
                  text: 'Logout',
                  icon: Icons.exit_to_app,
                  onClicked: () {
                    var box2 = GetStorage();
                    box2.erase();
                    Get.offNamedUntil(AppPages.INITIAL, (route) => false);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildHeader() => InkWell(
        onTap: () {},
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
          child: Row(
            children: [
              Container(
                height: 60,
                width: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
                  border: Border.all(color: AppColor.primaryColor),
                ),
                child: ClipOval(
                  child: SizedBox.fromSize(
                    size: Size.fromRadius(48), // Image radius
                    child: CachedNetworkImage(
                      fit: BoxFit.cover,
                      imageUrl:
                          "$baseUrl/storage/app/public/user/${box2.read("image") == null ? "" : box2.read("image")}",
                      placeholder: (context, url) => Icon(
                        Icons.photo,
                        size: 25,
                        color: AppColor.accentLightGrey,
                      ),
                      errorWidget: (context, url, error) => Icon(
                        Icons.person,
                        size: 25,
                        color: AppColor.accentLightGrey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 4),
                  Text("${box2.read('name')}",
                      style: TextStyle(fontSize: 15, color: Colors.black)),
                  SizedBox(height: 4),
                  SizedBox(
                    height: 30,
                    width: 200,
                    child: Text(
                      "${box2.read('email')}",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: Colors.black),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );

  Widget buildMenuItem({
    required String text,
    required IconData icon,
    VoidCallback? onClicked,
  }) {
    final color = Colors.black;
    final hoverColor = Colors.red.shade200;

    return InkWell(
      hoverColor: hoverColor,
      splashColor: hoverColor,
      focusColor: hoverColor,
      highlightColor: hoverColor,
      child: Container(
        width: double.infinity,
        height: 45,
        child: Row(
          children: [
            SizedBox(
              width: 25,
            ),
            Icon(icon, color: color),
            SizedBox(
              width: 18,
            ),
            Text(
              text,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
        alignment: Alignment.center,
      ),
      onTap: onClicked,
    );
  }

  void selectedItem(BuildContext context, int index) {
    Get.back();

    switch (index) {
      case 8:
        Get.to(MainScreen());
        break;
      case 2:
        Get.to(FAQ());

        break;

      case 3:
        Get.to(ContactUs());

        break;

      case 4:
        Get.to(CommonWebViewScreen(
          appBarTitle: "Privacy Policy",
          index: 1,
        ));

        break;
      case 5:
        Get.to(CommonWebViewScreen(
          appBarTitle: "Return Policy",
          index: 2,
        ));

        break;
      case 6:
        Get.to(CommonWebViewScreen(
          appBarTitle: "Terms and conditions",
          index: 0,
        ));

        break;

      case 7:
        Get.to(CouponListScreen());

        break;

      case 11:
        Get.to(OrdersView());
        break;

      case 10:
        Get.to(CategoriesView());

        break;
      case 15:
        Get.to(AllBrandsView());

        break;
      case 16:
        Get.to(SubscriptionsView());

        break;
    }
  }
}
