import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/shopping_cart/model/coupon_response_model.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/services/base_client.dart';

class CouponListScreen extends StatefulWidget {
  CouponListScreen({Key? key}) : super(key: key);

  @override
  _CouponListScreenState createState() => _CouponListScreenState();
}

class _CouponListScreenState extends State<CouponListScreen> {
  bool isLoading = true;
  BaseClient baseClient = BaseClient();
  List<CouponResponse> couponlist = [];

  getWishlist() async {
    var response =
        await baseClient.get(true, "$baseUrl", "/api/v1/coupon/list");

    couponlist = couponResponseFromJson(response);
    isLoading = false;
    setState(() {});
  }

  @override
  void initState() {
    getWishlist();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //  drawer: DrawerView(),
      backgroundColor: AppColor.accentBgColor,
      appBar: CustomAppBar("Coupons"),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : couponlist == null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Container(
                      height: MediaQuery.of(context).size.height / 2 + 68,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          color: AppColor.accentWhite,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/sentiment_dissatisfied.svg',
                              height: 150,
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Text(
                              "Your Couponlist is empty!",
                              style: Texttheme.bodyText1.copyWith(
                                  color: AppColor.accentDarkGrey, fontSize: 20),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            SizedBox(
                              width: double.infinity,
                              child: Text(
                                "",
                                textAlign: TextAlign.center,
                                style: Texttheme.bodyText1.copyWith(
                                    color: AppColor.accentLightGrey,
                                    fontSize: 16),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: DefaultButton(
                                buttonText: "Start Shopping",
                                press: () {
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => const MainScreen(),
                                    ),
                                  );
                                },
                                buttonColor: AppColor.primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  child: SafeArea(
                    child: Column(
                      children: [
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: couponlist.length,
                          itemBuilder: (context, index) {
                            return InkWell(
                              onTap: () {
                                // Navigator.push(context,
                                //     MaterialPageRoute(builder: (_) {
                                //   return ProductDetails(
                                //       id: couponlist[index].code);
                                // }));
                              },
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                child: Column(
                                  children: [
                                    couponlist[index].prime == 0
                                        ? Container(
                                            margin: const EdgeInsets.only(
                                              top: 10,
                                            ),
                                            padding: EdgeInsets.symmetric(
                                                vertical: 10, horizontal: 10),
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.black12),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: AppColor.accentWhite,
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(30.0),
                                              child: Row(
                                                children: [
                                                  const SizedBox(
                                                    width: 14,
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      SizedBox(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width -
                                                            160,
                                                        child: Text(
                                                          "Title: ${couponlist[index].title}",
                                                          maxLines: 2,
                                                          style: Texttheme
                                                              .bodyText1
                                                              .copyWith(
                                                                  color: AppColor
                                                                      .accentLightGrey,
                                                                  fontSize: 18,
                                                                  fontFamily:
                                                                      'InterBold',
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 5.5,
                                                      ),
                                                      SizedBox(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width -
                                                            160,
                                                        child: Text(
                                                          "Code: ${couponlist[index].code}",
                                                          maxLines: 2,
                                                          style: Texttheme
                                                              .bodyText1
                                                              .copyWith(
                                                                  color: AppColor
                                                                      .accentDarkGrey,
                                                                  fontSize: 18,
                                                                  fontFamily:
                                                                      'InterBold',
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 5),
                                                        child: Text(
                                                          "Min purchase: ₹${couponlist[index].minPurchase}",
                                                          maxLines: 2,
                                                          style: Texttheme
                                                              .bodyText1
                                                              .copyWith(
                                                                  color: AppColor
                                                                      .accentLightGrey,
                                                                  fontSize: 18,
                                                                  fontFamily:
                                                                      'InterBold',
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis),
                                                        ),
                                                      ),
                                                      couponlist[index]
                                                                  .discountType ==
                                                              "percent"
                                                          ? Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 5),
                                                              child: Column(
                                                                children: [
                                                                  Text(
                                                                    "Discount: ${couponlist[index].discount}%",
                                                                    maxLines: 2,
                                                                    style: Texttheme.bodyText1.copyWith(
                                                                        color: AppColor
                                                                            .accentLightGrey,
                                                                        fontSize:
                                                                            18,
                                                                        fontFamily:
                                                                            'InterBold',
                                                                        overflow:
                                                                            TextOverflow.ellipsis),
                                                                  ),
                                                                  Text(
                                                                    "Off Upto: ₹${couponlist[index].maxDiscount}",
                                                                    maxLines: 2,
                                                                    style: Texttheme.bodyText1.copyWith(
                                                                        color: AppColor
                                                                            .accentLightGrey,
                                                                        fontSize:
                                                                            18,
                                                                        fontFamily:
                                                                            'InterBold',
                                                                        overflow:
                                                                            TextOverflow.ellipsis),
                                                                  ),
                                                                ],
                                                              ),
                                                            )
                                                          : Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 5),
                                                              child: Text(
                                                                "Discount: ₹${couponlist[index].discount}",
                                                                maxLines: 2,
                                                                style: Texttheme.bodyText1.copyWith(
                                                                    color: AppColor
                                                                        .accentLightGrey,
                                                                    fontSize:
                                                                        18,
                                                                    fontFamily:
                                                                        'InterBold',
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis),
                                                              ),
                                                            ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          )
                                        : Container(
                                            margin: const EdgeInsets.only(
                                              top: 10,
                                            ),
                                            padding: EdgeInsets.symmetric(
                                                vertical: 10, horizontal: 10),
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.black12),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: AppColor.accentWhite,
                                            ),
                                            child: Banner(
                                              message: "Prime",
                                              location: BannerLocation.topEnd,
                                              color: AppColor.primaryColor,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(30.0),
                                                child: Row(
                                                  children: [
                                                    const SizedBox(
                                                      width: 14,
                                                    ),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        SizedBox(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width -
                                                              160,
                                                          child: Text(
                                                            "Title: ${couponlist[index].title}",
                                                            maxLines: 2,
                                                            style: Texttheme.bodyText1.copyWith(
                                                                color: AppColor
                                                                    .accentLightGrey,
                                                                fontSize: 18,
                                                                fontFamily:
                                                                    'InterBold',
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: 5.5,
                                                        ),
                                                        SizedBox(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width -
                                                              160,
                                                          child: Text(
                                                            "Code: ${couponlist[index].code}",
                                                            maxLines: 2,
                                                            style: Texttheme.bodyText1.copyWith(
                                                                color: AppColor
                                                                    .accentDarkGrey,
                                                                fontSize: 18,
                                                                fontFamily:
                                                                    'InterBold',
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 5),
                                                          child: Text(
                                                            "Min purchase: ₹${couponlist[index].minPurchase}",
                                                            maxLines: 2,
                                                            style: Texttheme.bodyText1.copyWith(
                                                                color: AppColor
                                                                    .accentLightGrey,
                                                                fontSize: 18,
                                                                fontFamily:
                                                                    'InterBold',
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis),
                                                          ),
                                                        ),
                                                        couponlist[index]
                                                                    .discountType ==
                                                                "percent"
                                                            ? Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top: 5),
                                                                child: Column(
                                                                  children: [
                                                                    Text(
                                                                      "Discount: ${couponlist[index].discount}%",
                                                                      maxLines:
                                                                          2,
                                                                      style: Texttheme.bodyText1.copyWith(
                                                                          color: AppColor
                                                                              .accentLightGrey,
                                                                          fontSize:
                                                                              18,
                                                                          fontFamily:
                                                                              'InterBold',
                                                                          overflow:
                                                                              TextOverflow.ellipsis),
                                                                    ),
                                                                    Text(
                                                                      "Off Upto: ₹${couponlist[index].maxDiscount}",
                                                                      maxLines:
                                                                          2,
                                                                      style: Texttheme.bodyText1.copyWith(
                                                                          color: AppColor
                                                                              .accentLightGrey,
                                                                          fontSize:
                                                                              18,
                                                                          fontFamily:
                                                                              'InterBold',
                                                                          overflow:
                                                                              TextOverflow.ellipsis),
                                                                    ),
                                                                  ],
                                                                ),
                                                              )
                                                            : Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top: 5),
                                                                child: Text(
                                                                  "Discount: ₹${couponlist[index].discount} ",
                                                                  maxLines: 2,
                                                                  style: Texttheme.bodyText1.copyWith(
                                                                      color: AppColor
                                                                          .accentLightGrey,
                                                                      fontSize:
                                                                          18,
                                                                      fontFamily:
                                                                          'InterBold',
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis),
                                                                ),
                                                              ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }
}
