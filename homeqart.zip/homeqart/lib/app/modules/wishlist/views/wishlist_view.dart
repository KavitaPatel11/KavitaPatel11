import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/modules/wishlist/wishlist_model.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/services/base_client.dart';

import '../controllers/wishlist_controller.dart';

class WishlistView extends StatefulWidget {
  const WishlistView({Key? key}) : super(key: key);

  @override
  _WishlistViewState createState() => _WishlistViewState();
}

class _WishlistViewState extends State<WishlistView> {
  final WishlistController wishlistController = Get.put(WishlistController());

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration.zero, () async {
      wishlistController.fetchwishlist();
    });
    return Scaffold(
        //  drawer: DrawerView(),
        backgroundColor: AppColor.accentBgColor,
        appBar: CustomAppBar("Wishlist"),
        body: Obx(() {
          if (wishlistController.isLoading.value) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (wishlistController.wishlist.value.result!.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  height: MediaQuery.of(context).size.height / 2 + 68,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: AppColor.accentWhite,
                      borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          'assets/icons/sentiment_dissatisfied.svg',
                          height: 150,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Text(
                          "Your wishlist is empty!",
                          style: Texttheme.bodyText1.copyWith(
                              color: AppColor.accentDarkGrey, fontSize: 20),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            "Make your wishlist happy and add your favourite products.",
                            textAlign: TextAlign.center,
                            style: Texttheme.bodyText1.copyWith(
                                color: AppColor.accentLightGrey, fontSize: 16),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: DefaultButton(
                            buttonText: "Add products",
                            press: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const MainScreen(),
                                ),
                              );
                            },
                            buttonColor: AppColor.primaryColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          } else {
            return SingleChildScrollView(
              child: SafeArea(
                child: Column(
                  children: [
                    RefreshIndicator(
                      onRefresh: (() => wishlistController.fetchwishlist()),
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: wishlistController
                                    .wishlist.value.result!.length ==
                                null
                            ? 0
                            : wishlistController.wishlist.value.result!.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              Get.to(() => ProductdetailView(),
                                  arguments: wishlistController.wishlist.value
                                              .result![index].productId ==
                                          null
                                      ? ""
                                      : wishlistController.wishlist.value
                                          .result![index].productId,
                                  preventDuplicates: false);
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Container(
                                margin: const EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black12),
                                  borderRadius: BorderRadius.circular(10),
                                  color: AppColor.accentWhite,
                                ),
                                child: Row(
                                  children: [
                                    wishlistController.wishlist.value
                                                .result![index].image ==
                                            null
                                        ? SizedBox()
                                        : Padding(
                                            padding: const EdgeInsets.only(
                                                top: 7, bottom: 9, left: 10),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: Image.network(
                                                "$baseUrl/storage/app/public/product/" +
                                                    wishlistController
                                                        .wishlist
                                                        .value
                                                        .result![index]
                                                        .image!,
                                                height: 70,
                                                width: 70,
                                              ),
                                            ),
                                          ),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width -
                                              160,
                                          child: Text(
                                            wishlistController.wishlist.value
                                                        .result![index].name ==
                                                    null
                                                ? ""
                                                : wishlistController.wishlist
                                                    .value.result![index].name!,
                                            maxLines: 2,
                                            style: Texttheme.bodyText1.copyWith(
                                                overflow:
                                                    TextOverflow.ellipsis),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 5),
                                          child: Row(
                                            children: [
                                              Text(
                                                "₹ " +
                                                    wishlistController
                                                        .wishlist
                                                        .value
                                                        .result![index]
                                                        .price!
                                                        .toString(),
                                                softWrap: true,
                                                style: Texttheme.title.copyWith(
                                                  color:
                                                      AppColor.accentLightGrey,
                                                  decoration: TextDecoration
                                                      .lineThrough,
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "₹ " +
                                                    wishlistController
                                                        .wishlist
                                                        .value
                                                        .result![index]
                                                        .sellingPrice!
                                                        .toString(),
                                                softWrap: true,
                                                style: Texttheme.title.copyWith(
                                                    color:
                                                        AppColor.neturalOrange),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    Expanded(
                                      child: Container(
                                        alignment: Alignment.centerRight,
                                        child: IconButton(
                                          onPressed: () {
                                            print("wishlist remove");
                                            wishlistController.isLoading.value
                                                ? Center(
                                                    child:
                                                        CircularProgressIndicator(),
                                                  )
                                                : wishlistController
                                                    .addwishlist(
                                                        wishlistController
                                                            .wishlist
                                                            .value
                                                            .result![index]
                                                            .productId!);
                                          },
                                          icon: Icon(
                                            Icons.delete,
                                            color: AppColor.neturalRed,
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(
                      height: 40,
                    )
                  ],
                ),
              ),
            );
          }
        }));
  }
}
