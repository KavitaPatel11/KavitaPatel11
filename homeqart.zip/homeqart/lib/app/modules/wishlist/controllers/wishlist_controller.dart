import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/wishlist/views/wishlist_view.dart';
import 'package:homeqart/app/modules/wishlist/wishlist_model.dart';
import 'package:homeqart/app/modules/wishlist/wishlist_services.dart';
import 'package:homeqart/app/theme.dart';

import 'package:http/http.dart' as http;

class WishlistController extends GetxController {
  var isLoading = true.obs;
  var iswishLoading = true.obs;

  var wishlist = WishListModel().obs;

  @override
  void onInit() async {
    fetchwishlist();

    super.onInit();
  }

  fetchwishlist() async {
    try {
      isLoading(true);
      print("wishlist  try block");
      var wishlists = await WishlistRemoteServices.fetchwishlist();
      print("========= $wishlists ======");
      if (wishlists != null) {
        print(" brands inside controller");
        wishlist.value = wishlists;
      }
    } finally {
      isLoading(false);
    }
  }

  Future<void> addwishlist(int product_id) async {
    
    print(
        "============wish list product_id====================================================$product_id=====");

    Map data = {
      'product_id': '$product_id',
    };

    print(data);
    print(baseUrl);
    final http.Response response = await http.post(
        Uri.parse("$baseUrl/api/v1/customer/wishlist/add"),
        headers: <String, String>{
          'Authorization': 'Bearer ${box2.read("logintoken")}'
        },
        body: data);

    if (response.statusCode == 200) {
      print(response.body);
      print("status wishlist remove api success");
    
      Fluttertoast.showToast(
        msg: "Item remove to your wishlist",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 2,
        backgroundColor: AppColor.primaryColor,
        textColor: Colors.white,
      );
      // Get.back();
      fetchwishlist();
    } else {
      print(response.body);
      print("status  wishlist remove  un successfull");
     
      Fluttertoast.showToast(
        msg: "Item did'nt removed to your wishlist",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 2,
        backgroundColor: AppColor.primaryColor,
        textColor: Colors.white,
      );
      Get.back();
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
