// ignore_for_file: non_constant_identifier_names

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:homeqart/app/modules/home/model/category_model.dart';

import 'package:homeqart/app/modules/home/model/latestproductdata.dart';
import 'package:homeqart/app/modules/home/model/product_model.dart';
import 'package:homeqart/app/modules/wishlist/wishlist_model.dart';
import 'package:http/http.dart' as http;


class WishlistRemoteServices {
  static var client = http.Client();

  static Future<WishListModel?> fetchwishlist() async {
   
    print("============ wishlist api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/customer/wishlist'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("wishlist api successs");
      var jsonString = response.body;
      print("wishlist======= $jsonString");
      print(jsonString);
      return wishListModelFromJson(jsonString);
    } else {
      print(" wishlist api Unsuccesssfull..");
      return null;
    }
  }

}