// To parse this JSON data, do
//
//     final registerUser = registerUserFromJson(jsonString);

import 'dart:convert';

RegisterUser registerUserFromJson(String str) =>
    RegisterUser.fromJson(json.decode(str));

String registerUserToJson(RegisterUser data) => json.encode(data.toJson());

class RegisterUser {
  RegisterUser({
    this.result,
    this.message,
    this.userId,
    this.verified,
  });

  bool? result;
  String? message;
  int? userId;
  String? verified;

  factory RegisterUser.fromJson(Map<String, dynamic> json) => RegisterUser(
        result: json["result"] == null ? null : json["result"],
        message: json["message"] == null ? null : json["message"],
        userId: json["user_id"] == null ? null : json["user_id"],
        verified: json["verified"] == null ? null : json["verified"],
      );

  Map<String, dynamic> toJson() => {
        "result": result == null ? null : result,
        "message": message == null ? null : message,
        "user_id": userId == null ? null : userId,
        "verified": verified == null ? null : verified,
      };
}
