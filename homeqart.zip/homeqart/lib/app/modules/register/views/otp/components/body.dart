import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/register/verify_otp_model.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/services/base_client.dart';

import 'otp_form.dart';

class Body extends StatefulWidget {
  final String mobileNUmber;
  final String userId;

  const Body({Key? key, required this.mobileNUmber, required this.userId})
      : super(key: key);

  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
  BaseClient baseClient = BaseClient();
  VerifyOtpResponse? verifyOtpResponse;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: MediaQuery.of(context).size.height * .2),
            Text(
              "OTP Verification",
              style: Texttheme.heading,
            ),
            Text(
              "We sent your code to ${widget.mobileNUmber}",
              style: Texttheme.subTitle,
            ),
            buildTimer(),
            OtpForm(
              userId: widget.userId,
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () async {
                var data = {"user_id": widget.userId};

                final apiResponse = await showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(baseClient.post(
                    false,
                    "$baseUrl",
                    "/api/v1/auth/resend_code",
                    data,
                  )),
                );

                verifyOtpResponse = verifyOtpResponseFromJson(apiResponse!);
                // final apiResponse = FutureProgressDialog(
                //   baseClient.post(
                //     false,
                //     "$baseUrl",
                //     "/api/v1/auth/resend_code",
                //     data,
                //   ),
                // );
                Fluttertoast.showToast(
                  msg: "${verifyOtpResponse!.message}",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.SNACKBAR,
                  timeInSecForIosWeb: 2,
                  backgroundColor: AppColor.primaryColor,
                  textColor: Colors.white,
                );
              },
              child: const Text(
                "Resend OTP Code",
                style: TextStyle(decoration: TextDecoration.underline),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Row buildTimer() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "This code will expired in 5 minutes ",
          style: Texttheme.subTitle,
        ),
      ],
    );
  }
}
