import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/login/views/login_view.dart';
import 'package:homeqart/app/modules/register/verify_otp_model.dart';
import 'package:homeqart/app/modules/register/views/otp/After_opt_response_data.dart';
import 'package:homeqart/app/modules/splash_screen/views/splash_screen_view.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/otp_text_field.dart';
import 'package:otp_text_field/style.dart';

class OtpForm extends StatefulWidget {
  final String userId;
  const OtpForm({Key? key, required this.userId}) : super(key: key);

  @override
  _OtpFormState createState() => _OtpFormState();
}

class _OtpFormState extends State<OtpForm> {
  BaseClient baseClient = BaseClient();
  VerifyOtpResponse? verifyOtpResponse;
  AfterOtpUserData? afterOtpUserData;
  String otp = "";
  OtpFieldController otpController = OtpFieldController();
  FocusNode? pin2FocusNode;
  FocusNode? pin3FocusNode;
  FocusNode? pin4FocusNode;
  FocusNode? pin5FocusNode;
  FocusNode? pin6FocusNode;

  @override
  void initState() {
    super.initState();
    pin2FocusNode = FocusNode();
    pin3FocusNode = FocusNode();
    pin4FocusNode = FocusNode();
    pin5FocusNode = FocusNode();
    pin6FocusNode = FocusNode();
  }

  @override
  void dispose() {
    super.dispose();
    pin2FocusNode!.dispose();
    pin3FocusNode!.dispose();
    pin4FocusNode!.dispose();
    pin5FocusNode!.dispose();
    pin6FocusNode!.dispose();
  }

  void nextField(String value, FocusNode? focusNode) {
    if (value.length == 1) {
      focusNode!.requestFocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Column(
        children: [
          const SizedBox(height: 15),
          OTPTextField(
              controller: otpController,
              length: 6,
              width: MediaQuery.of(context).size.width,
              textFieldAlignment: MainAxisAlignment.spaceAround,
              fieldWidth: 45,
              fieldStyle: FieldStyle.box,
              outlineBorderRadius: 10,
              style: TextStyle(fontSize: 14),
              onChanged: (pin) {
                setState(() {
                  otp = pin;
                });
                print("Changed: " + pin);
                print("otp: " + otp);
              },
              onCompleted: (pin) {
                print("Completed: " + pin);
                setState(() {
                  otp = pin;
                });
                print("otp: " + otp);
              }),
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //   children: [
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         autofocus: true,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           var temp = otp + value;
          //           otp = temp;
          //           nextField(value, pin2FocusNode);
          //         },
          //       ),
          //     ),
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         focusNode: pin2FocusNode,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           var temp = otp + value;
          //           otp = temp;
          //           nextField(value, pin3FocusNode);
          //         },
          //       ),
          //     ),
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         focusNode: pin3FocusNode,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           var temp = otp + value;
          //           otp = temp;
          //           nextField(value, pin4FocusNode);
          //         },
          //       ),
          //     ),
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         focusNode: pin4FocusNode,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           var temp = otp + value;
          //           otp = temp;
          //           nextField(value, pin5FocusNode);
          //         },
          //       ),
          //     ),
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         focusNode: pin5FocusNode,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           var temp = otp + value;
          //           otp = temp;
          //           nextField(value, pin6FocusNode);
          //         },
          //       ),
          //     ),
          //     SizedBox(
          //       width: 50,
          //       child: TextFormField(
          //         focusNode: pin6FocusNode,
          //         obscureText: true,
          //         style: const TextStyle(fontSize: 24),
          //         keyboardType: TextInputType.number,
          //         textAlign: TextAlign.center,
          //         decoration: otpInputDecoration,
          //         onChanged: (value) {
          //           if (value.length == 1) {
          //             pin6FocusNode!.unfocus();
          //             var temp = otp + value;
          //             otp = temp;
          //             // Then you need to check is the code is correct or not
          //           }
          //         },
          //       ),
          //     ),
          //   ],
          // ),
          const SizedBox(height: 15),
          DefaultButton(
            buttonText: "Continue",
            press: () async {
              Map<String, dynamic> dataBody = {
                "user_id": widget.userId,
                "otp_code": otp
              };
              print(dataBody);
              var dataToSend = json.encode(dataBody);

              var response = await http.post(
                  Uri.parse("$baseUrl/api/v1/auth/confirm_code"),
                  headers: <String, String>{
                    'Content-Type': 'application/json; charset=UTF-8',
                  },
                  body: dataToSend);
              print(response);
              print(response.body);
              print(response.statusCode);

              if (response.statusCode == 200) {
                Map<String, dynamic> responseData = jsonDecode(response.body);
                if (responseData['message'] == "Successfully logged in") {
                  box2.write("logintoken", responseData['access_token']);
                  box2.write("result", responseData['result']);
                  box2.write("name", responseData['user']['name']);
                  box2.write("email", responseData['user']['email']);
                  box2.write("id", responseData['user']['id']);
                  box2.write("phone", responseData['user']['phone']);
                  box2.write("image", responseData['user']['image']);
                  box2.write(
                      "provider_id", responseData['user']['provider_id']);
                  box2.write("verified", responseData['user']['verified']);
                  box2.write("is_prime", responseData['user']['is_prime']);

                  print(
                      "=================logintokn======${box2.read("logintoken")}================");
                  print(
                      "=================verified======${box2.read("verified")}================");

                  Get.snackbar(
                    "Successfully ",
                    "Logged in...",
                    backgroundColor: Colors.green,
                    snackPosition: SnackPosition.BOTTOM,
                    borderRadius: 10,
                    borderWidth: 2,
                    colorText: Colors.white,
                  );

                  Get.offAll(() => SplashScreenView());
                } else {
                  Get.snackbar(
                    "Invalid OTP",
                    "${responseData['message']}",
                    backgroundColor: AppColor.neturalOrange,
                    snackPosition: SnackPosition.BOTTOM,
                    borderRadius: 10,
                    borderWidth: 2,
                    colorText: Colors.white,
                  );
                }
              } else {
                Get.snackbar(
                  "Invalid OTP",
                  "",
                  backgroundColor: AppColor.neturalOrange,
                  snackPosition: SnackPosition.BOTTOM,
                  colorText: Colors.white,
                  borderRadius: 10,
                  borderWidth: 2,
                );
              }
            },
            buttonColor: AppColor.primaryColor,
          )
        ],
      ),
    );
  }
}
