import 'package:flutter/material.dart';
import 'package:homeqart/app/constent.dart';

import 'package:homeqart/components/appbar_without_actions.dart';

import 'components/body.dart';
import 'components/body2_otp_screen.dart';

class SecondOtpScreen extends StatelessWidget {
  final String mobileNUmber;
  final String userId;

  const SecondOtpScreen(
      {Key? key, required this.mobileNUmber, required this.userId})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("OTP Verification"),
      body: SecondScreenBody(
        mobileNUmber: box2.read("phone").toString(),
        userId: box2.read("id").toString(),
      ),
    );
  }
}
