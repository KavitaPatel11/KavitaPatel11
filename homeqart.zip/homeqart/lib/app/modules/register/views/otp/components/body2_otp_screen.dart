import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/register/verify_otp_model.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/services/base_client.dart';

import '../otp_screen_sencond.dart';
import 'otp_form.dart';
import 'otp_form_second.dart';

class SecondScreenBody extends StatefulWidget {
  final String mobileNUmber;
  final String userId;

  const SecondScreenBody(
      {Key? key, required this.mobileNUmber, required this.userId})
      : super(key: key);

  @override
  State<SecondScreenBody> createState() => _SecondScreenBodyState();
}

class _SecondScreenBodyState extends State<SecondScreenBody> {
  BaseClient baseClient = BaseClient();
  VerifyOtpResponse? verifyOtpResponse;
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration.zero, () async {
      var data = {"user_id": "${box2.read("id")}"};

      final apiResponse = await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(baseClient.post(
          false,
          "$baseUrl",
          "/api/v1/auth/resend_code",
          data,
        )),
      );
      // final apiResponse = FutureProgressDialog(
      //   baseClient.post(
      //     false,
      //     "$baseUrl",
      //     "/api/v1/auth/resend_code",
      //     data,
      //   ),
      // );

      verifyOtpResponse = verifyOtpResponseFromJson(apiResponse!);

      Fluttertoast.showToast(
        msg: "${verifyOtpResponse!.message}",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 2,
        backgroundColor: AppColor.primaryColor,
        textColor: Colors.white,
      );
    });
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: MediaQuery.of(context).size.height * .2),
            Text(
              "Your account is not verified ",
              style: Texttheme.heading,
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "OTP Verification",
              style: Texttheme.heading,
            ),
            Text(
              "We sent your code to ${widget.mobileNUmber}",
              style: Texttheme.subTitle,
            ),
            buildTimer(),
            SecondOtpForm(
              userId: "${box2.read("id")}",
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () async {
                // var data = {"user_id": "${box2.read("id")}"};

                // final apiResponse = await showDialog(
                //   context: context,
                //   builder: (context) => FutureProgressDialog(baseClient.post(
                //     false,
                //     "$baseUrl",
                //     "/api/v1/auth/resend_code",
                //     data,
                //   )),
                // );

                // verifyOtpResponse = verifyOtpResponseFromJson(apiResponse!);
                // final apiResponse = FutureProgressDialog(
                //   baseClient.post(
                //     false,
                //     "$baseUrl",
                //     "/api/v1/auth/resend_code",
                //     data,
                //   ),
                // );
                // Fluttertoast.showToast(
                //   msg: "${verifyOtpResponse!.message}",
                //   toastLength: Toast.LENGTH_SHORT,
                //   gravity: ToastGravity.SNACKBAR,
                //   timeInSecForIosWeb: 2,
                //   backgroundColor: AppColor.primaryColor,
                //   textColor: Colors.white,
                // );
                Navigator.push(context, MaterialPageRoute(builder: (_) {
                  return SecondOtpScreen(
                    mobileNUmber: box2.read("phone").toString(),
                    userId: box2.read("id").toString(),
                  );
                }));
              },
              child: const Text(
                "Resend OTP Code",
                style: TextStyle(decoration: TextDecoration.underline),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Row buildTimer() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "This code will expired in 5 minutes ",
          style: Texttheme.subTitle,
        ),
      ],
    );
  }
}
