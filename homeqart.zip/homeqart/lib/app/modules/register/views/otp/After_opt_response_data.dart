// To parse this JSON data, do
//
//     final afterOtpUserData = afterOtpUserDataFromJson(jsonString);

import 'dart:convert';

AfterOtpUserData afterOtpUserDataFromJson(String str) =>
    AfterOtpUserData.fromJson(json.decode(str));

String afterOtpUserDataToJson(AfterOtpUserData data) =>
    json.encode(data.toJson());

class AfterOtpUserData {
  AfterOtpUserData({
    this.result,
    this.message,
    this.accessToken,
    this.tokenType,
    this.expiresAt,
    this.user,
  });

  bool? result;
  String? message;
  String? accessToken;
  String? tokenType;
  DateTime? expiresAt;
  User? user;

  factory AfterOtpUserData.fromJson(Map<String, dynamic> json) =>
      AfterOtpUserData(
        result: json["result"] == null ? null : json["result"],
        message: json["message"] == null ? null : json["message"],
        accessToken: json["access_token"] == null ? null : json["access_token"],
        tokenType: json["token_type"] == null ? null : json["token_type"],
        expiresAt: json["expires_at"] == null
            ? null
            : DateTime.parse(json["expires_at"]),
        user: json["user"] == null ? null : User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "result": result == null ? null : result,
        "message": message == null ? null : message,
        "access_token": accessToken == null ? null : accessToken,
        "token_type": tokenType == null ? null : tokenType,
        "expires_at": expiresAt == null ? null : expiresAt!.toIso8601String(),
        "user": user == null ? null : user!.toJson(),
      };
}

class User {
  User({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.image,
    this.providerId,
    this.cityId,
    this.city,
    this.verified,
    this.isPrime,
  });

  int? id;
  String? name;
  String? email;
  String? phone;
  String? image;
  dynamic providerId;
  int? cityId;
  String? city;
  String? verified;
  String? isPrime;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        email: json["email"] == null ? null : json["email"],
        phone: json["phone"] == null ? null : json["phone"],
        image: json["image"] == null ? null : json["image"],
        providerId: json["provider_id"],
        cityId: json["city_id"] == null ? null : json["city_id"],
        city: json["city"] == null ? null : json["city"],
        verified: json["verified"] == null ? null : json["verified"],
        isPrime: json["is_prime"] == null ? null : json["is_prime"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "email": email == null ? null : email,
        "phone": phone == null ? null : phone,
        "image": image == null ? null : image,
        "provider_id": providerId,
        "city_id": cityId == null ? null : cityId,
        "city": city == null ? null : city,
        "verified": verified == null ? null : verified,
        "is_prime": isPrime == null ? null : isPrime,
      };
}
