import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'package:homeqart/app/modules/login/views/components/body.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

import '../controllers/login_controller.dart';

class LoginView extends GetView<LoginController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColor.accentBgColor,
        appBar: CustomAppBar("Sign In"),
        body: Body());
  }
}
