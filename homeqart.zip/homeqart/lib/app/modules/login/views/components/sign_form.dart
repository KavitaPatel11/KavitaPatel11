import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/forgot_password/forgot_password_screen.dart';
import 'package:homeqart/app/modules/helper/keyboard_helper.dart';
import 'package:homeqart/app/modules/login/controllers/login_controller.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/components/form_error.dart';
import 'package:sms_autofill/sms_autofill.dart';

class SignForm extends StatefulWidget {
  const SignForm({Key? key}) : super(key: key);

  @override
  _SignFormState createState() => _SignFormState();
}

class _SignFormState extends State<SignForm> {
  final _formKey = GlobalKey<FormState>();

  final phoneNumberController = TextEditingController();
  final passwordController = TextEditingController();
  bool? remember = false;
  final List<String?> errors = [];
  final LoginController loginController = Get.put(LoginController());
  void addError({String? error}) {
    if (!errors.contains(error)) {
      setState(() {
        errors.add(error);
      });
    }
  }

  void removeError({String? error}) {
    if (errors.contains(error)) {
      setState(() {
        errors.remove(error);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildEmailFormField(),
          const SizedBox(height: 15),
          buildPasswordFormField(),
          const SizedBox(height: 15),
          Row(
            children: [
              Checkbox(
                value: remember,
                activeColor: AppColor.primaryColor,
                onChanged: (value) {
                  setState(() {
                    remember = value;
                  });
                },
              ),
              const Text("Remember me"),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  Get.to(ForgotPasswordScreen());
                },
                // onTap: () => Navigator.push(context,
                //     MaterialPageRoute(builder: (context) {
                //   return const ForgotPasswordScreen();
                // })),
                child: const Text(
                  "Forgot Password",
                  style: TextStyle(decoration: TextDecoration.underline),
                ),
              )
            ],
          ),
          FormError(errors: errors),
          const SizedBox(height: 20),
          Obx(
            () => loginController.isDataSubmitting.value == false
                ? DefaultButton(
                    buttonText: "Continue",
                    press: () {
                      userLogin();
                    },
                    buttonColor: AppColor.primaryColor)
                : CircularProgressIndicator(),
          ),
        ],
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      obscureText: true,
      controller: passwordController,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPassNullError);
        } else if (value.length >= 8) {
          removeError(error: kShortPassError);
        }
        return;
      },
      validator: (value) {
        if (value!.isEmpty) {
          addError(error: kPassNullError);
          return "";
        } else if (value.length < 8) {
          addError(error: kShortPassError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
          hintText: "Enter your password",
          fillColor: AppColor.accentWhite,
          filled: true,
          prefixIcon: const Icon(Icons.security),
          border: InputBorder.none),
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      maxLength: 10,
      keyboardType: TextInputType.phone,
      controller: phoneNumberController,
      onChanged: (value) {
        // if (value.isNotEmpty) {
        //   removeError(error: kEmailNullError);
        // } else if (emailValidatorRegExp.hasMatch(value)) {
        //   removeError(error: kInvalidEmailError);
        // }
        // return;
      },
      validator: (value) {
        // if (value!.isEmpty) {
        //   addError(error: kEmailNullError);
        //   return "";
        // } else if (!emailValidatorRegExp.hasMatch(value)) {
        //   addError(error: kInvalidEmailError);
        //   return "";
        // }
        // return null;
      },
      decoration: InputDecoration(
          counterText: "",
          hintText: "Enter your phone number",
          fillColor: AppColor.accentWhite,
          filled: true,
          floatingLabelBehavior: FloatingLabelBehavior.always,
          prefixIcon: const Icon(Icons.person),
          border: InputBorder.none),
    );
  }

  void userLogin() {
    final _isValid = _formKey.currentState!.validate();
    if (_isValid) {
      // print(useridController.text);
      // print(passController.text);

      loginController.loginWithDetail(
          phoneNumberController.text, passwordController.text);
    }
    {
      return null;
    }
  }
}
