import 'package:homeqart/app/constent.dart';

class CustomWebServices {
  static String signup_api_url =
      "https://thedigitalgamezone.com/Abhi/flutter-tutorial-api/signUpUserAPI.php";

  static String login_url =
      "$baseUrl/api/v1/auth/login";

  static String PROFILE_IMAGE = "image";
  static String USER_NAME = "name";
  static String USER_EMAIL = "email";
  static String USER_MOBILE = "phone";
  static String USER_ID = "id";
  static String USER_PASS = "userPass";
}