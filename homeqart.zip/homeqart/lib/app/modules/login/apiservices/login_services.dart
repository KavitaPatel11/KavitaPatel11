



// import 'dart:convert';

// import 'package:homeqart/app/constent.dart';
// import 'package:homeqart/app/modules/home/model/product_model.dart';
// import 'package:homeqart/app/modules/login/model/login_response_model.dart';
// import 'package:homeqart/app/modules/login/model/user_data_list.dart';
// import 'package:homeqart/app/modules/productdetail/product_detail_model.dart';
// import 'package:http/http.dart' as http;


// class LoginRemoteServices {
//   static var client = http.Client();

//   static Future<LoginResponse?> fetchlogin(String phone, String password ) async {
//     print("============ orderDetailData api calling=======");
    
//        Map<String, dynamic> dataBody = {
//       "phone": phone,
//       "password": password,
//     };
//     print(dataBody);
//     var dataToSend = json.encode(dataBody);

//     var response = await client.post(
//       Uri.parse('$baseUrl/api/v1/auth/login'),
//       headers: {
//         'Content-Type': 'application/json; charset=UTF-8',
//         'Authorization': 'Bearer ${box2.read("logintoken")}',
//       },
//        body: dataToSend
//     );
//     if (response.statusCode == 200) {
//       print("orderDetailData api successs");
//       var jsonString = response.body;
//       print("orderDetailData $jsonString");
//       print(jsonString);
//       return loginResponseFromJson(jsonString);
//     } else {
//       print("orderDetailData api Unsuccesssfull..");
//       return null;
//     }
//   }



// }
