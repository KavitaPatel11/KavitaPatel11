class UserDataList {
  static String? name = "";
  static String? email = "";
  static String? mobile = "";
  static String? id = "".toString();
  static String? profilePic = "";
}