import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:get_storage/get_storage.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/login/apiservices/custum_webserices.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/login/model/login_response_model.dart';
import 'package:homeqart/app/modules/login/model/user_data_list.dart';
import 'package:homeqart/app/modules/splash_screen/views/splash_screen_view.dart';

import 'package:http/http.dart' as http;
import 'package:get/get.dart';

class LoginController extends GetxController {
  var isDataSubmitting = false.obs;
  var isFacebookDataloading = false.obs;
  var isfacebookDataSubmitting = false.obs;
  var isDataReadingCompleted = false.obs;
  LoginResponse? loginResponse;
  final box2 = GetStorage();
  Map<String, dynamic>? _userData;

  String welcome = "Facebook";

  loginWithDetail(String phone, String password) async {
    isDataSubmitting.value = true;

    Map<String, dynamic> dataBody = {
      "phone": phone,
      "password": password,
    };
    print(dataBody);
    var dataToSend = json.encode(dataBody);

    var response = await http.post(Uri.parse("$baseUrl/api/v1/auth/login"),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: dataToSend);
    print(response);
    print(response.body);
    print(response.statusCode);

    if (response.statusCode == 200) {
      isDataSubmitting.value = false;
      Map<String, dynamic> responseData = jsonDecode(response.body);
      if (responseData['message'] == "Successfully logged in") {
        box2.write("logintoken", responseData['access_token']);
        box2.write("result", responseData['result']);
        box2.write("name", responseData['user']['name']);
        box2.write("email", responseData['user']['email']);
        box2.write("id", responseData['user']['id']);
        box2.write("phone", responseData['user']['phone']);
        box2.write("image", responseData['user']['image']);
        box2.write("provider_id", responseData['user']['provider_id']);
        box2.write("verified", responseData['user']['verified']);
        box2.write("is_prime", responseData['user']['is_prime']);

        print(
            "=================logintokn======${box2.read("logintoken")}================");

        isDataReadingCompleted.value = true;
        if (box2.read("verified") == "1") {
          Get.snackbar(
            "Successfully ",
            "Logged in...",
            backgroundColor: Colors.green,
            snackPosition: SnackPosition.BOTTOM,
            borderRadius: 10,
            borderWidth: 2,
            colorText: Colors.white,
          );
        }

        Get.offAll(() => SplashScreenView());
      } else {
        Get.snackbar(
          "Login Failed",
          "Invalid User Id / Password",
          backgroundColor: Colors.black,
          snackPosition: SnackPosition.BOTTOM,
          borderRadius: 10,
          borderWidth: 2,
          colorText: Colors.white,
        );
      }
    } else {
      isDataSubmitting.value = false;
      Get.snackbar(
        "Login Failed",
        "Invalid User Id / Password",
        backgroundColor: Colors.black,
        snackPosition: SnackPosition.BOTTOM,
        colorText: Colors.white,
        borderRadius: 10,
        borderWidth: 2,
      );
    }
  }

  loginWithfacebbok() async {
    isFacebookDataloading.value == true;
    isfacebookDataSubmitting.value == false;

    final result =
        await FacebookAuth.i.login(permissions: ['public_profile', 'email']);
    if (result.status == LoginStatus.success) {
      final userData = await FacebookAuth.i.getUserData();
      print(userData);
      _userData = userData;

      String userid = _userData?['id'];
      String name = _userData?['name'];
      String email = _userData?['email'];
      String profile_image = _userData?['picture']['data']['url'];
      print(userid);
      // loginController.loginWithfacebbok(userid, _userData?['name'],
      //     _userData?['picture']['data']['url'], _userData?['email']);

      print("login with facebook is calling");
      isfacebookDataSubmitting.value = false;

      Map<String, dynamic> dataBody = {
        "id": userid,
        "name": name,
        "avatar": profile_image,
        "email": email,
      };
      print(dataBody);
      var dataToSend = json.encode(dataBody);

      var response =
          await http.post(Uri.parse("$baseUrl/api/v1/auth/facebook_login"),
              headers: <String, String>{
                'Content-Type': 'application/json; charset=UTF-8',
              },
              body: dataToSend);
      print(response);
      print(response.body);

      print(response.statusCode);

      if (response.statusCode == 200) {
        isfacebookDataSubmitting.value == false;
        Map<String, dynamic> responseData = jsonDecode(response.body);
        if (responseData['message'] == "Successfully logged in") {
          box2.write("logintoken", responseData['access_token']);
          box2.write("result", responseData['result']);
          box2.write("name", responseData['user']['name']);
          box2.write("email", responseData['user']['email']);
          box2.write("id", responseData['user']['id']);
          box2.write("phone", responseData['user']['phone']);
          box2.write("image", responseData['user']['image']);
          box2.write("provider_id", responseData['user']['provider_id']);
          box2.write("verified", responseData['user']['verified']);
          box2.write("is_prime", responseData['user']['is_prime']);

          print(
              "=================logintokn======${box2.read("logintoken")}================");

          isDataReadingCompleted.value = true;
          isfacebookDataSubmitting.value = true;

          Get.offAll(() => SplashScreenView());
        } else {
          Get.snackbar(
            "Login Failed",
            "Invalid User Id / Password",
            backgroundColor: Colors.black,
            snackPosition: SnackPosition.BOTTOM,
            borderRadius: 10,
            borderWidth: 2,
            colorText: Colors.white,
          );
        }
      } else {
        isfacebookDataSubmitting.value = false;
        Get.snackbar(
          "Login Failed",
          "Invalid User Id / Password",
          backgroundColor: Colors.black,
          snackPosition: SnackPosition.BOTTOM,
          colorText: Colors.white,
          borderRadius: 10,
          borderWidth: 2,
        );
      }
    } else {
      print(result.message);
    }
  }
}
