import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../../components/appbar_without_actions.dart';
import '../../../../services/base_client.dart';
import '../../../theme.dart';
import '../../common_model/subscription_payment_modal.dart';
import '../../subscriptions/subscriptionlist.dart';

class PaymentMethod extends StatefulWidget {
  PaymentMethod({Key? key}) : super(key: key);

  @override
  State<PaymentMethod> createState() => _PaymentMethodState();
}

class _PaymentMethodState extends State<PaymentMethod> {
  TextEditingController _paymentController = TextEditingController();

  late Razorpay _razorpay;

  bool isLoading = true;

  BaseClient baseClient = BaseClient();
  SubscriptionPaymentModal? paymentModal;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar("Subscription Plans"),
      body: Center(
        child: SingleChildScrollView(
            child: Column(
          children: [
            Container(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ElevatedButton(
                  child: Text('Pay with razorpay'),
                  onPressed: () {
                    openCheckout();
                  },
                  style: ElevatedButton.styleFrom(
                      primary: AppColor.accentLightGrey,
                      padding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      textStyle: TextStyle(
                        fontSize: 22,
                      )),
                ),
              ),
            ),
          ],
        )),
      ),
    );
  }

  void openCheckout() async {
    var totalamount = Get.arguments;
    var options = {
      'key': 'rzp_live_Kzp45jq38QNrLM',
      'amount': (double.parse(totalamount[2]['amount']) * 100.roundToDouble())
          .toString(),
      'name': "${box2.read("name")}",
      'description': 'HomeQart',
      'retry': {'enabled': true, 'max_count': 1},
      'send_sms_hash': true,
      'prefill': {'contact': '', 'email': ''},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Error: e');
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    isLoading == true;
    var argu = Get.arguments;
    var data = {
      "payment_id": "${response.paymentId}",
      "amount": "${argu[2]['amount']}",
      "s_name": "${argu[1]['s_name']}",
      "s_id": "${argu[0]['s_id']}",
      "razorpay_id": response.paymentId!.toString(),
      "u_name": "${box2.read("name")}",
      "u_id": "${box2.read("id")}",
      "duration": "${argu[3]['duration']}",
    };
    print("subscription data");
    print(data);

    final apiResponse = await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(
        baseClient.post(true, "$baseUrl", "/api/v1/subscription/s_pay", data),
      ),
    );

    isLoading = false;

    Get.to(SubscriptionsView());
    Fluttertoast.showToast(
      msg: 'Payment successfull :',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 3,
      backgroundColor: AppColor.primaryColor,
      textColor: Colors.white,
    );
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
      msg: "Something went wrong,Please try again",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 3,
      backgroundColor: AppColor.neturalOrange,
      textColor: Colors.white,
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName!,
        toastLength: Toast.LENGTH_SHORT);
  }
}
