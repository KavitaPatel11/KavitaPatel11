import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:get/get.dart';

import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/order_placed_model.dart';
import 'package:homeqart/app/modules/common_model/time_slot_model.dart';
import 'package:homeqart/app/modules/order_status/login_success_screen.dart';
import 'package:homeqart/app/modules/payment_option/views/rozar_pay.dart';
import 'package:homeqart/app/modules/status_screen.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/default_button.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:intl/intl.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../shopping_cart/model/cart_summery_model.dart';

class PaymentOptionView extends StatefulWidget {
  const PaymentOptionView({Key? key}) : super(key: key);

  @override
  _PaymentOptionViewState createState() => _PaymentOptionViewState();
}

class _PaymentOptionViewState extends State<PaymentOptionView> {
  OrderPlacedModel? orderPlacedModel;
  int? selectedValue;
  bool isLoading = true;
  DateTime deliveryDate = DateTime.now();
  BaseClient baseClient = BaseClient();
  final suggetionController = TextEditingController();
  int _radioSelected = 1;
  String _radioVal = "";
  CartSummaryModel? cartSummaryModel;
  late Razorpay _razorpay;
  final _checkoutformKey = GlobalKey<FormState>();

  List<TimeSlotModel> slots = [];

  getOrderSummary() async {
    final apiResponse = await baseClient.get(
        true, "$baseUrl", "/api/v1/customer/cart/cart_value");
    cartSummaryModel = cartSummaryModelFromJson(apiResponse);
    isLoading = false;
    setState(() {});
  }

  Future<void> _selectCompletionDate(context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != deliveryDate) {
      setState(() {
        deliveryDate = picked;
      });
    }
  }

  getDeliverySlot() async {
    final apiResponse =
        await baseClient.get(true, "$baseUrl", "/api/v1/timeSlot");
    slots = timeSlotModelFromJson(apiResponse);
    isLoading = false;
    setState(() {});
  }

  @override
  void initState() {
    //  implement initState

    getDeliverySlot();
    getOrderSummary();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.accentBgColor,
      appBar: CustomAppBar("Select Payment Option"),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Form(
                    key: _checkoutformKey,
                    child: Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: _radioSelected == 1
                                      ? AppColor.neturalRed
                                      : AppColor.accentWhite),
                              color: AppColor.accentWhite,
                              borderRadius: BorderRadius.circular(10)),
                          height: 70,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Radio(
                                value: 1,
                                groupValue: _radioSelected,
                                activeColor: Colors.blue,
                                onChanged: (value) {
                                  setState(() {
                                    _radioSelected = value as int;
                                    _radioVal = 'COD';
                                    print(_radioVal);
                                  });
                                },
                              ),
                              Container(
                                height: 80,
                                width: 280,
                                decoration: BoxDecoration(
                                    color: AppColor.accentWhite,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: ListTile(
                                    leading: Container(
                                        height: 60,
                                        width: 50,
                                        decoration: BoxDecoration(
                                            color: AppColor.neturalOrange,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Icon(
                                          Icons.delivery_dining_sharp,
                                          size: 45,
                                          color: AppColor.accentWhite,
                                        )),
                                    title: Text(
                                      "Cash on delivery",
                                      style: Texttheme.title.copyWith(
                                          color: AppColor.accentDarkGrey),
                                    ),
                                    subtitle: Text(
                                      'Get your product deliverd to your door steps',
                                      style: Texttheme.bodyText1.copyWith(
                                          color: AppColor.accentLightGrey),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: _radioSelected == 2
                                      ? AppColor.neturalRed
                                      : AppColor.accentWhite),
                              color: AppColor.accentWhite,
                              borderRadius: BorderRadius.circular(10)),
                          height: 70,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Radio(
                                value: 2,
                                groupValue: _radioSelected,
                                activeColor: Colors.blue,
                                onChanged: (value) {
                                  setState(() {
                                    _radioSelected = value as int;
                                    _radioVal = 'Razorpay';
                                    print(_radioVal);
                                  });
                                },
                              ),
                              Container(
                                height: 80,
                                width: 280,
                                decoration: BoxDecoration(
                                    color: AppColor.accentWhite,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: ListTile(
                                    leading: Container(
                                      height: 60,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          image: new DecorationImage(
                                            image: new AssetImage(
                                                "assets/images/razorpay.png"),
                                            fit: BoxFit.fill,
                                          ),
                                          color: AppColor.accentWhite,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                    ),
                                    title: Text(
                                      "Razorpay",
                                      style: Texttheme.title.copyWith(
                                          color: AppColor.accentDarkGrey),
                                    ),
                                    subtitle: Text(
                                      'Get your product deliverd to your door steps',
                                      style: Texttheme.bodyText1.copyWith(
                                          color: AppColor.accentLightGrey),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                              color: AppColor.accentWhite,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Prefered Delivery date and time",
                                  style: Texttheme.subTitle,
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  children: [
                                    SizedBox(
                                      height: 60,
                                      child: OutlinedButton(
                                        onPressed: () {
                                          _selectCompletionDate(context);
                                        },
                                        style: OutlinedButton.styleFrom(
                                          side: BorderSide(
                                            width: 1,
                                            color: AppColor.primaryColor,
                                          ),
                                          backgroundColor: AppColor.accentWhite,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                        ),
                                        child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 10, horizontal: 5),
                                            child: Text(
                                                DateFormat('d MMM yyyy')
                                                    .format(deliveryDate),
                                                style: Texttheme.bodyText2)),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Expanded(
                                      child: Container(
                                        height: 60,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12),
                                        decoration: BoxDecoration(
                                          color: AppColor.accentWhite,
                                          border: Border.all(
                                            color: AppColor.primaryColor,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: DropdownButtonHideUnderline(
                                            child: ButtonTheme(
                                          alignedDropdown: true,
                                          child: DropdownButtonFormField<int>(
                                            decoration: InputDecoration(
                                              enabledBorder: InputBorder.none,
                                            ),
                                            isExpanded: true,
                                            hint: Text(
                                              'Select preferd time slot',
                                              style: Texttheme.caption2,
                                            ),
                                            value: selectedValue,
                                            validator: (value) => value == null
                                                ? 'field required '
                                                : null,
                                            icon: const Icon(
                                              Icons
                                                  .keyboard_arrow_down_outlined,
                                              color: Colors.black,
                                            ),
                                            iconSize: 20,
                                            onChanged: (newValue) {
                                              selectedValue = newValue!;
                                              setState(() {
                                                selectedValue = newValue;
                                              });
                                            },
                                            items: slots.map((item) {
                                              return DropdownMenuItem(
                                                child: Text(
                                                  '${item.startTime} - ${item.endTime}',
                                                  style: Texttheme.bodyText2,
                                                ),
                                                value: item.id,
                                              );
                                            }).toList(),
                                          ),
                                        )),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        TextFormField(
                          controller: suggetionController,
                          maxLines: 4,
                          decoration: InputDecoration(
                              hintText: "Write your suggetions here........",
                              hintStyle: Texttheme.bodyText2,
                              fillColor: AppColor.accentWhite,
                              filled: true,
                              border: InputBorder.none),
                          // validator: (value) {
                          //   if (value == null || value.isEmpty) {
                          //     return 'Please enter some text';
                          //   }
                          //   return null;
                          // },
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        _radioVal == "Razorpay"
                            ? DefaultButton(
                                buttonText: "Pay now",
                                press: () async {
                                  if (_checkoutformKey.currentState!
                                      .validate()) {
                                    openCheckout();
                                  } else {
                                    return;
                                  }
                                },
                                buttonColor: AppColor.neturalOrange)
                            : DefaultButton(
                                buttonText: "Place Order",
                                press: () async {
                                  if (_checkoutformKey.currentState!
                                      .validate()) {
                                    var data = {
                                      "payment_type": "COD",
                                      "delivery_date": deliveryDate.toString(),
                                      "order_note": suggetionController.text,
                                      "timeSlot": selectedValue.toString()
                                    };

                                    print(
                                        "==============================================order  data $data");

                                    final apiResponse = await showDialog(
                                      context: context,
                                      builder: (context) =>
                                          FutureProgressDialog(
                                        baseClient.post(true, "$baseUrl",
                                            "/api/v1/customer/order", data),
                                      ),
                                    );

                                    orderPlacedModel =
                                        orderPlacedModelFromJson(apiResponse);
                                    Navigator.pushReplacement(context,
                                        MaterialPageRoute(
                                      builder: (context) {
                                        return LoginSuccessScreen(
                                          odrId: orderPlacedModel!.orderId!
                                              .toString(),
                                          message: orderPlacedModel!.message!,
                                        );
                                      },
                                    ));
                                  }
                                },
                                buttonColor: AppColor.primaryColor,
                              )
                      ],
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  void openCheckout() async {
    var options = {
      'key': 'rzp_live_Kzp45jq38QNrLM',
      // "amount": (double.parse(30.toString()) * 100.roundToDouble()),
      // //     .toString()
      'amount': (double.parse(cartSummaryModel!.total.toString()) *
              100.roundToDouble())
          .toString(),
      'name': '${box2.read("name")}',
      'description': 'Homeqart',
      // 'retry': {'enabled': true, 'max_count': 1},
      'send_sms_hash': true,
      'prefill': {'contact': '', 'email': ''},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Error: e');
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    Fluttertoast.showToast(
      msg: 'Payment successfull :',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 3,
      backgroundColor: AppColor.primaryColor,
      textColor: Colors.white,
    );

    isLoading = true;
    var data = {
      "payment_type": "PAY",
      "delivery_date": deliveryDate.toString(),
      "order_note": suggetionController.text,
      "timeSlot": selectedValue.toString(),
      "razorpay_payment_id": response.paymentId!.toString()
    };

    final apiResponse = await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(
        baseClient.post(true, "$baseUrl", "/api/v1/customer/order", data),
      ),
    );

    orderPlacedModel = orderPlacedModelFromJson(apiResponse);
    isLoading = false;

    Navigator.pushReplacement(context, MaterialPageRoute(
      builder: (context) {
        return LoginSuccessScreen(
          odrId: orderPlacedModel!.orderId!.toString(),
          message: orderPlacedModel!.message!,
        );
      },
    ));
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
      msg: "Something went wrong,Please try again",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 3,
      backgroundColor: AppColor.neturalOrange,
      textColor: Colors.white,
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
      msg: 'EXTERNAL_WALLET:' + response.walletName!,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 8,
      backgroundColor: AppColor.neturalOrange,
      textColor: Colors.white,
    );
  }
}
