import 'package:get/get.dart';

import 'package:homeqart/app/modules/brands/controllers/brandswise_products_controller_controller.dart';

import '../controllers/brands_controller.dart';

class BrandsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<BrandswiseProductsControllerController>(
      () => BrandswiseProductsControllerController(),
    );
    Get.lazyPut<BrandsController>(
      () => BrandsController(),
    );
  }
}
