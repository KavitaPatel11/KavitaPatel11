import 'package:get/get.dart';
import 'package:homeqart/app/modules/brands/services.dart';
import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class BrandsController extends GetxController {
  var isLoading = true.obs;
  var brandResponse = BrandResponse().obs;
  int currentPage = 1;
  late int totalPages;

  // final RefreshController refreshController =
  //     RefreshController(initialRefresh: true);

  @override
  void onInit() async {
    brands();
    super.onInit();
  }

  brands() async {
    try {
      isLoading(true);
      print("brand block");
      final apiResponse = await BrandRemoteServices.fetchbrands(currentPage);

      print("brand block exexuted");
      if (apiResponse != null) {
        var result = apiResponse;
        print("brands====$result");
        brandResponse.value = result;
        totalPages = brandResponse.value.totalPages!;
      }
    } finally {
      isLoading(false);
    }
  }

  // Future<bool> brands({bool isRefresh = false, }) async {
  //   print("all product2==");
  //   if (isRefresh) {
  //     currentPage = 1;
  //   } else {
  //     if (currentPage >= totalPages) {
  //       refreshController.loadNoData();
  //       return false;
  //     }
  //   }

  //   //  final apiResponse = await baseClient.get(false, "$baseUrl",
  //   //     "/api/v1/${getArgumentData[1]['path']}?offset=$currentPage");
  //   final apiResponse = await BrandRemoteServices.fetchbrands(currentPage);
  //   if (apiResponse != null) {

  //     print("fetchcatProduct3==$apiResponse");
  //     var result = apiResponse;
  //     if (isRefresh) {
  //     brandResponse.value=result;
  //      print("fetchcatProduct3==$result");
  //     } else {
  //       brandResponse.value=result;
  //     }

  //     print(brandResponse);
  //     currentPage++;
  //     totalPages = 50;
  //     print(
  //         "brandResponse.products!.length==${brandResponse.value.brands!.length}");
  //     // print((brandResponse.length / 15).toInt());
  //     // print(" brandresponse====== $brandResponse");
  //     isLoading(false);

  //     return true;
  //   } else {
  //     print("all null product6==$apiResponse");
  //     return false;
  //   }
  // }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
