import 'package:get/get.dart';
import 'package:homeqart/app/modules/brands/services.dart';

import '../../../../services/base_client.dart';
import '../../../constent.dart';
import '../../common_model/product_by_brand_response.dart';

class BrandswiseProductsControllerController extends GetxController {
  var isLoading = true.obs;
  var productByBrandResponse = ProductByBrandResponse().obs;
  int currentPage = 1;
  late int totalPages;
  var argu = Get.arguments;
  BaseClient baseClient = BaseClient();

  // final RefreshController refreshController =
  //     RefreshController(initialRefresh: true);

  @override
  void onInit() async {
    products();
    super.onInit();
  }

  products() async {
    try {
      isLoading(true);
      print("brands all products block");
      final apiResponse = await BrandRemoteServices.fetchbrandsproducts(
          argu[0]['id'], currentPage);

      print("brands all products exexuted");
      if (apiResponse != null) {
        var result = apiResponse;
        print("brands all products====$result");
        productByBrandResponse.value = result;
        print("productByBrandResponse-------------$productByBrandResponse");
        totalPages = productByBrandResponse.value.totalPages!;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() {}
}
