import 'package:homeqart/app/constent.dart';

import 'package:homeqart/app/modules/home/model/brands_response.dart';
import 'package:http/http.dart' as http;

import '../common_model/product_by_brand_response.dart';

class BrandRemoteServices {
  static var client = http.Client();

  static Future<BrandResponse?> fetchbrands(int currentPage) async {
    print("============ all brands api calling=======");

    var response = await client.get(
      Uri.parse('$baseUrl/api/v1/brands?limit=16&offset=$currentPage'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print("br api successs");
      var jsonString = response.body;
      print("all brands======= $jsonString");
      print(jsonString);
      print("success");
      return brandResponseFromJson(jsonString);
    } else {
      print("all brands api Unsuccesssfull..");
      return null;
    }
  }

  static Future<ProductByBrandResponse?> fetchbrandsproducts(
    brand_id,
    currentPage,
  ) async {
    print("============ productByBrandResponse all brands api calling=======");

    var response = await client.get(
      Uri.parse(
          '$baseUrl/api/v1/brands/$brand_id?limit=16&offset=$currentPage'),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${box2.read("logintoken")}'
      },
    );

    if (response.statusCode == 200) {
      print(" productByBrandResponse api successs");
      var jsonString = response.body;
      print(" productByBrandResponse all brands======= $jsonString");
      print(jsonString);
      print("success");
      return productByBrandResponseFromJson(jsonString);
    } else {
      print(" productByBrandResponse all brands api Unsuccesssfull..");
      return null;
    }
  }
}
