import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/brands/controllers/brands_controller.dart';
import 'package:homeqart/app/modules/brands/views/brands_view.dart';
import 'package:homeqart/app/theme.dart';

import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/brand_card.dart';
import 'package:homeqart/components/product_card.dart';

import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../showAllProducts/views/categorise_wise/show_all_product_by_brand.dart';

class AllBrandsView extends StatefulWidget {
  const AllBrandsView({
    Key? key,
  }) : super(key: key);

  @override
  _AllBrandsViewState createState() => _AllBrandsViewState();
}

class _AllBrandsViewState extends State<AllBrandsView> {
  final BrandsController brandsController = Get.put(BrandsController());
  final getargument = Get.arguments;
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (brandsController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return Scaffold(
              floatingActionButton: brandsController.isLoading.value
                  ? SizedBox()
                  : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      if (brandsController.currentPage > 1)
                        ClipOval(
                          child: Material(
                            color: Colors.black12, // Button color
                            child: InkWell(
                              splashColor: Colors.red, // Splash color
                              onTap: () {
                                brandsController.currentPage--;
                                brandsController.brands();
                              },
                              child: SizedBox(
                                width: 56,
                                height: 56,
                                child: Icon(
                                  Icons.navigate_before_rounded,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ),
                        ),
                      if (brandsController.currentPage <
                          brandsController.totalPages.toInt())
                        ClipOval(
                          child: Material(
                            color: Colors.black12, // Button color
                            child: InkWell(
                              splashColor: Colors.red, // Splash color
                              onTap: () {
                                brandsController.currentPage++;
                                brandsController.brands();
                              },
                              child: SizedBox(
                                width: 56,
                                height: 56,
                                child: Icon(
                                  Icons.navigate_next_rounded,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ),
                        )
                    ]),
              appBar: CustomAppBar("All Brands"),
              body: Container(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
                  child: GridView.builder(
                    // controller: scrollController,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 150,
                      mainAxisExtent: 120,
                      childAspectRatio: 2 / 2,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount:
                        brandsController.brandResponse.value.brands!.length,
                    itemBuilder: (BuildContext ctx, index) {
                      return BrandCard(
                        onTap: () {
                          Get.to(ShowAllBrandsProductScreen(), arguments: [
                            {
                              'id': brandsController
                                  .brandResponse.value.brands![index].id!
                            },
                            {
                              'name': brandsController
                                  .brandResponse.value.brands![index].name
                            },
                            {
                              'banner': brandsController
                                  .brandResponse.value.brands![index].banner
                            }
                          ]);
                        },
                        image:
                            "$baseUrl/storage/app/public/brand/${brandsController.brandResponse.value.brands![index].image!}",
                        height: 30.0,
                        width: 30.0,
                      );
                    },
                  ),
                ),
              ));
        }
      }),
    );
  }
}
