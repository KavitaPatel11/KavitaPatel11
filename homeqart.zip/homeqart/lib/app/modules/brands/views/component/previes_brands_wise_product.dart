import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/product_by_brand_response.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/brand_by_product_card.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class BrandsView extends StatefulWidget {
  @override
  _BrandsViewState createState() => _BrandsViewState();
}

class _BrandsViewState extends State<BrandsView> {
  bool isLoading = true;
  BaseClient baseClient = BaseClient();
  var productByBrandResponse = ProductByBrandResponse();
  var argu = Get.arguments;
  int currentPage = 1;
  var totalPages;
  final RefreshController refreshController =
      RefreshController(initialRefresh: true);

  // getData() async {
  //   final apiResponse = await baseClient.get(false, "$baseUrl",
  //       "/api/v1/brands/${argu[0]['id']}");

  //   productByBrandResponse = productByBrandResponseFromJson(apiResponse);
  //    print(productByBrandResponse);
  //   isLoading = false;
  //   setState(() {});
  // }

  Future<bool> getBrandData({bool isRefresh = false}) async {
    if (isRefresh) {
      currentPage = 1;
    } else {
      if (currentPage == totalPages) {
        refreshController.loadNoData();
        return false;
      }
    }
    final apiResponse = await baseClient.get(false, "$baseUrl",
        "/api/v1/brands/${argu[0]['id']}?limit=16&offset=$currentPage");
    if (apiResponse != null) {
      var result = productByBrandResponseFromJson(apiResponse);
      if (isRefresh) {
        productByBrandResponse = result;
      } else {
        productByBrandResponse = result;
      }

      print(productByBrandResponse);
      currentPage++;
      totalPages = (productByBrandResponse.totalPages! + 1).toInt();
      print(
          "productByBrandResponse.products!.length==${(productByBrandResponse.totalPages!)}");
      // print((brandResponse.length / 15).toInt());
      // print(" brandresponse====== $brandResponse");
      isLoading = false;
      setState(() {});
      return true;
    } else {
      return false;
    }
  }

  @override
  void initState() {
    getBrandData();

    super.initState();
  }

  @override
  void dispose() {
    refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomAppBar(argu[1]['name']),
        body: SmartRefresher(
          controller: refreshController,
          enablePullUp: true,
          onRefresh: () async {
            final result = await getBrandData(isRefresh: true);
            if (result) {
              refreshController.refreshCompleted();
            } else {
              refreshController.refreshFailed();
            }
          },
          onLoading: () async {
            final result = await getBrandData();
            if (result) {
              refreshController.loadComplete();
            } else {
              refreshController.loadNoData();
            }
          },
          child: isLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : productByBrandResponse.products!.isEmpty
                  ? Center(
                      child: Text("nothing to show"),
                    )
                  : SingleChildScrollView(
                      child: SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 10, right: 10, top: 10),
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 200,
                              mainAxisExtent: 220,
                              childAspectRatio: 2 / 2,
                              crossAxisSpacing: 8,
                              mainAxisSpacing: 8,
                            ),
                            itemCount:
                                productByBrandResponse.products!.length == null
                                    ? 0
                                    : productByBrandResponse.products!.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return BrandProductCard(
                                id: productByBrandResponse
                                            .products![index].id ==
                                        null
                                    ? 0
                                    : productByBrandResponse
                                        .products![index].id!,
                                image:
                                    '$baseUrl/storage/app/public/product/${productByBrandResponse.products![index].image![0]}',
                                mrp:
                                    '${productByBrandResponse.products![index].price == null ? 0 : productByBrandResponse.products![index].price!}',
                                offAmount: productByBrandResponse
                                            .products![index].offAmount ==
                                        null
                                    ? 0
                                    : productByBrandResponse
                                        .products![index].offAmount!,
                                unit:
                                    '${productByBrandResponse.products![index].unit == null ? '' : productByBrandResponse.products![index].unit!}',
                                name:
                                    '${productByBrandResponse.products![index].name == null ? 0 : productByBrandResponse.products![index].name!}',
                                sellingPrice: productByBrandResponse
                                            .products![index].sellingPrice ==
                                        null
                                    ? 0
                                    : productByBrandResponse
                                        .products![index].sellingPrice!,
                              );
                              ;
                            },
                          ),
                        ),
                      ),
                    ),
        ));
  }
}
