import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/common_model/product_by_brand_response.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:homeqart/components/brand_by_product_card.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../../components/product_card.dart';
import '../controllers/brands_controller.dart';
import '../controllers/brandswise_products_controller_controller.dart';

class BrandsView extends StatefulWidget {
  @override
  _BrandsViewState createState() => _BrandsViewState();
}

class _BrandsViewState extends State<BrandsView> {
  final BrandswiseProductsControllerController
      brandswiseProductsControllerController =
      Get.put(BrandswiseProductsControllerController());
  final getargument = Get.arguments;
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (brandswiseProductsControllerController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return Scaffold(
              // floatingActionButton:showAllProductsController
              //         .isLoading.value
              //     ? SizedBox()
              //     : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage >
              //             1)
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                  showAllProductsController
              //                       .currentPage--;
              //                  showAllProductsController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_before_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           ),
              //         if (showAllProductScreen3ControllerController
              //                 .currentPage <
              //            showAllProductsController.totalPages
              //                 .toInt())
              //           ClipOval(
              //             child: Material(
              //               color: Colors.black12, // Button color
              //               child: InkWell(
              //                 splashColor: Colors.red, // Splash color
              //                 onTap: () {
              //                  showAllProductsController
              //                       .currentPage++;
              //                  showAllProductsController
              //                       .products();
              //                 },
              //                 child: SizedBox(
              //                   width: 56,
              //                   height: 56,
              //                   child: Icon(
              //                     Icons.navigate_next_rounded,
              //                     color: Colors.blue,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           )
              //       ]),
              appBar: CustomAppBar("${Get.arguments[1]['name']}"),
              body: SingleChildScrollView(
                child: SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 10, right: 10, top: 10),
                        child: GridView.builder(
                          controller: scrollController,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200,
                            mainAxisExtent: 220,
                            childAspectRatio: 2 / 2,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: brandswiseProductsControllerController
                                      .productByBrandResponse
                                      .value
                                      .products!
                                      .length ==
                                  null
                              ? 0
                              : brandswiseProductsControllerController
                                  .productByBrandResponse
                                  .value
                                  .products!
                                  .length,
                          itemBuilder: (BuildContext ctx, index) {
                            return ProductCard(
                              id: brandswiseProductsControllerController
                                  .productByBrandResponse
                                  .value
                                  .products![index]
                                  .id!,
                              image: "$baseUrl/storage/app/public/product/" +
                                  brandswiseProductsControllerController
                                      .productByBrandResponse
                                      .value
                                      .products![index]
                                      .image![0],
                              name: brandswiseProductsControllerController
                                  .productByBrandResponse
                                  .value
                                  .products![index]
                                  .name!,
                              mrp:
                                  "${brandswiseProductsControllerController.productByBrandResponse.value.products![index].price!}",
                              offAmount: brandswiseProductsControllerController
                                  .productByBrandResponse
                                  .value
                                  .products![index]
                                  .offAmount!
                                  .toString(),
                              sellingPrice:
                                  brandswiseProductsControllerController
                                      .productByBrandResponse
                                      .value
                                      .products![index]
                                      .sellingPrice!
                                      .toString(),
                              unit:
                                  '${brandswiseProductsControllerController.productByBrandResponse.value.products![index].unit!}',
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsets.only(left: 10, right: 10, bottom: 10),
                        child: Container(
                          child: brandswiseProductsControllerController
                                  .isLoading.value
                              ? SizedBox()
                              : Card(
                                  child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        if (brandswiseProductsControllerController
                                                .currentPage >
                                            1)
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  brandswiseProductsControllerController
                                                      .currentPage--;
                                                  brandswiseProductsControllerController
                                                      .products();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons
                                                        .navigate_before_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        if (brandswiseProductsControllerController
                                                .currentPage <
                                            brandswiseProductsControllerController
                                                .totalPages
                                                .toInt())
                                          ClipOval(
                                            child: Material(
                                              color: Colors
                                                  .black12, // Button color
                                              child: InkWell(
                                                splashColor:
                                                    Colors.red, // Splash color
                                                onTap: () {
                                                  brandswiseProductsControllerController
                                                      .currentPage++;
                                                  brandswiseProductsControllerController
                                                      .products();
                                                },
                                                child: SizedBox(
                                                  width: 56,
                                                  height: 56,
                                                  child: Icon(
                                                    Icons.navigate_next_rounded,
                                                    color: Colors.blue,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                      ]),
                                ),
                        ),
                      )
                    ],
                  ),
                ),
              ));
        }
      }),
    );
  }
}
