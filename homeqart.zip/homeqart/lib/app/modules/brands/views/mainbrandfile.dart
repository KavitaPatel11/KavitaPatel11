import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:homeqart/app/modules/brands/views/all_brands_screen.dart';

class MainBranddScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
      body:ListView(children: [
        Container(
          height: 2000,
          child: AllBrandsView() 
        )
      ]),
    );
  }
}
