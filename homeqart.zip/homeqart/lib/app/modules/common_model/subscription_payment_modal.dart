// To parse this JSON data, do
//
//     final subscriptionPaymentModal = subscriptionPaymentModalFromJson(jsonString);

import 'dart:convert';

SubscriptionPaymentModal subscriptionPaymentModalFromJson(String str) =>
    SubscriptionPaymentModal.fromJson(json.decode(str));

String subscriptionPaymentModalToJson(SubscriptionPaymentModal data) =>
    json.encode(data.toJson());

class SubscriptionPaymentModal {
  SubscriptionPaymentModal({
    this.msg,
  });

  bool? msg;

  factory SubscriptionPaymentModal.fromJson(Map<String, dynamic> json) =>
      SubscriptionPaymentModal(
        msg: json["msg"] == null ? null : json["msg"],
      );

  Map<String, dynamic> toJson() => {
        "msg": msg == null ? null : msg,
      };
}
