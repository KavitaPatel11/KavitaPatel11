// To parse this JSON data, do
//
//     final subscriptionDataModal = subscriptionDataModalFromJson(jsonString);

import 'dart:convert';

SubscriptionDataModal subscriptionDataModalFromJson(String str) =>
    SubscriptionDataModal.fromJson(json.decode(str));

String subscriptionDataModalToJson(SubscriptionDataModal data) =>
    json.encode(data.toJson());

class SubscriptionDataModal {
  SubscriptionDataModal({
    this.subscription,
    this.sPlans,
  });

  List<Subscription>? subscription;
  List<SPlan>? sPlans;

  factory SubscriptionDataModal.fromJson(Map<String, dynamic> json) =>
      SubscriptionDataModal(
        subscription: json["subscription"] == null
            ? null
            : List<Subscription>.from(
                json["subscription"].map((x) => Subscription.fromJson(x))),
        sPlans: json["s_plans"] == null
            ? null
            : List<SPlan>.from(json["s_plans"].map((x) => SPlan.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "subscription": subscription == null
            ? null
            : List<dynamic>.from(subscription!.map((x) => x.toJson())),
        "s_plans": sPlans == null
            ? null
            : List<dynamic>.from(sPlans!.map((x) => x.toJson())),
      };
}

class SPlan {
  SPlan({
    this.id,
    this.name,
    this.userId,
    this.amount,
    this.paymentId,
    this.razorpayId,
    this.paymentDone,
    this.subscriptionId,
    this.subscriptionName,
    this.startDate,
    this.endDate,
    this.status,
  });

  int? id;
  String? name;
  int? userId;
  int? amount;
  String? paymentId;
  String? razorpayId;
  int? paymentDone;
  int? subscriptionId;
  String? subscriptionName;
  DateTime? startDate;
  DateTime? endDate;
  int? status;

  factory SPlan.fromJson(Map<String, dynamic> json) => SPlan(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        userId: json["user_id"] == null ? null : json["user_id"],
        amount: json["amount"] == null ? null : json["amount"],
        paymentId: json["payment_id"] == null ? null : json["payment_id"],
        razorpayId: json["razorpay_id"] == null ? null : json["razorpay_id"],
        paymentDone: json["payment_done"] == null ? null : json["payment_done"],
        subscriptionId:
            json["subscription_id"] == null ? null : json["subscription_id"],
        subscriptionName: json["subscription_name"] == null
            ? null
            : json["subscription_name"],
        startDate: json["start_date"] == null
            ? null
            : DateTime.parse(json["start_date"]),
        endDate:
            json["end_date"] == null ? null : DateTime.parse(json["end_date"]),
        status: json["status"] == null ? null : json["status"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "user_id": userId == null ? null : userId,
        "amount": amount == null ? null : amount,
        "payment_id": paymentId == null ? null : paymentId,
        "razorpay_id": razorpayId == null ? null : razorpayId,
        "payment_done": paymentDone == null ? null : paymentDone,
        "subscription_id": subscriptionId == null ? null : subscriptionId,
        "subscription_name": subscriptionName == null ? null : subscriptionName,
        "start_date": startDate == null
            ? null
            : "${startDate!.year.toString().padLeft(4, '0')}-${startDate!.month.toString().padLeft(2, '0')}-${startDate!.day.toString().padLeft(2, '0')}",
        "end_date": endDate == null
            ? null
            : "${endDate!.year.toString().padLeft(4, '0')}-${endDate!.month.toString().padLeft(2, '0')}-${endDate!.day.toString().padLeft(2, '0')}",
        "status": status == null ? null : status,
      };
}

class Subscription {
  Subscription({
    this.id,
    this.title,
    this.price,
    this.sPrice,
    this.duration,
    this.description,
    this.subscribe,
  });

  int? id;
  String? title;
  int? price;
  int? sPrice;
  int? duration;
  String? description;
  int? subscribe;

  factory Subscription.fromJson(Map<String, dynamic> json) => Subscription(
        id: json["id"] == null ? null : json["id"],
        title: json["title"] == null ? null : json["title"],
        price: json["price"] == null ? null : json["price"],
        sPrice: json["s_price"] == null ? null : json["s_price"],
        duration: json["duration"] == null ? null : json["duration"],
        description: json["description"] == null ? null : json["description"],
        subscribe: json["subscribe"] == null ? null : json["subscribe"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "title": title == null ? null : title,
        "price": price == null ? null : price,
        "s_price": sPrice == null ? null : sPrice,
        "duration": duration == null ? null : duration,
        "description": description == null ? null : description,
        "subscribe": subscribe == null ? null : subscribe,
      };
}
