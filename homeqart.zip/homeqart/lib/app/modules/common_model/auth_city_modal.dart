// To parse this JSON data, do
//
//     final availableCityModal = availableCityModalFromJson(jsonString);

import 'dart:convert';

AvailableCityModal availableCityModalFromJson(String str) =>
    AvailableCityModal.fromJson(json.decode(str));

String availableCityModalToJson(AvailableCityModal data) =>
    json.encode(data.toJson());

class AvailableCityModal {
  AvailableCityModal({
    this.city,
  });

  List<City>? city;

  factory AvailableCityModal.fromJson(Map<String, dynamic> json) =>
      AvailableCityModal(
        city: json["city"] == null
            ? null
            : List<City>.from(json["city"].map((x) => City.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "city": city == null
            ? null
            : List<dynamic>.from(city!.map((x) => x.toJson())),
      };
}

class City {
  City({
    this.id,
    this.name,
  });

  int? id;
  String? name;

  factory City.fromJson(Map<String, dynamic> json) => City(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
      };
}
