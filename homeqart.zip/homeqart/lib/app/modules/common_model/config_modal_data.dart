// To parse this JSON data, do
//
//     final configModalData = configModalDataFromJson(jsonString);

import 'dart:convert';

ConfigModalData configModalDataFromJson(String str) =>
    ConfigModalData.fromJson(json.decode(str));

String configModalDataToJson(ConfigModalData data) =>
    json.encode(data.toJson());

class ConfigModalData {
  ConfigModalData({
    this.ecommerceName,
    this.ecommerceLogo,
    this.ecommerceAddress,
    this.ecommercePhone,
    this.ecommerceEmail,
    this.ecommerceLocationCoverage,
    this.minimumOrderValue,
    this.selfPickup,
    this.baseUrls,
    this.currencySymbol,
    this.deliveryCharge,
    this.cashOnDelivery,
    this.digitalPayment,
    this.branches,
    this.termsAndConditions,
    this.privacyPolicy,
    this.aboutUs,
  });

  String? ecommerceName;
  String? ecommerceLogo;
  String? ecommerceAddress;
  String? ecommercePhone;
  String? ecommerceEmail;
  EcommerceLocationCoverage? ecommerceLocationCoverage;
  int? minimumOrderValue;
  int? selfPickup;
  BaseUrls? baseUrls;
  String? currencySymbol;
  String? deliveryCharge;
  String? cashOnDelivery;
  String? digitalPayment;
  List<Branch>? branches;
  String? termsAndConditions;
  String? privacyPolicy;
  String? aboutUs;

  factory ConfigModalData.fromJson(Map<String, dynamic> json) =>
      ConfigModalData(
        ecommerceName:
            json["ecommerce_name"] == null ? null : json["ecommerce_name"],
        ecommerceLogo:
            json["ecommerce_logo"] == null ? null : json["ecommerce_logo"],
        ecommerceAddress: json["ecommerce_address"] == null
            ? null
            : json["ecommerce_address"],
        ecommercePhone:
            json["ecommerce_phone"] == null ? null : json["ecommerce_phone"],
        ecommerceEmail:
            json["ecommerce_email"] == null ? null : json["ecommerce_email"],
        ecommerceLocationCoverage: json["ecommerce_location_coverage"] == null
            ? null
            : EcommerceLocationCoverage.fromJson(
                json["ecommerce_location_coverage"]),
        minimumOrderValue: json["minimum_order_value"] == null
            ? null
            : json["minimum_order_value"],
        selfPickup: json["self_pickup"] == null ? null : json["self_pickup"],
        baseUrls: json["base_urls"] == null
            ? null
            : BaseUrls.fromJson(json["base_urls"]),
        currencySymbol:
            json["currency_symbol"] == null ? null : json["currency_symbol"],
        deliveryCharge:
            json["delivery_charge"] == null ? null : json["delivery_charge"],
        cashOnDelivery:
            json["cash_on_delivery"] == null ? null : json["cash_on_delivery"],
        digitalPayment:
            json["digital_payment"] == null ? null : json["digital_payment"],
        branches: json["branches"] == null
            ? null
            : List<Branch>.from(
                json["branches"].map((x) => Branch.fromJson(x))),
        termsAndConditions: json["terms_and_conditions"] == null
            ? null
            : json["terms_and_conditions"],
        privacyPolicy:
            json["privacy_policy"] == null ? null : json["privacy_policy"],
        aboutUs: json["about_us"] == null ? null : json["about_us"],
      );

  Map<String, dynamic> toJson() => {
        "ecommerce_name": ecommerceName == null ? null : ecommerceName,
        "ecommerce_logo": ecommerceLogo == null ? null : ecommerceLogo,
        "ecommerce_address": ecommerceAddress == null ? null : ecommerceAddress,
        "ecommerce_phone": ecommercePhone == null ? null : ecommercePhone,
        "ecommerce_email": ecommerceEmail == null ? null : ecommerceEmail,
        "ecommerce_location_coverage": ecommerceLocationCoverage == null
            ? null
            : ecommerceLocationCoverage!.toJson(),
        "minimum_order_value":
            minimumOrderValue == null ? null : minimumOrderValue,
        "self_pickup": selfPickup == null ? null : selfPickup,
        "base_urls": baseUrls == null ? null : baseUrls!.toJson(),
        "currency_symbol": currencySymbol == null ? null : currencySymbol,
        "delivery_charge": deliveryCharge == null ? null : deliveryCharge,
        "cash_on_delivery": cashOnDelivery == null ? null : cashOnDelivery,
        "digital_payment": digitalPayment == null ? null : digitalPayment,
        "branches": branches == null
            ? null
            : List<dynamic>.from(branches!.map((x) => x.toJson())),
        "terms_and_conditions":
            termsAndConditions == null ? null : termsAndConditions,
        "privacy_policy": privacyPolicy == null ? null : privacyPolicy,
        "about_us": aboutUs == null ? null : aboutUs,
      };
}

class BaseUrls {
  BaseUrls({
    this.productImageUrl,
    this.customerImageUrl,
    this.bannerImageUrl,
    this.categoryImageUrl,
    this.reviewImageUrl,
    this.notificationImageUrl,
    this.ecommerceImageUrl,
    this.deliveryManImageUrl,
    this.chatImageUrl,
  });

  String? productImageUrl;
  String? customerImageUrl;
  String? bannerImageUrl;
  String? categoryImageUrl;
  String? reviewImageUrl;
  String? notificationImageUrl;
  String? ecommerceImageUrl;
  String? deliveryManImageUrl;
  String? chatImageUrl;

  factory BaseUrls.fromJson(Map<String, dynamic> json) => BaseUrls(
        productImageUrl: json["product_image_url"] == null
            ? null
            : json["product_image_url"],
        customerImageUrl: json["customer_image_url"] == null
            ? null
            : json["customer_image_url"],
        bannerImageUrl:
            json["banner_image_url"] == null ? null : json["banner_image_url"],
        categoryImageUrl: json["category_image_url"] == null
            ? null
            : json["category_image_url"],
        reviewImageUrl:
            json["review_image_url"] == null ? null : json["review_image_url"],
        notificationImageUrl: json["notification_image_url"] == null
            ? null
            : json["notification_image_url"],
        ecommerceImageUrl: json["ecommerce_image_url"] == null
            ? null
            : json["ecommerce_image_url"],
        deliveryManImageUrl: json["delivery_man_image_url"] == null
            ? null
            : json["delivery_man_image_url"],
        chatImageUrl:
            json["chat_image_url"] == null ? null : json["chat_image_url"],
      );

  Map<String, dynamic> toJson() => {
        "product_image_url": productImageUrl == null ? null : productImageUrl,
        "customer_image_url":
            customerImageUrl == null ? null : customerImageUrl,
        "banner_image_url": bannerImageUrl == null ? null : bannerImageUrl,
        "category_image_url":
            categoryImageUrl == null ? null : categoryImageUrl,
        "review_image_url": reviewImageUrl == null ? null : reviewImageUrl,
        "notification_image_url":
            notificationImageUrl == null ? null : notificationImageUrl,
        "ecommerce_image_url":
            ecommerceImageUrl == null ? null : ecommerceImageUrl,
        "delivery_man_image_url":
            deliveryManImageUrl == null ? null : deliveryManImageUrl,
        "chat_image_url": chatImageUrl == null ? null : chatImageUrl,
      };
}

class Branch {
  Branch({
    this.id,
    this.name,
    this.email,
    this.longitude,
    this.latitude,
    this.address,
    this.coverage,
  });

  int? id;
  String? name;
  String? email;
  String? longitude;
  String? latitude;
  String? address;
  int? coverage;

  factory Branch.fromJson(Map<String, dynamic> json) => Branch(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        email: json["email"] == null ? null : json["email"],
        longitude: json["longitude"] == null ? null : json["longitude"],
        latitude: json["latitude"] == null ? null : json["latitude"],
        address: json["address"] == null ? null : json["address"],
        coverage: json["coverage"] == null ? null : json["coverage"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "email": email == null ? null : email,
        "longitude": longitude == null ? null : longitude,
        "latitude": latitude == null ? null : latitude,
        "address": address == null ? null : address,
        "coverage": coverage == null ? null : coverage,
      };
}

class EcommerceLocationCoverage {
  EcommerceLocationCoverage({
    this.longitude,
    this.latitude,
    this.coverage,
  });

  String? longitude;
  String? latitude;
  int? coverage;

  factory EcommerceLocationCoverage.fromJson(Map<String, dynamic> json) =>
      EcommerceLocationCoverage(
        longitude: json["longitude"] == null ? null : json["longitude"],
        latitude: json["latitude"] == null ? null : json["latitude"],
        coverage: json["coverage"] == null ? null : json["coverage"],
      );

  Map<String, dynamic> toJson() => {
        "longitude": longitude == null ? null : longitude,
        "latitude": latitude == null ? null : latitude,
        "coverage": coverage == null ? null : coverage,
      };
}
