// To parse this JSON data, do
//
//     final getNotificationResponse = getNotificationResponseFromJson(jsonString);

import 'dart:convert';

List<GetNotificationResponse> getNotificationResponseFromJson(String str) => List<GetNotificationResponse>.from(json.decode(str).map((x) => GetNotificationResponse.fromJson(x)));

String getNotificationResponseToJson(List<GetNotificationResponse> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class GetNotificationResponse {
    GetNotificationResponse({
        this.id,
        this.title,
        this.description,
        this.image,
        this.status,
       
        this.time,
    });

    int? id;
    String? title;
    String? description;
    String? image;
    int? status;   
    String? time;

    factory GetNotificationResponse.fromJson(Map<String, dynamic> json) => GetNotificationResponse(
        id: json["id"] == null ? null : json["id"],
        title: json["title"] == null ? null : json["title"],
        description: json["description"] == null ? null : json["description"],
        image: json["image"] == null ? null : json["image"],
        status: json["status"] == null ? null : json["status"],
       
        time: json["time"] == null ? null : json["time"],
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "title": title == null ? null : title,
        "description": description == null ? null : description,
        "image": image == null ? null : image,
        "status": status == null ? null : status,
       
        "time": time == null ? null : time,
    };
}
