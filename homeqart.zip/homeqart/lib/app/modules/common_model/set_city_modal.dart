// To parse this JSON data, do
//
//     final setCityModal = setCityModalFromJson(jsonString);

import 'dart:convert';

SetCityModal setCityModalFromJson(String str) =>
    SetCityModal.fromJson(json.decode(str));

String setCityModalToJson(SetCityModal data) => json.encode(data.toJson());

class SetCityModal {
  SetCityModal({
    this.msg,
  });

  String? msg;

  factory SetCityModal.fromJson(Map<String, dynamic> json) => SetCityModal(
        msg: json["msg"] == null ? null : json["msg"],
      );

  Map<String, dynamic> toJson() => {
        "msg": msg == null ? null : msg,
      };
}
