// To parse this JSON data, do
//
//     final allCategoriesData = allCategoriesDataFromJson(jsonString);

import 'dart:convert';

List<AllCategoriesData> allCategoriesDataFromJson(String str) => List<AllCategoriesData>.from(json.decode(str).map((x) => AllCategoriesData.fromJson(x)));

String allCategoriesDataToJson(List<AllCategoriesData> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class AllCategoriesData {
    AllCategoriesData({
        this.id,
        this.name,
        this.banner,
        this.mobileImage,
        this.childCategories,
    });

    int? id;
    String? name;
    String? banner;
    String? mobileImage;
    List<AllCategoriesData>? childCategories;

    factory AllCategoriesData.fromJson(Map<String, dynamic> json) => AllCategoriesData(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        banner: json["banner"] == null ? null : json["banner"],
        mobileImage: json["mobile_image"] == null ? null : json["mobile_image"],
        childCategories: json["child_categories"] == null ? null : List<AllCategoriesData>.from(json["child_categories"].map((x) => AllCategoriesData.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "banner": banner == null ? null : banner,
        "mobile_image": mobileImage == null ? null : mobileImage,
        "child_categories": childCategories == null ? null : List<dynamic>.from(childCategories!.map((x) => x.toJson())),
    };
}
