import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../text_theme.dart';

class SteperView extends StatefulWidget {
  final String accountStatusText;

  const SteperView({Key? key, required this.accountStatusText})
      : super(key: key);

  @override
  State<SteperView> createState() => _SteperViewState();
}

class _SteperViewState extends State<SteperView> {
  Widget line3() {
    return Container(
      color: Colors.red,
      height: 2,
      width: 170.0,
    );
  }

  // Widget spacer() {
  Widget line2() {
    return Container(
      color: Colors.green,
      height: 3,
      width: 70,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3,
      width: 70,
    );
  }

  Widget icondata2(bool) {
    return Container(
        height: 15,
        width: 15,
        decoration: BoxDecoration(
            color: (bool == true ? Colors.green : Colors.grey),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: (bool == true ? Colors.green : Colors.grey), width: 1)),
        child: bool == true
            ? Icon(
                Icons.check,
                size: 20,
                color: Colors.white,
              )
            : Icon(
                Icons.circle_outlined,
                size: 20,
                color: Colors.transparent,
              ));
  }

  Widget icondata(bool) {
    return Container(
        height: 30,
        width: 30,
        decoration: BoxDecoration(
            color: (bool == true ? Colors.green : Colors.grey),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: (bool == true ? Colors.green : Colors.grey), width: 1)),
        child: bool == true
            ? Center(
                child: Icon(
                  Icons.check,
                  size: 20,
                  color: Colors.white,
                ),
              )
            : Center(
                child: Icon(
                  Icons.circle_outlined,
                  size: 20,
                  color: Colors.transparent,
                ),
              ));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          // color: Colors.amber,
          height: 60,
          width: double.infinity,
          child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: widget.accountStatusText == "pending"
                  ? pending()
                  : widget.accountStatusText == "processing"
                      ? processing()
                      : widget.accountStatusText == "out_for_delivery"
                          ? out_for_delivery()
                          : widget.accountStatusText == "delivered"
                              ? delivered()
                              : widget.accountStatusText == "canceled"
                                  ? cancelled()
                                  : nostatus()),
        ),
        Container(
          // color: Colors.amber,
          height: 30,
          width: double.infinity,
          child: widget.accountStatusText == "canceled"
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Ordered",
                      style: TextStyle(fontSize: 12),
                    ),
                    SizedBox(),
                    Text(
                      "Cancelled",
                      style: TextStyle(fontSize: 12),
                    ),
                    SizedBox(
                      width: 7,
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 2,
                    ),
                    Text(
                      "Ordered",
                      style: TextStyle(fontSize: 12),
                    ),
                    SizedBox(
                      width: 1,
                    ),
                    Text(
                      "Processing",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "Out for delivery",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "delivered",
                      style: TextStyle(fontSize: 12),
                    ),
                    SizedBox(
                      width: 7,
                    ),
                  ],
                ),
        ),
      ],
    );
  }

  Row pending() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(true),
        line2(),
        icondata(false),
        line(),
        icondata(false),
        line(),
        icondata(false),
      ],
    );
  }

  Row processing() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(true),
        line2(),
        icondata(true),
        line2(),
        icondata(false),
        line(),
        icondata(false),
      ],
    );
  }

  Row out_for_delivery() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(true),
        line2(),
        icondata(true),
        line2(),
        icondata(true),
        line2(),
        icondata(false),
      ],
    );
  }

  Row delivered() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(true),
        line2(),
        icondata(true),
        line2(),
        icondata(true),
        line2(),
        icondata(true),
      ],
    );
  }

  Row nostatus() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(false),
        line(),
        icondata(false),
        line(),
        icondata(false),
        line(),
        icondata(false),
      ],
    );
  }

  Row cancelled() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        icondata(true),
        line3(),
        Container(
          height: 30,
          width: 30,
          decoration: BoxDecoration(
              color: (bool == true ? Colors.red : Colors.red),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: (bool == true ? Colors.green : Colors.grey),
                  width: 1)),
          child: Center(
            child: Icon(
              Icons.close,
              size: 20,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
