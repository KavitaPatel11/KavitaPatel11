import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/modules/myorders_detail/modal/my_order_detail.dart';
import 'package:homeqart/app/modules/myorders_detail/views/order_status_bar.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';

import '../../../../services/base_client.dart';
import '../../../constent.dart';
import '../../../text_theme.dart';
import '../../common_model/order_model.dart';
import '../../productdetail/views/productdetail_view.dart';
import '../controllers/myorders_detail_controller.dart';

class MyordersDetailView extends StatefulWidget {
  const MyordersDetailView({Key? key}) : super(key: key);

  @override
  _MyordersDetailViewState createState() => _MyordersDetailViewState();
}

class _MyordersDetailViewState extends State<MyordersDetailView> {
  ScrollController mainScrollController = ScrollController();
  final MyordersDetailController myordersDetailController =
      Get.put(MyordersDetailController());
  var argu = Get.arguments[0]['id'];
  var argu2 = Get.arguments[1]['status'];

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration.zero, () {
      myordersDetailController.ordedetail();
    });
    return Scaffold(
        backgroundColor: AppColor.accentBgColor,
        appBar: CustomAppBar("Order Details "),
        body: Obx(() {
          if (myordersDetailController.isLoading.value) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else {
            return SafeArea(
              child: CustomScrollView(
                controller: mainScrollController,
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                slivers: [
                  SliverList(
                      delegate: SliverChildListDelegate(
                    [SteperView(accountStatusText: Get.arguments[1]['status'])],
                  )),
                  SliverList(
                    delegate: SliverChildListDelegate(
                      [
                        myordersDetailController
                                .myorderdetail.value.products!.isEmpty
                            ? SizedBox(
                                height: 50,
                                child: Center(
                                  child: Text("This product deleted..,"),
                                ),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: myordersDetailController
                                            .myorderdetail
                                            .value
                                            .products!
                                            .length ==
                                        null
                                    ? 0
                                    : myordersDetailController
                                        .myorderdetail.value.products!.length,
                                itemBuilder: (context, index) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                    ),
                                    child: InkWell(
                                      onTap: () {
                                        Get.to(ProductdetailView(),
                                            arguments: myordersDetailController
                                                .myorderdetail
                                                .value
                                                .products![index]
                                                .id);
                                      },
                                      child: Container(
                                        margin: const EdgeInsets.only(top: 10),
                                        decoration: BoxDecoration(
                                          border:
                                              Border.all(color: Colors.black12),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: AppColor.accentWhite,
                                        ),
                                        child: Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 7, bottom: 9, left: 10),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                child: Image.network(
                                                  "$baseUrl/storage/app/public/product/${myordersDetailController.myorderdetail.value.products![index]['image'] == null ? "" : myordersDetailController.myorderdetail.value.products![index]['image']}",
                                                  height: 70,
                                                  width: 70,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 14,
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      165,
                                                  child: Text(
                                                    "${myordersDetailController.myorderdetail.value.products![index]['name'] == null ? "" : myordersDetailController.myorderdetail.value.products![index]['name']}",
                                                    maxLines: 2,
                                                    style: Texttheme.bodyText1
                                                        .copyWith(
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 8,
                                                ),
                                                SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      160,
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                          "₹${myordersDetailController.myorderdetail.value.allProducts!.details![index].price! - myordersDetailController.myorderdetail.value.allProducts!.details![index].discountOnProduct!.toInt() == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.details![index].price! - myordersDetailController.myorderdetail.value.allProducts!.details![index].discountOnProduct!.toInt()}",
                                                          softWrap: true,
                                                          style:
                                                              Texttheme.title),
                                                      Text(
                                                        "${myordersDetailController.myorderdetail.value.allProducts!.details![index].quantity == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.details![index].quantity} Unit ",
                                                        softWrap: true,
                                                        style: Texttheme
                                                            .caption2
                                                            .copyWith(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: AppColor
                                                                    .neturalOrange),
                                                      ),
                                                      Text(
                                                        "${myordersDetailController.myorderdetail.value.products![index]['capacity'] == null ? "" : myordersDetailController.myorderdetail.value.products![index]['capacity']}${myordersDetailController.myorderdetail.value.allProducts!.details![index].unit == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.details![index].unit}",
                                                        softWrap: true,
                                                        style: Texttheme
                                                            .subTitle
                                                            .copyWith(
                                                                color: AppColor
                                                                    .primaryColor),
                                                      ),
                                                      Text(
                                                          "₹${(myordersDetailController.myorderdetail.value.allProducts!.details![index].price! - myordersDetailController.myorderdetail.value.allProducts!.details![index].discountOnProduct!.toInt()) * myordersDetailController.myorderdetail.value.allProducts!.details![index].quantity!.toInt() == null ? "" : (myordersDetailController.myorderdetail.value.allProducts!.details![index].price! - myordersDetailController.myorderdetail.value.allProducts!.details![index].discountOnProduct!.toInt()) * myordersDetailController.myorderdetail.value.allProducts!.details![index].quantity!.toInt()}",
                                                          softWrap: true,
                                                          style:
                                                              Texttheme.title),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ],
                    ),
                  ),
                  SliverList(
                    delegate: SliverChildListDelegate(
                      [
                        Container(
                          margin: const EdgeInsets.only(
                              top: 15, bottom: 8, left: 10, right: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColor.accentWhite),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 15, vertical: 15),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        myordersDetailController
                                                    .myorderdetail
                                                    .value
                                                    .allProducts!
                                                    .totalTaxAmount ==
                                                0
                                            ? SizedBox()
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Tax / GST:",
                                                    style: Texttheme.subTitle,
                                                  ),
                                                  Text(
                                                    "₹${myordersDetailController.myorderdetail.value.allProducts!.totalTaxAmount == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.totalTaxAmount}",
                                                    style: Texttheme.bodyText1,
                                                  ),
                                                ],
                                              ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        myordersDetailController
                                                    .myorderdetail
                                                    .value
                                                    .allProducts!
                                                    .couponDiscountAmount ==
                                                0
                                            ? SizedBox()
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Coupon Discount:",
                                                    style: Texttheme.subTitle,
                                                  ),
                                                  Text(
                                                    "₹${myordersDetailController.myorderdetail.value.allProducts!.couponDiscountAmount == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.couponDiscountAmount}",
                                                    style: Texttheme.bodyText1,
                                                  ),
                                                ],
                                              ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Delivery Fee:",
                                              style: Texttheme.subTitle,
                                            ),
                                            myordersDetailController
                                                        .myorderdetail
                                                        .value
                                                        .allProducts!
                                                        .deliveryCharge ==
                                                    0
                                                ? Text("Free",
                                                    style: Texttheme.caption1
                                                        .copyWith(
                                                            color: AppColor
                                                                .primaryColor))
                                                : Text(
                                                    "₹${myordersDetailController.myorderdetail.value.allProducts!.deliveryCharge == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.deliveryCharge}",
                                                    style: Texttheme.bodyText1,
                                                  ),
                                          ],
                                        ),
                                        Divider(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Total (including all taxes):",
                                              style: Texttheme.subTitle,
                                            ),
                                            Text(
                                              "₹${myordersDetailController.myorderdetail.value.allProducts!.orderAmount == null ? "" : myordersDetailController.myorderdetail.value.allProducts!.orderAmount}",
                                              style: Texttheme.bodyText1,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        }));
  }
}
