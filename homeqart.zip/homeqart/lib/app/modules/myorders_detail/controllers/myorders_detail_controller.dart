import 'package:get/get.dart';
import 'package:homeqart/app/modules/myorders_detail/modal/my_order_detail.dart';
import 'package:homeqart/app/modules/myorders_detail/modal/services.dart';

class MyordersDetailController extends GetxController {
  var isLoading = true.obs;

  var myorderdetail = MyOrderDetailsModel().obs;
  var argu = Get.arguments[0]["id"];

  ordedetail() async {
    try {
      isLoading(true);
      print(" dailyNeeds try block");
      var ordersdetail = await MyOrdersRemoteServices.getOrderDetail(argu);
      print("========= $ordersdetail ======");
      if (ordersdetail != null) {
        print(" dailyNeeds inside controller");
        myorderdetail.value = ordersdetail;
      }
    } finally {
      isLoading(false);
    }
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
