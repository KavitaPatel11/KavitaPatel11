import 'package:get/get.dart';

import '../controllers/myorders_detail_controller.dart';

class MyordersDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MyordersDetailController>(
      () => MyordersDetailController(),
    );
  }
}
