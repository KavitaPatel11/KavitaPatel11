// To parse this JSON data, do
//
//     final myOrderDetailsModel = myOrderDetailsModelFromJson(jsonString);

import 'dart:convert';

MyOrderDetailsModel myOrderDetailsModelFromJson(String str) =>
    MyOrderDetailsModel.fromJson(json.decode(str));

String myOrderDetailsModelToJson(MyOrderDetailsModel data) =>
    json.encode(data.toJson());

class MyOrderDetailsModel {
  MyOrderDetailsModel({
    this.products,
    this.allProducts,
  });

  List<dynamic>? products;
  AllProducts? allProducts;

  factory MyOrderDetailsModel.fromJson(Map<String, dynamic> json) =>
      MyOrderDetailsModel(
        products: json["products"] == null
            ? null
            : List<dynamic>.from(json["products"].map((x) => x)),
        allProducts: json["all_products"] == null
            ? null
            : AllProducts.fromJson(json["all_products"]),
      );

  Map<String, dynamic> toJson() => {
        "products": products == null
            ? null
            : List<dynamic>.from(products!.map((x) => x)),
        "all_products": allProducts == null ? null : allProducts!.toJson(),
      };
}

class AllProducts {
  AllProducts({
    this.id,
    this.userId,
    this.orderAmount,
    this.couponDiscountAmount,
    this.couponDiscountTitle,
    this.paymentStatus,
    this.orderStatus,
    this.totalTaxAmount,
    this.paymentMethod,
    this.transactionReference,
    this.deliveryAddressId,
    this.checked,
    this.deliveryManId,
    this.deliveryCharge,
    this.orderNote,
    this.couponCode,
    this.orderType,
    this.branchId,
    this.timeSlotId,
    this.date,
    this.deliveryDate,
    this.callback,
    this.productId,
    this.quantity,
    this.code,
    this.isPrime,
    this.details,
  });

  int? id;
  int? userId;
  int? orderAmount;
  int? couponDiscountAmount;
  dynamic couponDiscountTitle;
  String? paymentStatus;
  String? orderStatus;
  int? totalTaxAmount;
  String? paymentMethod;
  dynamic transactionReference;
  int? deliveryAddressId;

  int? checked;
  int? deliveryManId;
  int? deliveryCharge;
  String? orderNote;
  dynamic couponCode;
  String? orderType;
  int? branchId;
  int? timeSlotId;
  DateTime? date;
  DateTime? deliveryDate;
  dynamic callback;
  String? productId;
  String? quantity;
  String? code;
  int? isPrime;
  List<Detail>? details;

  factory AllProducts.fromJson(Map<String, dynamic> json) => AllProducts(
        id: json["id"] == null ? null : json["id"],
        userId: json["user_id"] == null ? null : json["user_id"],
        orderAmount: json["order_amount"] == null ? null : json["order_amount"],
        couponDiscountAmount: json["coupon_discount_amount"] == null
            ? null
            : json["coupon_discount_amount"],
        couponDiscountTitle: json["coupon_discount_title"],
        paymentStatus:
            json["payment_status"] == null ? null : json["payment_status"],
        orderStatus: json["order_status"] == null ? null : json["order_status"],
        totalTaxAmount:
            json["total_tax_amount"] == null ? null : json["total_tax_amount"],
        paymentMethod:
            json["payment_method"] == null ? null : json["payment_method"],
        transactionReference: json["transaction_reference"],
        deliveryAddressId: json["delivery_address_id"] == null
            ? null
            : json["delivery_address_id"],
        checked: json["checked"] == null ? null : json["checked"],
        deliveryManId:
            json["delivery_man_id"] == null ? null : json["delivery_man_id"],
        deliveryCharge:
            json["delivery_charge"] == null ? null : json["delivery_charge"],
        orderNote: json["order_note"] == null ? null : json["order_note"],
        couponCode: json["coupon_code"],
        orderType: json["order_type"] == null ? null : json["order_type"],
        branchId: json["branch_id"] == null ? null : json["branch_id"],
        timeSlotId: json["time_slot_id"] == null ? null : json["time_slot_id"],
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        deliveryDate: json["delivery_date"] == null
            ? null
            : DateTime.parse(json["delivery_date"]),
        callback: json["callback"],
        productId: json["product_id"] == null ? null : json["product_id"],
        quantity: json["quantity"] == null ? null : json["quantity"],
        code: json["code"] == null ? null : json["code"],
        isPrime: json["is_prime"] == null ? null : json["is_prime"],
        details: json["details"] == null
            ? null
            : List<Detail>.from(json["details"].map((x) => Detail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "user_id": userId == null ? null : userId,
        "order_amount": orderAmount == null ? null : orderAmount,
        "coupon_discount_amount":
            couponDiscountAmount == null ? null : couponDiscountAmount,
        "coupon_discount_title": couponDiscountTitle,
        "payment_status": paymentStatus == null ? null : paymentStatus,
        "order_status": orderStatus == null ? null : orderStatus,
        "total_tax_amount": totalTaxAmount == null ? null : totalTaxAmount,
        "payment_method": paymentMethod == null ? null : paymentMethod,
        "transaction_reference": transactionReference,
        "delivery_address_id":
            deliveryAddressId == null ? null : deliveryAddressId,
        "checked": checked == null ? null : checked,
        "delivery_man_id": deliveryManId == null ? null : deliveryManId,
        "delivery_charge": deliveryCharge == null ? null : deliveryCharge,
        "order_note": orderNote == null ? null : orderNote,
        "coupon_code": couponCode,
        "order_type": orderType == null ? null : orderType,
        "branch_id": branchId == null ? null : branchId,
        "time_slot_id": timeSlotId == null ? null : timeSlotId,
        "date": date == null ? null : date!.toIso8601String(),
        "delivery_date": deliveryDate == null
            ? null
            : "${deliveryDate!.year.toString().padLeft(4, '0')}-${deliveryDate!.month.toString().padLeft(2, '0')}-${deliveryDate!.day.toString().padLeft(2, '0')}",
        "callback": callback,
        "product_id": productId == null ? null : productId,
        "quantity": quantity == null ? null : quantity,
        "code": code == null ? null : code,
        "is_prime": isPrime == null ? null : isPrime,
        "details": details == null
            ? null
            : List<dynamic>.from(details!.map((x) => x.toJson())),
      };
}

class Detail {
  Detail({
    this.id,
    this.productId,
    this.orderId,
    this.price,
    this.productDetails,
    this.variation,
    this.discountOnProduct,
    this.discountType,
    this.quantity,
    this.taxAmount,
    this.unit,
    this.isStockDecreased,
    this.timeSlotId,
    this.deliveryDate,
  });

  int? id;
  int? productId;
  int? orderId;
  int? price;
  dynamic productDetails;
  dynamic variation;
  int? discountOnProduct;
  DiscountType? discountType;
  int? quantity;
  int? taxAmount;

  String? unit;
  int? isStockDecreased;
  int? timeSlotId;
  DateTime? deliveryDate;

  factory Detail.fromJson(Map<String, dynamic> json) => Detail(
        id: json["id"] == null ? null : json["id"],
        productId: json["product_id"] == null ? null : json["product_id"],
        orderId: json["order_id"] == null ? null : json["order_id"],
        price: json["price"] == null ? null : json["price"],
        productDetails: json["product_details"],
        variation: json["variation"],
        discountOnProduct: json["discount_on_product"] == null
            ? null
            : json["discount_on_product"],
        discountType: json["discount_type"] == null
            ? null
            : discountTypeValues.map[json["discount_type"]],
        quantity: json["quantity"] == null ? null : json["quantity"],
        taxAmount: json["tax_amount"] == null ? null : json["tax_amount"],
        unit: json["unit"] == null ? null : json["unit"],
        isStockDecreased: json["is_stock_decreased"] == null
            ? null
            : json["is_stock_decreased"],
        timeSlotId: json["time_slot_id"] == null ? null : json["time_slot_id"],
        deliveryDate: json["delivery_date"] == null
            ? null
            : DateTime.parse(json["delivery_date"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "product_id": productId == null ? null : productId,
        "order_id": orderId == null ? null : orderId,
        "price": price == null ? null : price,
        "product_details": productDetails,
        "variation": variation,
        "discount_on_product":
            discountOnProduct == null ? null : discountOnProduct,
        "discount_type": discountType == null
            ? null
            : discountTypeValues.reverse[discountType],
        "quantity": quantity == null ? null : quantity,
        "tax_amount": taxAmount == null ? null : taxAmount,
        "unit": unit == null ? null : unitValues.reverse[unit],
        "is_stock_decreased":
            isStockDecreased == null ? null : isStockDecreased,
        "time_slot_id": timeSlotId == null ? null : timeSlotId,
        "delivery_date": deliveryDate == null
            ? null
            : "${deliveryDate!.year.toString().padLeft(4, '0')}-${deliveryDate!.month.toString().padLeft(2, '0')}-${deliveryDate!.day.toString().padLeft(2, '0')}",
      };
}

enum DiscountType { PERCENT, AMOUNT }

final discountTypeValues = EnumValues(
    {"amount": DiscountType.AMOUNT, "percent": DiscountType.PERCENT});

enum Unit { PC, KG, GM }

final unitValues = EnumValues({"gm": Unit.GM, "kg": Unit.KG, "pc": Unit.PC});

class ProductClass {
  ProductClass({
    this.id,
    this.name,
    this.image,
    this.capacity,
  });

  int? id;
  String? name;
  String? image;
  int? capacity;

  factory ProductClass.fromJson(Map<String, dynamic> json) => ProductClass(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        image: json["image"] == null ? null : json["image"],
        capacity: json["capacity"] == null ? null : json["capacity"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "image": image == null ? null : image,
        "capacity": capacity == null ? null : capacity,
      };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
