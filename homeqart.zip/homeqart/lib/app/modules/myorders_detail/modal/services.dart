import 'package:homeqart/app/constent.dart';
import 'package:homeqart/app/modules/myorders_detail/modal/my_order_detail.dart';
import 'package:http/http.dart' as http;

class MyOrdersRemoteServices {
  static var client = http.Client();

  static Future<MyOrderDetailsModel?> getOrderDetail(orderid) async {
    print("============ my order deatail api calling=======");

    var response = await client.get(
      Uri.parse(
          '$baseUrl/api/v1/customer/order/product_details?order_id=$orderid'),
      headers: {'Authorization': 'Bearer ${box2.read("logintoken")}'},
    );

    if (response.statusCode == 200) {
      print("my order deatail api successs");
      var jsonString = response.body;
      print("my order deatail ======= $jsonString");
      print(jsonString);
      return myOrderDetailsModelFromJson(jsonString);
    } else {
      print(" my order deatail  api Unsuccesssfull..");
      return null;
    }
  }
}
