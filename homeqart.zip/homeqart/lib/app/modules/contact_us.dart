import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/contact/controllers/contact_controller.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';

import 'package:whatsapp_unilink/whatsapp_unilink.dart';

import 'package:url_launcher/url_launcher.dart';

class ContactUs extends StatelessWidget {
  ContactUs({Key? key}) : super(key: key);

  final ContactController contactController = Get.put(ContactController());

  AppBar buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: AppColor.primaryColor,
      centerTitle: true,
      title: const Text(
        "Connect With Us",
        // style: TextStyle(fontSize: 16, color: AppColor.accentDarkGrey),
      ),
      elevation: 0.0,
      titleSpacing: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColor.accentBgColor,
        appBar: buildAppBar(context),
        body: Obx(() {
          if (contactController.isLoading.value) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else {
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                  decoration: BoxDecoration(
                      color: AppColor.accentWhite,
                      borderRadius: BorderRadius.circular(15)),
                  child: Column(
                    children: [
                      Image.asset('assets/images/5133405-removebg-preview.png'),
                      const Divider(),
                      ListTile(
                        onTap: () async {
                          final link = WhatsAppUnilink(
                            phoneNumber:
                                '${contactController.configdata.value.ecommercePhone == null ? "" : contactController.configdata.value.ecommercePhone}',
                            text: "Hello,",
                          );

                          await launch('$link');
                        },
                        leading: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Icon(Icons.message_outlined),
                        ),
                        title: Text(
                          'Chat With Custmer Service',
                          style: Texttheme.bodyText1,
                        ),
                        subtitle: Text(
                          'Monday - Sunday : 10:00 AM - 07:00PM',
                          style: Texttheme.bodyText2,
                        ),
                      ),
                      ListTile(
                        onTap: () async {
                          launch(
                              'tel:${contactController.configdata.value.ecommercePhone == null ? "" : contactController.configdata.value.ecommercePhone}');
                        },
                        leading: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Icon(Icons.call_outlined),
                        ),
                        title: Text(
                          'Call Us',
                          style: Texttheme.bodyText1,
                        ),
                        subtitle: Text(
                          'Monday - Sunday : 10:00 AM - 07:00PM',
                          style: Texttheme.bodyText2,
                        ),
                      ),
                      ListTile(
                        onTap: () async {
                          launch(
                            'mailto:${contactController.configdata.value.ecommerceEmail == null ? "" : contactController.configdata.value.ecommerceEmail}?subject=Subject&body= ',
                          );
                        },
                        leading: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Icon(Icons.email_outlined),
                        ),
                        title: Text(
                          'Email Us',
                          style: Texttheme.bodyText1,
                        ),
                        subtitle: Text(
                          '24x7 Available',
                          style: Texttheme.bodyText2,
                        ),
                      ),
                      ListTile(
                        onTap: () async {
                          final link2 = WhatsAppUnilink(
                            phoneNumber:
                                '${contactController.configdata.value.ecommercePhone == null ? "" : contactController.configdata.value.ecommercePhone}',
                            text: "Hello,",
                          );

                          await launch('$link2');
                        },
                        leading: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Icon(Icons.chat_bubble_outline_rounded),
                        ),
                        title: Text(
                          'Live Chat',
                          style: Texttheme.bodyText1,
                        ),
                        subtitle: Text(
                          'Monday - Sunday : 10:00 AM - 07:00PM',
                          style: Texttheme.bodyText2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
        }));
  }
}
