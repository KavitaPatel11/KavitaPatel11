import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/services/base_client.dart';

import '../../../../components/default_button.dart';
import 'package:universal_html/html.dart' as html;

class SubscriptionCard extends StatefulWidget {
  final String subscriptionStatus;
  final int id;
  final String title;
  final String description;

  final int doration;
  final String price;
  final int s_Price;
  final VoidCallback onPress;

  const SubscriptionCard({
    Key? key,
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.doration,
    required this.s_Price,
    required this.onPress,
    required this.subscriptionStatus,
  }) : super(key: key);

  @override
  _SubscriptionCardState createState() => _SubscriptionCardState();
}

class _SubscriptionCardState extends State<SubscriptionCard> {
  String _parseHtmlString(String htmlString) {
    var text = html.Element.p()..appendHtml(htmlString);
    return text.innerText;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      width: double.infinity,
      // height: 100,
      child: Card(
          child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              Text(
                widget.title.toString(),
                style: Texttheme.bodyText1,
              ),
              SizedBox(
                width: 10,
              ),
              // Container(
              //   height: 30,
              //   width: 30,
              //   decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(10),
              //       color: AppColor.accentLightGrey),
              //   child: Center(
              //       child: Text(
              //     "1",
              //     style: TextStyle(color: AppColor.accentWhite),
              //   )),
              // ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "${widget.doration} Months ",
                  style: Texttheme.bodyText2,
                ),
              ],
            ),
          ),
          Divider(
            color: AppColor.accentLightGrey,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                widget.price == null
                    ? SizedBox()
                    : Text(
                        "₹${widget.price}",
                        style: TextStyle(
                          color: Colors.red,
                          // decorationColor: Colors.red,
                          // decorationStyle: TextDecorationStyle.solid,
                          decoration: TextDecoration.lineThrough,
                          fontSize: 20,
                        ),
                      ),
                widget.s_Price == null
                    ? SizedBox()
                    : Text(
                        "${widget.s_Price}",
                        style: Texttheme.bodyText2,
                      ),
              ],
            ),
          ),
          widget.description == null
              ? SizedBox()
              : Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                  child: Html(data: widget.description, style: {
                    "h2": Style(
                      fontSize: FontSize.rem(1),
                      color: AppColor.accentLightGrey,
                      padding: EdgeInsets.all(0),
                    ),
                    "h3": Style(
                      fontSize: FontSize.rem(1),
                      color: AppColor.accentLightGrey,
                      padding: EdgeInsets.all(0),
                    ),
                  })),
          SizedBox(
            height: 10,
          ),
          widget.subscriptionStatus == "1"
              ? DefaultButton(
                  buttonText: "Subscribed",
                  press: () {},
                  buttonColor: AppColor.neturalBrown)
              : DefaultButton(
                  buttonText: "Purchase",
                  press: widget.onPress,
                  buttonColor: AppColor.primaryColor)
        ]),
      )),
      decoration: new BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(.5),
            blurRadius: 20.0, // soften the shadow
            spreadRadius: 0.0, //extend the shadow
            offset: Offset(
              5.0, // Move to right 10  horizontally
              5.0, // Move to bottom 10 Vertically
            ),
          )
        ],
      ),
    );
  }
}
