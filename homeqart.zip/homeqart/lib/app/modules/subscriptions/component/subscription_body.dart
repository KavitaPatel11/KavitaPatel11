import 'package:flutter/material.dart';
import 'package:homeqart/app/modules/subscriptions/component/subscrition_card.dart';
import 'package:homeqart/app/theme.dart';

class SubscriptionBody extends StatelessWidget {
  const SubscriptionBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      // controller: controller,
      child: Column(
        children: [],
      ),
    );
  }
}
