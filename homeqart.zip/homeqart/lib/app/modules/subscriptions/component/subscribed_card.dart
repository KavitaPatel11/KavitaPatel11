import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:homeqart/app/modules/productdetail/views/productdetail_view.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/services/base_client.dart';
import 'package:intl/intl.dart';

import '../../../../components/default_button.dart';
import 'package:universal_html/html.dart' as html;

class SubscripedCard extends StatefulWidget {
  final int id;
  final String title;
  final String amount;

  final String enddate;

  const SubscripedCard({
    Key? key,
    required this.id,
    required this.title,
    required this.amount,
    required this.enddate,
  }) : super(key: key);

  @override
  _SubscripedCardState createState() => _SubscripedCardState();
}

class _SubscripedCardState extends State<SubscripedCard> {
  String formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
  String _parseHtmlString(String htmlString) {
    var text = html.Element.p()..appendHtml(htmlString);
    return text.innerText;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      width: double.infinity,
      // height: 100,
      child: Card(
          child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              Text(
                widget.title.toString(),
                style: Texttheme.bodyText1,
              ),
              SizedBox(
                width: 10,
              ),
              // Container(
              //   height: 30,
              //   width: 30,
              //   decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(10),
              //       color: AppColor.accentLightGrey),
              //   child: Center(
              //       child: Text(
              //     "1",
              //     style: TextStyle(color: AppColor.accentWhite),
              //   )),
              // ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "It will expire on  ",
                  style: Texttheme.bodyText1,
                ),
                SizedBox(
                  width: 10,
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  height: 30,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppColor.accentLightGrey),
                  child: Center(
                      child: Text(
                    widget.enddate,
                    style: TextStyle(color: AppColor.accentWhite),
                  )),
                ),
              ],
            ),
          ),
          Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: Text("Amount : ${widget.amount}")),
          SizedBox(
            height: 10,
          ),
        ]),
      )),
      decoration: new BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(.5),
            blurRadius: 20.0, // soften the shadow
            spreadRadius: 0.0, //extend the shadow
            offset: Offset(
              5.0, // Move to right 10  horizontally
              5.0, // Move to bottom 10 Vertically
            ),
          )
        ],
      ),
    );
  }
}
