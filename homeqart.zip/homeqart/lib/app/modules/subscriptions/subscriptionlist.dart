import 'package:homeqart/app/modules/common_model/subscription_payment_modal.dart';
import 'package:intl/intl.dart';

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:homeqart/app/modules/common_model/subscription_data_modal.dart';
import 'package:homeqart/app/modules/payment_option/views/rozar_pay.dart';

import 'package:homeqart/app/modules/subscriptions/component/subscrition_card.dart';
import 'package:homeqart/app/text_theme.dart';
import 'package:homeqart/app/theme.dart';
import 'package:homeqart/components/appbar_without_actions.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../components/default_button.dart';
import '../../../services/base_client.dart';
import '../../constent.dart';
import 'component/subscribed_card.dart';

class SubscriptionsView extends StatefulWidget {
  const SubscriptionsView({Key? key}) : super(key: key);

  @override
  State<SubscriptionsView> createState() => _SubscriptionsViewState();
}

class _SubscriptionsViewState extends State<SubscriptionsView> {
  bool isLoading = true;

  bool isPaymentDone = true;
  BaseClient baseClient = BaseClient();
  SubscriptionPaymentModal? paymentModal;
  DateTime now2 = DateTime.now();
  String formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

  SubscriptionDataModal? subscriptionlist;

  TextEditingController _paymentController = TextEditingController();

  late Razorpay _razorpay;

  @override
  void initState() {
    super.initState();

    getData();
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  getData() async {
    var response =
        await baseClient.get(true, "$baseUrl", "/api/v1/subscription/list");

    subscriptionlist = subscriptionDataModalFromJson(response);
    isLoading = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        getData();
      },
      child: Scaffold(
        appBar: CustomAppBar("Subscription Plans "),
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : subscriptionlist!.subscription!.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Container(
                        height: MediaQuery.of(context).size.height / 2 + 68,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: AppColor.accentWhite,
                            borderRadius: BorderRadius.circular(15)),
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(
                                height: 20,
                              ),
                              Text(
                                "You Haven't Purchesed any subscription plan",
                                style: Texttheme.bodyText1.copyWith(
                                    color: AppColor.accentDarkGrey,
                                    fontSize: 20),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    child: SafeArea(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            margin: EdgeInsets.symmetric(horizontal: 10),
                            child: Card(
                              elevation: 0,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                child: Column(children: [
                                  Row(
                                    children: [
                                      Text(
                                        "Subscription Plans ",
                                        style: Texttheme.title,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Container(
                                        height: 30,
                                        width: 30,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: AppColor.accentLightGrey),
                                        child: Center(
                                            child: Text(
                                          "${subscriptionlist!.subscription!.length == null ? "" : subscriptionlist!.subscription!.length}",
                                          style: TextStyle(
                                              color: AppColor.accentWhite),
                                        )),
                                      ),
                                    ],
                                  ),
                                ]),
                              ),
                            ),
                          ),
                          Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: Row(
                                children: [
                                  Text(
                                    "Your Subscribed Plans  ",
                                    style: Texttheme.title,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Container(
                                    height: 30,
                                    width: 30,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: AppColor.accentLightGrey),
                                    child: Center(
                                        child: Text(
                                      "${subscriptionlist!.sPlans!.length == null ? "" : subscriptionlist!.sPlans!.length}",
                                      style: TextStyle(
                                          color: AppColor.accentWhite),
                                    )),
                                  ),
                                ],
                              )),
                          subscriptionlist!.sPlans!.isEmpty
                              ? Card(
                                  elevation: 0,
                                  margin: EdgeInsets.symmetric(horizontal: 20),
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    color: AppColor.accentWhite,
                                    child: Center(
                                        child: Text(
                                            "You Haven't Purchesed any subscription plan")),
                                  ),
                                )
                              : ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount:
                                      subscriptionlist!.sPlans!.length == null
                                          ? 0
                                          : subscriptionlist!.sPlans!.length,
                                  itemBuilder: (context, index) {
                                    return Column(
                                      children: [
                                        SubscripedCard(
                                          id: subscriptionlist!
                                              .sPlans![index].id!,
                                          title: subscriptionlist!
                                              .sPlans![index].subscriptionName!,
                                          amount: subscriptionlist!
                                              .sPlans![index].amount!
                                              .toString(),
                                          // enddate: subscriptionlist!
                                          //     .sPlans![index].endDate
                                          //     .toString(),
                                          enddate:
                                              "${DateFormat('yyyy-MM-dd').format(subscriptionlist!.sPlans![index].endDate!)}",
                                        ),
                                        subscriptionlist!
                                                .sPlans![index].endDate!
                                                .isAfter(now2)
                                            ? Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 15),
                                                child: DefaultButton(
                                                    buttonText: "Active",
                                                    press: () {},
                                                    buttonColor:
                                                        AppColor.primaryColor),
                                              )
                                            : Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 15),
                                                child: DefaultButton(
                                                    buttonText: "Off",
                                                    press: () {},
                                                    buttonColor: AppColor
                                                        .accentLightGrey),
                                              )
                                      ],
                                    );
                                  },
                                ),
                          Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Text(
                              "All Plans ",
                              style: Texttheme.title,
                            ),
                          ),
                          ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount:
                                subscriptionlist!.subscription!.length == null
                                    ? 0
                                    : subscriptionlist!.subscription!.length,
                            itemBuilder: (context, index) {
                              return SubscriptionCard(
                                id: subscriptionlist!.subscription![index].id!,
                                title: subscriptionlist!
                                    .subscription![index].title!,
                                description: subscriptionlist!
                                    .subscription![index].description!,
                                price: subscriptionlist!
                                    .subscription![index].price
                                    .toString(),
                                doration: subscriptionlist!
                                    .subscription![index].duration!,
                                s_Price: subscriptionlist!
                                    .subscription![index].sPrice!,
                                onPress: () {
                                  Get.to(PaymentMethod(), arguments: [
                                    {
                                      "s_id":
                                          "${subscriptionlist!.subscription![index].id}",
                                    },
                                    {
                                      "s_name":
                                          "${subscriptionlist!.subscription![index].title}",
                                    },
                                    {
                                      "amount":
                                          "${subscriptionlist!.subscription![index].sPrice}",
                                    },
                                    {
                                      "duration":
                                          "${subscriptionlist!.subscription![index].duration}",
                                    }
                                  ]);
                                },
                                subscriptionStatus:
                                    '${subscriptionlist!.subscription![index].subscribe == null ? "" : subscriptionlist!.subscription![index].subscribe}',
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}
