import 'dart:async';

import 'package:get/get.dart';
import 'package:homeqart/app/main_page.dart';
import 'package:homeqart/app/modules/login/views/login_view.dart';

class SubscriptionController extends GetxController {
  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
