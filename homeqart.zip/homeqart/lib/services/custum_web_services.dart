// import 'dart:async';
// import 'dart:convert';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:homeqart_online/models/response/get_banners_response.dart';

// import 'package:http/http.dart' as http;
// import '../helper/get_storage_helper.dart';
// import '../models/response/error_model.dart';
// import '../theme.dart';
// import 'app_exceptions.dart';

// class CustumBaseClient {
//   // static const int timeOutDuration = 20;
//   static Future<GetBannersResponse> carousel() async {
//     var uri = Uri.parse("/api/v1/banners");
//     try {
//       var response = await http.get(
//         uri,
//         headers: <String, String>{
//           'Content-Type': 'application/json; charset=UTF-8',
//           'Authorization': 'Bearer ${box.read('access_token')}'
//         },
//       );

//       print(response.body);
//       var jsonString = jsonDecode(response.body);
//       return jsonString;
//     } on SocketException {
//       throw FetchDataException('No Internet connection', uri.toString());
//     } on TimeoutException {
//       throw ApiNotRespondingException(
//           'API not responded in time', uri.toString());
//     }
//   }
// }
